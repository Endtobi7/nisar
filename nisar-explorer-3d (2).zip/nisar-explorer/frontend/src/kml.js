// Every NISAR browse PNG ships with a KML file that states exactly where the image sits on the map.
import { fetchText } from "./api.js";

// rotate a LatLonBox around its centre (KML rotation is counter-clockwise, in degrees)
function rotateBox(n, s, e, w, deg) {
  const cx = (e + w) / 2, cy = (n + s) / 2, k = Math.cos((cy * Math.PI) / 180), a = (deg * Math.PI) / 180;
  return [[w, n], [e, n], [e, s], [w, s]].map(([x, y]) => {
    const dx = (x - cx) * k, dy = y - cy;
    return [cx + (dx * Math.cos(a) - dy * Math.sin(a)) / k, cy + dx * Math.sin(a) + dy * Math.cos(a)];
  });
}

// -> corners [TL, TR, BR, BL] or null
export function parseKml(text, imageName = "") {
  const doc = new DOMParser().parseFromString(text, "text/xml");
  const all = [...doc.getElementsByTagNameNS("*", "GroundOverlay")];
  if (!all.length) return null;
  const g = all.find((o) => imageName && (o.getElementsByTagNameNS("*", "href")[0]?.textContent || "").includes(imageName)) || all[0];
  const quad = g.getElementsByTagNameNS("*", "LatLonQuad")[0];
  if (quad) {
    const pts = quad.getElementsByTagNameNS("*", "coordinates")[0].textContent.trim().split(/\s+/).map((s) => s.split(",").slice(0, 2).map(Number));
    // KML order is lower-left, lower-right, upper-right, upper-left
    if (pts.length === 4 && pts.flat().every(Number.isFinite)) return [pts[3], pts[2], pts[1], pts[0]];
  }
  const num = (t) => parseFloat(g.getElementsByTagNameNS("*", t)[0]?.textContent);
  const [n, s, e, w] = ["north", "south", "east", "west"].map(num);
  if ([n, s, e, w].every(Number.isFinite)) return rotateBox(n, s, e, w, num("rotation") || 0);
  return null;
}

// find the KML that belongs to a granule's browse image and return exact corners, or null
export async function exactCorners(feature, sid) {
  const p = feature.properties;
  const png = Array.isArray(p.browse) ? p.browse[0] : null;
  const extra = Array.isArray(p.additionalUrls) ? p.additionalUrls : [];
  const urls = [...new Set([
    ...extra.filter((u) => /\.kml($|\?)/i.test(u)),
    png && png.replace(/\.(png|jpe?g)(\?.*)?$/i, ".kml"),
  ].filter(Boolean))];
  const name = png ? png.split("/").pop().split("?")[0] : "";
  for (const u of urls) {
    try {
      const c = parseKml(await fetchText(u, sid), name);
      if (c) return c;
    } catch { /* try next */ }
  }
  return null;
}
