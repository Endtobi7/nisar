// Turns an analysis result (metrics, images, series, notes) into plain language:
//  - interpret(res).items[i]      what each number is and what its value means
//  - interpret(res).headline/points/next   the overall reading
//  - explainImage(im) / explainSeries(group)  what a figure or chart shows
// All thresholds are rules of thumb (as the README says), never NASA values.

const num = (s) => (String(s ?? "").match(/-?\d+(?:\.\d+)?(?:e-?\d+)?/gi) || []).map(Number);
const f1 = (x) => (Math.abs(x) >= 100 ? Math.round(x) : Math.abs(x) >= 10 ? x.toFixed(1) : x.toFixed(2)).toString();
const sentence = (s) => s.charAt(0).toUpperCase() + s.slice(1);

// level: good | info | watch | alert
const R = [];
const rule = (re, fn) => R.push([re, fn]);

// ---------- backscatter and vegetation ----------
rule(/^(HH|HV|VH|VV) (backscatter|amplitude)/, (m, v, label) => {
  const pol = label.slice(0, 2), cross = pol === "HV" || pol === "VH";
  const [med, lo, hi] = v;
  const what = "How strongly the ground sends the radar signal back, in decibels (dB). More negative = darker = less energy returned.";
  let read, level = "info";
  if (cross) {
    if (med < -27) { read = "Very dark in the cross-polarised channel: smooth bare ground, calm water or radar shadow. Almost no vegetation volume."; }
    else if (med < -20) { read = "Low cross-polarised return: sparse vegetation, crops at an early stage or bare soil."; }
    else if (med < -13) { read = "Moderate cross-polarised return: typical of vegetation (shrubs, crops, open woodland). This channel grows with plant volume."; }
    else { read = "Strong cross-polarised return: dense forest or very rough surfaces such as towns and rocks."; }
  } else if (med < -20) { read = "Very dark: calm water, very smooth surfaces or radar shadow dominate the typical pixel."; level = "watch"; }
  else if (med < -15) { read = "Dark: smooth bare soil, dry sand or short sparse vegetation."; }
  else if (med < -8) { read = "Mid-range: typical of soil with vegetation, fields and woodland."; }
  else { read = "Bright: rough ground, buildings, rocks or slopes facing the radar dominate."; level = "watch"; }
  if (hi != null && lo != null && hi - lo > 15) read += ` The 5–95 % range spans ${f1(hi - lo)} dB, so the window mixes very different surfaces (for example water next to built-up land).`;
  return { what, read, level };
});
rule(/^(HV|VH) minus (HH|VV)/, (m, v) => ({
  what: "Cross-polarised minus co-polarised backscatter. It rises with vegetation volume.",
  read: v[0] > -6 ? "Close to 0 dB difference: strong volume scattering, so dense vegetation." : v[0] > -10 ? "Intermediate: moderate vegetation cover." : "Very negative: little volume scattering, so bare or smooth ground.",
  level: "info",
}));
rule(/Radar vegetation index/, (m, v) => ({
  what: "Index from 0 (bare surface) towards 1 (dense vegetation) built from the cross- and co-polarised channels.",
  read: v[0] < 0.3 ? `${v[0]}: sparse vegetation or bare ground.` : v[0] < 0.6 ? `${v[0]}: moderate vegetation.` : `${v[0]}: dense vegetation.`,
  level: "info", story: { p: 40, text: v[0] < 0.3 ? "Vegetation is sparse (radar vegetation index " + v[0] + ")." : v[0] < 0.6 ? "Vegetation cover is moderate (index " + v[0] + ")." : "Vegetation is dense (index " + v[0] + ")." },
}));
rule(/^Valid pixels/, (m, v) => ({
  what: "Share of pixels in the window that hold usable data.",
  read: v[0] >= 95 ? "Practically complete coverage." : v[0] >= 80 ? "Mostly complete; small gaps." : "Large gaps: the results describe only part of your window. Try another window or file.",
  level: v[0] >= 80 ? "good" : "watch",
}));
rule(/Excluded by the mask/, (m, v) => ({
  what: "Pixels the product's own quality mask marks as invalid or outside the image.",
  read: v[0] < 1 ? "Nothing significant was excluded." : v[0] < 10 ? "A small part was excluded and is not in any number." : "A large part was excluded: the window touches the image edge or an unfocused zone.",
  level: v[0] < 10 ? "info" : "watch",
}));
rule(/Water-like share/, (m, v) => ({
  what: "Share of pixels darker than −18 dB. Calm water is dark, but so are radar shadows and smooth tarmac or sand.",
  read: v[0] < 1 ? "Almost no water-like pixels." : v[0] < 10 ? "A modest share of dark pixels: small lakes, rivers or shadow." : "A large share of dark pixels: open water, a flood or extensive shadow. Use the water map to separate them.",
  level: v[0] < 10 ? "info" : "watch",
}));

// ---------- water map ----------
rule(/^Automatic water threshold/, () => ({
  what: "The dB limits used to call a pixel water: a very dark seed, then growth into slightly brighter neighbours.",
  read: "These are fixed physical limits, not learned from your area. Wind-roughened water is brighter than the limit and can be missed.", level: "info",
}));
rule(/^Water share/, (m, v) => ({
  what: "Share of the window classified as open water.",
  read: v[0] < 0.5 ? "Essentially no open water in this window." : v[0] < 10 ? `About ${f1(v[0])} % of the window is open water: a lake, reservoir or river section.` : `${f1(v[0])} % of the window is open water: a large lake, the sea or a flood.`,
  level: "info", story: { p: 80, head: (x) => x < 0.5 ? "No open water found in this window" : `Open water covers ${f1(x)} % of the window`, text: v[0] < 0.5 ? "No significant open water was detected." : `Open water covers ${f1(v[0])} % of the window.` },
}));
rule(/^Water area/, (m, v) => ({ what: "Surface area of the detected water.", read: `${m.value}. Compare with a known reservoir or lake size to judge whether the detection is plausible.`, level: "info" }));
rule(/^Water bodies/, (m, v) => ({ what: "Number of separate connected water patches.", read: v[0] <= 3 ? "Few, large patches: lakes or one river." : "Many patches: scattered ponds, a braided river, or noise. Tiny regions (0.00 km²) are probably speckle.", level: "info" }));
rule(/^Water region/, (m) => ({ what: "One detected water patch: its area, mean brightness and shape.", read: /elongated/.test(m.value) ? "Elongated shape: typical of a river or canal." : /compact/.test(m.value) ? "Compact shape: typical of a lake or reservoir." : "Irregular shape: check the map.", level: "info" }));
rule(/^Possible water/, (m) => ({ what: "Pixels that are dark but not dark enough to be sure.", read: "Treat these as a hint only: wet soil, tarmac or shadow look similar.", level: "watch" }));
rule(/^Excluded as steep terrain/, () => ({ what: "Dark pixels removed because they lie on steep slopes, where dark means radar shadow, not water.", read: "A large share here means the area is mountainous and the water map is more reliable on flat ground only.", level: "info" }));

// ---------- land cover and scattering ----------
rule(/^Class \d/, (m) => ({ what: "One land-cover group found by clustering the backscatter. Groups have no names: the colour on the map just separates similar pixels.", read: /darkest/.test(m.label) ? "Darkest group: water, smooth ground or shadow." : /brightest/.test(m.label) ? "Brightest group: buildings, rock or slopes facing the radar." : "Intermediate surfaces; compare its dB values with the other groups.", level: "info" }));
rule(/^Surface scattering/, (m, v) => ({ what: "Share of power from single reflection off the ground or water surface.", read: v[0] > 50 ? "Surface scattering dominates: bare ground, water or short crops." : "A minor part of the signal.", level: "info" }));
rule(/^Double-bounce scattering/, (m, v) => ({ what: "Share of power from two reflections (ground then wall or trunk).", read: v[0] > 20 ? "A large double-bounce share: built-up areas or flooded vegetation." : "Small: few buildings or flooded trees.", level: "info", story: v[0] > 20 ? { p: 55, text: `Double-bounce is high (${f1(v[0])} %), a typical sign of buildings or flooded vegetation.` } : undefined }));
rule(/^Volume scattering/, (m, v) => ({ what: "Share of power from many random reflections inside a canopy.", read: v[0] > 50 ? "Volume scattering dominates: forest or dense vegetation." : "Not dominant: sparse vegetation or bare ground.", level: "info", story: { p: 50, text: v[0] > 50 ? `Volume scattering dominates (${f1(v[0])} % of power): forest or dense vegetation.` : `Volume scattering is limited (${f1(v[0])} %): sparse vegetation or bare ground.` } }));
rule(/^Dominant mechanism/, () => ({ what: "Share of pixels where each scattering type is the strongest.", read: "The largest share names the main land type of the window.", level: "info" }));
rule(/^Very bright share/, (m, v) => ({ what: "Share of very bright pixels.", read: v[0] < 1 ? "Few bright targets: little built-up land." : "Noticeable bright share: towns, rocks or slopes facing the satellite.", level: "info" }));
rule(/sigma-0|Gamma-0 to sigma-0/, () => ({ what: "Conversion between two ways of normalising backscatter (gamma-0 vs sigma-0).", read: "Only needed to compare with sigma-0 products. It does not change the interpretation.", level: "info" }));
rule(/texture/i, (m, v) => ({ what: "Local variability of the brightness (coefficient of variation).", read: v[0] < 0.4 ? "Low: smooth, homogeneous surfaces (fields, water)." : "High: mixed targets such as towns, trees and rocks.", level: "info" }));
rule(/^Mask:|^Sub-swaths|^Number of looks|^Equivalent number of looks/, (m) => ({ what: "Technical quality information about the product (mask, averaging, speckle).", read: m.note || "Used to judge how noisy the other numbers are.", level: "info" }));
rule(/Phase concentration/, (m, v) => ({ what: "How similar the phases of the pixels are (0 random, 1 identical).", read: v[0] < 0.2 ? "Random, as expected for one date: a single phase has no use alone." : "Unusually uniform.", level: "info" }));
rule(/^Bright targets detected/, (m, v) => ({ what: "Number of isolated very bright points (ships, buildings, corner reflectors).", read: v[0] === 0 ? "No isolated bright target found." : `${v[0]} target(s) found: check them on the map (likely man-made objects).`, level: "info", story: { p: 45, text: v[0] === 0 ? "No isolated bright targets." : `${v[0]} isolated bright target(s) detected.` } }));
rule(/^Target \d/, () => ({ what: "One detected bright point: strength in dB and location.", read: "Higher dB = stronger reflector.", level: "info" }));

// ---------- interferometry (ground motion) ----------
rule(/^Line-of-sight change/, (m, v) => {
  const big = Math.max(Math.abs(v[0]), Math.abs(v[1] ?? 0));
  return {
    what: "Change in distance between ground and satellite along the line of sight, relative to a reference level, in cm (2–98 % range). One colour cycle in the raw phase is about 12 cm.",
    read: big < 2 ? "Under about 2 cm: no clear deformation. Atmosphere and noise commonly cause this much." : big < 10 ? `Up to ${f1(big)} cm: possible slow deformation (subsidence, uplift, landslide creep) or an atmospheric artefact. Confirm with coherence and a second pair.` : `Up to ${f1(big)} cm: large change. Real motion (earthquake, landslide, mining, strong subsidence) is likely, or an unwrapping error.`,
    level: big < 2 ? "good" : big < 10 ? "watch" : "alert",
    story: { p: 95, head: () => big < 2 ? "No clear ground motion between the two dates" : big < 10 ? `Ground motion of up to ${f1(big)} cm detected (needs confirming)` : `Large ground motion of up to ${f1(big)} cm detected`, text: big < 2 ? "Line-of-sight change stays under ~2 cm, within what noise and atmosphere produce." : `Line-of-sight change reaches ${f1(big)} cm. Positive/negative sign depends on the product convention; positive usually means towards the satellite.` },
  };
});
rule(/^Spread \(std dev\)|^Spread after/, (m, v) => ({ what: "How much the displacement varies across the window (standard deviation, cm).", read: v[0] < 1 ? "Very uniform: the whole window moves together or not at all." : "Varied: some parts move differently from others. Look at the map for the pattern.", level: "info" }));
rule(/^Largest change/, (m, v) => ({ what: "Biggest absolute displacement in the window.", read: v[0] < 2 ? "Small." : "Large enough to be worth checking on the map. Single extreme pixels can be noise.", level: "info" }));
rule(/^Coherence$|^Mean coherence|^Coherence \(5x5/, (m, v) => {
  if (/reference pair/.test(m.value)) {
    const drop = v[1] < v[0] - 0.1;
    return { what: "Average coherence of the reference pair and of the event pair.", read: drop ? "The event pair is clearly less coherent than the reference: something changed on the ground." : "Similar coherence in both pairs: no widespread surface change.", level: drop ? "watch" : "good" };
  }
  const c = v[0];
  return {
    what: "Quality of the radar phase between two dates (1 = stable surface, 0 = completely changed).",
    read: c >= 0.7 ? `High (${c}): the surface stayed stable, so the displacement is trustworthy.` : c >= 0.4 ? `Moderate (${c}): usable in the stable parts only; vegetation or moisture changed the rest.` : `Low (${c}): the surface changed too much, so the displacement is mostly noise.`,
    level: c >= 0.7 ? "good" : c >= 0.4 ? "info" : "watch",
    story: { p: 85, text: c >= 0.7 ? `Coherence is high (${c}), so the measurements are reliable.` : c >= 0.4 ? `Coherence is moderate (${c}): trust the stable areas only.` : `Coherence is low (${c}): treat displacement values with great caution.` },
  };
});
rule(/^Reliable pixels|^Pixels kept \(coherence/, (m, v) => ({ what: "Share of pixels coherent enough to trust.", read: v[0] >= 60 ? "Most of the window is reliable." : v[0] >= 25 ? "Only part of the window is reliable: look at the mask." : "Very little is reliable: results here are weak evidence.", level: v[0] >= 25 ? "info" : "watch" }));
rule(/^Decorrelated pixels/, (m, v) => ({ what: "Share of pixels whose phase decorrelated (coherence below 0.3).", read: v[0] < 20 ? "Few: the surface is mostly stable." : "Many: water, dense vegetation, snow or damage. If damage is suspected, compare with the coherence-change analysis.", level: v[0] < 20 ? "good" : "watch" }));
rule(/^Area moving more than/, (m) => ({ what: "Area of reliable pixels that move more than your limit.", read: /^0(\.0+)?\s/.test(m.value) ? "Nothing moves more than the limit." : "This area is a candidate zone of ground motion. Check it against geology, mining or water extraction.", level: /^0(\.0+)?\s/.test(m.value) ? "good" : "watch", story: { p: 90, text: /^0(\.0+)?\s/.test(m.value) ? "No area moves more than the chosen limit." : `${m.value} moves more than the chosen limit.` } }));
rule(/^Share of reliable pixels that move more/, (m, v) => ({ what: "Same as above as a share of reliable pixels.", read: v[0] < 1 ? "Negligible." : v[0] < 10 ? "A localised area." : "A widespread pattern: check for a long-wavelength atmospheric effect.", level: "info" }));
rule(/^(Largest positive|Largest negative|Maximum|Minimum)/, () => ({ what: "Extreme displacement and where it occurs.", read: "Extremes are sensitive to noise: confirm they sit in a coherent patch.", level: "info" }));
rule(/^Profile/, () => ({ what: "Displacement range along a line across the window.", read: "A smooth step suggests a fault or slope edge; a noisy wiggle suggests atmosphere.", level: "info" }));
rule(/strain/i, () => ({ what: "Rate at which displacement changes with distance (stretching or compression).", read: "High values concentrate where the ground bends or breaks, such as fault traces or landslide edges.", level: "info" }));
rule(/^Displacement uncertainty|uncertainty$/, (m) => ({ what: "Estimated error of each measurement.", read: "Differences smaller than this are not meaningful.", level: "info" }));
rule(/^One phase cycle/, () => ({ what: "Motion corresponding to one full colour cycle (fringe) in the phase image.", read: "Count the colour bands: each one is this much motion. Dense bands mean fast change.", level: "info" }));
rule(/^Fringe density/, (m, v) => ({ what: "How many phase fringes per 100 pixels.", read: v[0] < 5 ? "Smooth: little ground change." : "Dense fringes: steep ground-change gradient, or noise if coherence is low.", level: "info" }));

// ---------- offsets, glacier speed ----------
rule(/^Bulk offset/, () => ({ what: "Common shift of the window between the two dates.", read: "Caused by orbit and geometry. It has been removed and is not ground motion.", level: "info" }));
rule(/^Noise level/, () => ({ what: "Typical random error of the offsets.", read: "Motion smaller than this cannot be told from noise.", level: "info" }));
rule(/^Relative motion/, (m, v) => ({ what: "Median and 95th-percentile offset after removing the common shift (metres).", read: v[1] > 1 ? "Large offsets between the two dates: moving ground or ice." : "Small offsets.", level: "info" }));
rule(/^Implied speed|^Speed over|^Median speed|^95th percentile speed|^Largest speed change/, (m, v) => {
  const ns = /not significant/.test(m.value);
  return {
    what: "Speed of the surface obtained from the offsets and the time between acquisitions (metres per year).",
    read: ns ? "Below the noise floor: no motion can be claimed from these data." : `${m.value.split("(")[0].trim()} Compare with the noise floor in the note: speeds close to it are noise.`,
    level: ns ? "info" : "watch",
    story: /^Implied|^Speed over|^95th/.test(m.label) ? { p: 90, head: () => ns ? "No surface motion above the noise" : "Surface motion above the noise detected", text: ns ? "The offsets show no motion clearly above the noise." : `Speed reaches ${m.value.split(",")[0].replace("median", "median speed")}.` } : undefined,
  };
});
rule(/^Mean direction|^Direction consistency/, (m, v) => ({ what: /Mean/.test(m.label) ? "Average direction of the flow in the image frame (not rotated to north)." : "How uniform the flow direction is (1 = all the same).", read: /Direction/.test(m.label) ? (v[0] > 0.8 ? "Very consistent flow, typical of a glacier." : "Mixed directions: noise or complex motion.") : "Use together with the arrows on the map.", level: "info" }));
rule(/^Pixels kept$/, (m, v) => ({ what: "Share of pixels left after quality filtering.", read: v[0] > 50 ? "Most of the data passed the filters." : "Strong filtering: coverage is thin.", level: "info" }));

// ---------- two-file analyses ----------
rule(/^Change threshold/, () => ({ what: "Smallest brightness change (dB) counted as real, set at several times the noise of this scene.", read: "Changes smaller than this are treated as noise.", level: "info" }));
rule(/^Median change/, (m, v) => ({ what: "Typical brightness change between the two dates (after minus before).", read: Math.abs(v[0]) < 0.5 ? "Near zero: the scene as a whole did not change." : v[0] > 0 ? "The scene became brighter overall: wetter soil, growth or roughening." : "The scene became darker overall: drying, water or smoother ground. A global shift can also come from calibration.", level: Math.abs(v[0]) < 0.5 ? "good" : "watch" }));
rule(/^Brighter pixels|^Darker pixels/, (m, v) => {
  const up = /Brighter/.test(m.label), s = v[0];
  return {
    what: `Share and area of pixels that became ${up ? "brighter" : "darker"} by more than the threshold.`,
    read: s < 1 ? "Almost none." : s < 5 ? "A small, localised change." : s < 20 ? "A moderate area changed." : "Widespread change: check for weather, soil moisture or season before blaming a local event.",
    level: s < 5 ? "info" : "watch",
    story: { p: 92, head: () => null, text: s < 1 ? `Almost no pixels became ${up ? "brighter" : "darker"}.` : `${f1(s)} % of pixels became ${up ? "brighter (growth, wetter soil, new structures)" : "darker (water, cleared land, drying)"}: ${m.value.split("-")[1]?.trim() || ""}`.replace(/: $/, ".") },
  };
});
rule(/^Permanent water/, (m, v) => ({ what: "Water present on both dates.", read: "The normal lakes and rivers: a baseline to compare the flood with.", level: "info" }));
rule(/^New open water/, (m, v) => ({
  what: "Pixels dark after the event but not before: newly flooded ground.",
  read: v[0] < 0.1 ? "No significant new open water." : v[0] < 2 ? "A small newly flooded area: local overflow or ponding." : "A large newly flooded area.",
  level: v[0] < 0.1 ? "good" : v[0] < 2 ? "watch" : "alert",
  story: { p: 99, head: () => v[0] < 0.1 ? "No new flooding detected" : `New flooding detected: ${m.value.split("-")[1]?.trim() || f1(v[0]) + " %"}`, text: v[0] < 0.1 ? "No significant newly flooded area." : `${f1(v[0])} % of the window is newly under water (${m.value.split("-")[1]?.trim()}).` },
}));
rule(/^Possible flooded vegetation/, (m, v) => ({ what: "Pixels much brighter after the event, a possible double-bounce signature of flooded trees or crops.", read: "A hint only: soil moisture and plant growth look similar. Confirm with optical imagery.", level: "watch", story: v[0] >= 1 ? { p: 70, text: `${f1(v[0])} % might be flooded vegetation (uncertain).` } : undefined }));
rule(/^Vegetation loss/, (m, v) => ({
  what: "Patches where the cross-polarised signal dropped sharply, as when forest is cleared or burned.",
  read: v[0] < 0.5 ? "Negligible vegetation loss." : v[0] < 5 ? "Localised clearing or burn patches." : "Extensive vegetation loss.",
  level: v[0] < 0.5 ? "good" : v[0] < 5 ? "watch" : "alert",
  story: { p: 99, head: () => v[0] < 0.5 ? "No significant vegetation loss" : v[0] < 5 ? "Localised vegetation loss detected" : "Extensive vegetation loss detected", text: v[0] < 0.5 ? "No significant vegetation loss." : `${f1(v[0])} % of the window lost vegetation (${m.value.split("-")[1]?.trim()}).` },
}));
rule(/^Median (HV|VH) change/, (m, v) => ({ what: "Typical change of the cross-polarised signal (dB). The value in brackets is inside the loss area.", read: v[0] < -1 ? "Overall drop: less vegetation." : "No overall drop.", level: "info" }));
rule(/^Pixels that lost more than/, (m, v) => ({
  what: "Pixels that were stable in the reference pair but lost coherence in the event pair.",
  read: v[0] < 1 ? "Very few: the surface stayed stable." : v[0] < 10 ? "A local area lost coherence: damage, flooding or ground disturbance." : "A large area lost coherence: major surface change.",
  level: v[0] < 1 ? "good" : v[0] < 10 ? "watch" : "alert",
  story: { p: 99, head: () => v[0] < 1 ? "The surface stayed stable across the event" : "Surface change detected (coherence loss)", text: v[0] < 1 ? "Almost no pixel lost coherence." : `${f1(v[0])} % of the window lost coherence (${m.value.split("-")[1]?.trim()}): look for damage, flooding or land disturbance.` },
}));
rule(/^Vertical change/, (m, v) => ({ what: "Up–down ground motion separated from two viewing directions (cm, 2–98 % range).", read: Math.max(Math.abs(v[0]), Math.abs(v[1])) < 2 ? "No clear vertical movement." : "Vertical movement detected: positive is uplift, negative is subsidence.", level: Math.max(Math.abs(v[0]), Math.abs(v[1])) < 2 ? "good" : "watch", story: { p: 95, head: () => Math.max(Math.abs(v[0]), Math.abs(v[1])) < 2 ? "No clear vertical ground motion" : "Vertical ground motion detected", text: `Vertical change spans ${m.value.replace(" (2-98%)", "")}.` } }));
rule(/^East-west change/, (m, v) => ({ what: "Horizontal east–west ground motion (cm).", read: Math.max(Math.abs(v[0]), Math.abs(v[1])) < 2 ? "No clear horizontal movement." : "Horizontal movement: positive is towards the east.", level: "info" }));
rule(/^Geometry used/, () => ({ what: "Viewing geometry assumed to split the two measurements.", read: "Nominal values: a small error here scales the up/east results slightly.", level: "info" }));
rule(/^Difference ascending/, (m, v) => ({ what: "Brightness difference between ascending and descending passes (dB).", read: "Differences come from slope direction, shadow or layover, not from change.", level: "info" }));
rule(/^Pixels differing by more than 3 dB/, (m, v) => ({ what: "Share of pixels that differ strongly between the two viewing directions.", read: v[0] < 10 ? "Small: terrain is fairly flat." : "Large: relief matters; combine both passes to fill gaps.", level: "info" }));
rule(/^Correlation \(backscatter/, (m, v) => ({ what: "How closely radar brightness follows soil moisture.", read: Math.abs(v[0]) > 0.6 ? "Strong relationship: radar tracks moisture here." : Math.abs(v[0]) > 0.3 ? "Moderate relationship." : "Weak relationship: vegetation or roughness dominates.", level: "info" }));
rule(/^Straight-line fit/, () => ({ what: "Slope of the linear fit between backscatter and soil moisture.", read: "A steeper slope means the radar is more sensitive to moisture.", level: "info" }));
rule(/^Agreement where both/, () => ({ what: "Agreement between phase and offset measurements where both are reliable.", read: "Small bias and rms mean the two methods confirm each other.", level: "info" }));
rule(/^Pixels filled from offsets|^Pixels differing/, () => ({ what: "Pixels where phase is unreliable and offsets were used instead.", read: "Filled pixels are less precise.", level: "info" }));
rule(/^Pixels kept/, (m, v) => ({ what: "Share of pixels left after masking.", read: v[0] > 50 ? "Most data kept." : "Heavy masking: coverage is thin.", level: "info" }));
rule(/^Water-like pixels removed/, () => ({ what: "Water-like pixels removed because phase over water is meaningless.", read: "Not an error: those areas simply cannot be measured.", level: "info" }));

// ---------- time series ----------
rule(/^Dates/, () => ({ what: "Number of acquisitions used and the period they cover.", read: "More dates give a more reliable trend.", level: "info" }));
rule(/ mean backscatter/, () => ({ what: "Average backscatter over all dates and its range.", read: "A wide range over time means the place changes (crops, water, wetness).", level: "info" }));
rule(/ trend$/, (m, v) => ({
  what: "Straight-line trend of the backscatter over the time series, in dB per year.",
  read: Math.abs(v[0]) < 0.5 ? "Essentially flat: the place is stable over this period." : v[0] > 0 ? `Rising by ${f1(v[0])} dB/year: growth, wetter ground or new structures.` : `Falling by ${f1(-v[0])} dB/year: drying, clearing or more water.`,
  level: Math.abs(v[0]) < 0.5 ? "good" : "watch", story: { p: 90, head: () => Math.abs(v[0]) < 0.5 ? "The place is stable over the period" : v[0] > 0 ? "The backscatter is rising over the period" : "The backscatter is falling over the period", text: `Trend ${f1(v[0])} dB/year. Short records give an uncertain trend: it may be only a season.` },
}));
rule(/^Largest (drop|rise) between/, (m, v) => ({ what: `The biggest ${/drop/.test(m.label) ? "fall" : "rise"} between two consecutive dates.`, read: Math.abs(v[0]) < 1.5 ? "Within normal variation (rain, wind, season)." : Math.abs(v[0]) < 3 ? "Notable: look at weather and land use around those dates." : "Abrupt: a real event is likely (flood, clearing, harvest, snow melt).", level: Math.abs(v[0]) < 1.5 ? "info" : "watch", story: Math.abs(v[0]) >= 3 ? { p: 88, text: `Abrupt ${/drop/.test(m.label) ? "drop" : "rise"} of ${f1(Math.abs(v[0]))} dB (${m.value.split("between")[1]?.trim()}).` } : undefined }));
rule(/^Pixels that changed/, (m, v) => ({
  what: "Share of pixels with a lasting change (beyond several sigma for two dates in a row).",
  read: v[0] < 1 ? "Almost no lasting change." : v[0] < 10 ? "A localised area changed." : "A widespread lasting change.",
  level: v[0] < 1 ? "good" : "watch", story: { p: 98, head: () => v[0] < 1 ? "No lasting change in the period" : `Lasting change found on ${f1(v[0])} % of the window`, text: v[0] < 1 ? "Almost no pixel changed." : `${f1(v[0])} % of pixels changed lastingly (${m.value.split("-")[1]?.trim()}).` },
}));
rule(/^Earliest change|^Latest first-change/, () => ({ what: "Date of the first and last first-change found in the window.", read: "A narrow date range means one event; a wide range means gradual change.", level: "info" }));
rule(/^Layer used/, () => ({ what: "The data layer used for the analysis.", read: "HV is preferred because it reacts most to vegetation change.", level: "info" }));
rule(/temporal average/, () => ({ what: "Average over all dates, which reduces speckle noise.", read: "A cleaner picture of the average surface than any single date.", level: "info" }));
rule(/^Variability/, (m, v) => ({ what: "How much backscatter varies over time (coefficient of variation).", read: v[0] < 0.4 ? "Low: stable surfaces." : "High: changing places such as crops, water or wetlands.", level: "info" }));
rule(/^Largest coherence drop/, (m, v) => ({ what: "Biggest fall of coherence between two dates.", read: v[0] < 0.15 ? "Small." : "Sizeable: often a change event (damage, flooding, harvest, snow).", level: v[0] < 0.15 ? "info" : "watch" }));
rule(/^Pair network/, () => ({ what: "Interferogram pairs used, over the full period.", read: "More connected pairs give a more robust velocity.", level: "info" }));
rule(/^Reference point/, () => ({ what: "Most coherent pixel used as zero: all motion is relative to it.", read: "If this point itself moves, everything is biased. Check it is on stable ground.", level: "info" }));
rule(/^Velocity \(line of sight\)/, (m, v) => {
  const [med, lo, hi] = v, big = Math.max(Math.abs(lo ?? med), Math.abs(hi ?? med));
  return {
    what: "Average speed of ground motion along the line of sight, in mm per year (median and 2–98 % range). Relative to the reference point, so the median near zero is expected.",
    read: big < 5 ? "No significant motion: the range stays within a few mm/yr." : big < 20 ? `Slow motion up to about ${f1(big)} mm/yr: subsidence, uplift or creep. Compare with the uncertainty and check the pattern on the map.` : `Fast motion up to about ${f1(big)} mm/yr: active deformation such as strong subsidence or a landslide.`,
    level: big < 5 ? "good" : big < 20 ? "watch" : "alert",
    story: { p: 99, head: () => big < 5 ? "No significant ground motion over the period" : big < 20 ? `Slow ground motion up to ~${f1(big)} mm/yr` : `Fast ground motion up to ~${f1(big)} mm/yr`, text: `Velocity range ${f1(lo)} to ${f1(hi)} mm/yr relative to the reference point.` },
  };
});
rule(/^Velocity uncertainty/, () => ({ what: "Formal error of the velocity from the pair weights.", read: "A real signal should be several times larger. Atmosphere and unwrapping errors are NOT included, so the true error is larger.", level: "watch" }));
rule(/^Network misfit/, (m, v) => ({ what: "How much the interferogram pairs disagree with each other.", read: v[0] < 0.5 ? "Low: consistent pairs." : "High: unwrapping errors or atmosphere. See the misfit map.", level: v[0] < 0.5 ? "good" : "watch" }));
rule(/^Latest date|^Reference dates/, () => ({ what: "Date compared with the earlier ones.", read: "More reference dates make the comparison fairer.", level: "info" }));
rule(/^Drier than usual|^Wetter than usual/, (m, v) => {
  const dry = /Drier/.test(m.label);
  return { what: `Share of pixels ${dry ? "drier" : "wetter"} than normal on the latest date.`, read: v[0] < 10 ? "Normal conditions for most of the area." : v[0] < 30 ? `A noticeable part is ${dry ? "drier" : "wetter"} than usual.` : `A large part is ${dry ? "drier" : "wetter"} than usual: ${dry ? "dry spell" : "recent rain or irrigation"}.`, level: v[0] < 10 ? "good" : "watch", story: { p: 90, text: v[0] < 10 ? `Few pixels are ${dry ? "drier" : "wetter"} than usual.` : `${f1(v[0])} % of the area is ${dry ? "drier" : "wetter"} than usual.` } };
});
rule(/^Dry \(below|^Wet \(above/, (m, v) => ({ what: "Share of pixels below the dry or above the wet soil-moisture limit.", read: v[0] < 10 ? "Small share." : "Large share: this is the dominant soil condition.", level: "info", story: { p: 85, text: `${m.label.split("(")[0].trim()}: ${f1(v[0])} % of the area.` } }));
rule(/^Soil-moisture uncertainty/, () => ({ what: "Estimated error of the soil-moisture values.", read: "Differences smaller than this are not meaningful.", level: "info" }));
rule(/class \d|vegetation water/i, () => ({ what: "Soil-related or crop information from the SME2 product.", read: "Check the product specification for the exact units.", level: "info" }));
rule(/^(HH|HV|VV|VH)? ?soil|moisture/i, (m, v) => ({ what: "Volumetric soil moisture (m³/m³).", read: v[0] < 0.15 ? "Dry soil." : v[0] < 0.35 ? "Moderate moisture." : "Wet soil.", level: "info" }));

// ---------- figures ----------
const FIG = [
  [/false colou?r/i, "Three polarisations combined in one picture.", "Red = HH, green = HV, blue = HH−HV. Green means vegetation, dark means water or shadow, bright red/white means buildings or rough ground."],
  [/water map|flood map/i, "A classification of open water.", "Blue = water (or permanent water in the flood map). Compare with a known lake or river outline."],
  [/vegetation loss/i, "Where vegetation was lost between the two dates.", "Red marks patches of loss. Tiny speckles are probably noise."],
  [/strong coherence loss/i, "Where the surface changed enough to lose phase coherence.", "Red marks the largest losses: look for damage, flooding or land disturbance."],
  [/removed: water/i, "Pixels removed because they are water-like.", "Blue marks removed pixels; those places cannot be measured by interferometry."],
  [/significant change/i, "Pixels whose brightness changed beyond the noise threshold.", "Blue = darker, red = brighter, grey = no significant change."],
  [/land-cover/i, "Pixels grouped by similar backscatter.", "Each colour is one group. Names come from the class lines above (darkest = water or smooth, brightest = built-up or slopes)."],
  [/decomposition/i, "Scattering types combined in one picture.", "Red = double-bounce (buildings, flooded trees), green = volume (canopy), blue = surface (bare ground, water)."],
  [/coherence change/i, "Difference in coherence between the event pair and the reference pair.", "Blue = coherence lost, red = coherence gained, white = unchanged. Most useful where the reference pair was coherent."],
  [/coherence/i, "How stable the surface was between two dates.", "Bright = stable (reliable measurements), dark = changed or noisy. Water and dense forest are usually dark."],
  [/wrapped|phase/i, "Interferometric phase, wrapped into repeating colour cycles.", "Each full colour cycle is about 12 cm of motion towards or away from the satellite. Dense bands = fast change; smooth colour = no change."],
  [/velocity uncertainty/i, "Estimated error of the velocity map.", "Bright = less certain. A real signal should stand well above these values."],
  [/velocity/i, "Average line-of-sight ground velocity (mm/yr).", "Blue and red are opposite directions, white is no motion relative to the reference point. Look for coherent patches, not single pixels."],
  [/misfit/i, "Disagreement between interferogram pairs.", "Bright = pairs disagree (unwrapping errors or atmosphere): be careful there."],
  [/line-of-sight|displacement|motion \(m\)|vertical|east-west/i, "Ground displacement.", "Blue and red are opposite directions, white is no change relative to a reference. Compact smooth patches suggest real deformation; broad gentle gradients often come from the atmosphere."],
  [/offset|speed/i, "Surface offsets or speed from feature tracking.", "Brighter or warmer colour = faster movement. Speeds near the noise floor are noise."],
  [/anomaly/i, "How unusual the latest date is compared with earlier ones.", "Brown = drier than usual, blue = wetter than usual, beige = normal (z-score in standard deviations)."],
  [/first change|day of first/i, "The date each pixel first changed.", "Colour encodes days since the first date: similar colours mean a similar timing, so one colour patch is one event."],
  [/variability|coefficient of variation/i, "How much each pixel varies over time.", "Bright = changing place (crops, water, wetlands); dark = stable."],
  [/ascending minus descending/i, "Difference between ascending and descending pass brightness.", "Blue/red = one pass brighter than the other. Mostly slope and shadow effects."],
  [/combined/i, "Ascending and descending merged to fill gaps.", "Grey scale backscatter with fewer holes than either pass."],
  [/change \(db\)/i, "Brightness change between the two dates.", "Blue = darker after, red = brighter after, white = unchanged."],
  [/backscatter|amplitude|temporal average|sigma/i, "Radar brightness of the ground.", "Dark = water, smooth or shadowed surfaces. Mid-grey = vegetation and soil. Bright = buildings, rocks, steep slopes facing the radar."],
];
export function explainImage(im) {
  const hit = FIG.find(([re]) => re.test(im.name));
  const range = im.legend ? `Colour scale: ${Number(im.legend.min).toFixed(1)} to ${Number(im.legend.max).toFixed(1)} ${im.legend.unit}.` : "";
  const h = im.hist;
  let spread = "";
  if (h && im.legend && h.counts?.length) {
    const tot = h.counts.reduce((a, b) => a + b, 0) || 1;
    const peak = h.counts.indexOf(Math.max(...h.counts));
    const at = h.min + ((peak + 0.5) / h.counts.length) * (h.max - h.min);
    const top = Math.max(...h.counts) / tot;
    spread = `Most pixels sit near ${f1(at)}${im.legend?.unit ? " " + im.legend.unit : ""}${top > 0.25 ? ", in one dominant peak, so the area is fairly uniform." : ", spread over a broad range, so the area is mixed."}`;
  }
  return { shows: hit ? hit[1] : "An image produced by the analysis.", reading: hit ? hit[2] : "Use the colour scale under the image to read values.", range, spread };
}

// ---------- charts ----------
export function explainSeries(group) {
  const s = group[0];
  if (!s || !s.x?.length) return "";
  if (s.kind === "scatter") return "Each dot is one pixel. A tight diagonal cloud means the two quantities move together; a round cloud means no relationship.";
  const ys = s.y.filter((y) => y !== null && Number.isFinite(y));
  if (ys.length < 2) return "";
  const lab = (i) => (s.labels ? s.labels[i] : f1(s.x[i]));
  const first = ys[0], last = ys[ys.length - 1];
  const iMin = s.y.indexOf(Math.min(...ys)), iMax = s.y.indexOf(Math.max(...ys));
  const unit = (s.ylabel || "").replace(/^.*\(/, "").replace(/\).*$/, "");
  const d = last - first;
  const span = Math.max(...ys) - Math.min(...ys);
  const trend = span < 1e-9 || Math.abs(d) < span * 0.15 ? "stays roughly level" : d > 0 ? "rises" : "falls";
  return `${sentence(s.name.split(":")[0])} ${trend} from ${f1(first)} to ${f1(last)}${unit && unit !== s.ylabel ? " " + unit : ""}. Lowest on ${lab(iMin)} (${f1(s.y[iMin])}), highest on ${lab(iMax)} (${f1(s.y[iMax])}). Sudden steps usually mark an event (rain, flood, harvest, clearing); a slow drift is a trend or a season.`;
}

// ---------- overall reading ----------
const NEXT = {
  flood: ["Check the flooded area against an optical image or a flood bulletin for the same dates.", "Re-run with a DEM file to remove radar-shadow false positives on slopes."],
  gcov_change: ["Open the change map on the 3D map to see whether changes follow terrain, fields or roads.", "Compare with rainfall: wet soil raises the backscatter without any real land change."],
  deforest: ["Overlay the loss patches on optical imagery before reporting them.", "Add a third date to check the loss persists."],
  coherence_change: ["Compare with a damage assessment or flood extent for the same event.", "Try a different reference pair if the reference coherence was low."],
  vertical_ew: ["Verify with GNSS stations if any exist nearby.", "Repeat with another date pair to confirm the pattern."],
  velocity: ["Add more dates: a longer record shrinks the velocity error.", "Check the misfit map and move the reference point if it sits on moving ground."],
  first_change: ["Plot a time series on one changed spot to see what happened there.", "Compare the event dates with weather and local activity."],
  default: ["Run another extra analysis on the same window and compare.", "Add granules to the workbench to follow the place through time."],
};

export function interpret(res) {
  const items = (res.metrics || []).map((m) => {
    const v = num(m.value);
    let out = null;
    for (const [re, fn] of R) {
      if (re.test(m.label)) { try { out = fn(m, v, m.label); } catch { out = null; } break; }
    }
    return out || { what: "A measurement from this analysis.", read: m.note || "See the guide for how it is calculated.", level: "info" };
  });

  const stories = items.map((it, i) => ({ ...it.story, level: it.level, m: res.metrics[i] })).filter((s) => s.text);
  stories.sort((a, b) => (b.p || 0) - (a.p || 0));
  const top = stories.find((s) => s.head && s.head(num(s.m.value)[0] ?? 0)) || null;
  const headline = top ? top.head(num(top.m.value)[0] ?? 0) : `${res.product}: ${items.length} measurements, read below`;
  const levels = items.map((i) => i.level);
  const tone = levels.includes("alert") ? "alert" : levels.includes("watch") ? "watch" : top && top.level === "good" ? "good" : "info";

  const points = stories.filter((s) => s !== top).slice(0, 6).map((s) => s.text);
  const caveats = [];
  if (res.demo) caveats.push("These numbers come from synthetic demo data and say nothing about the real world.");
  caveats.push("Thresholds used to explain the numbers (for example −18 dB for water, coherence 0.6 and 0.3) are rules of thumb, not official NASA values: confirm important findings with another source.");
  if (items.some((i, k) => /Velocity uncertainty/.test(res.metrics[k].label))) caveats.push("The velocity uncertainty counts only noise from the pair weights; atmosphere and unwrapping errors make the real error larger.");
  if (res.metrics.some((m) => /relative/i.test(m.note || m.label))) caveats.push("Displacements are relative to a reference level; a global offset is not ground motion.");
  const next = NEXT[res.mode] || NEXT.default;
  return { headline, tone, points, items, caveats, next };
}

export const LEVEL_LABEL = { good: "Reassuring", info: "For information", watch: "Worth checking", alert: "Significant" };

// compact text version of a result, given to the AI assistant as context
export function digest(res, it) {
  const lines = [
    `Analysis: ${res.product}${res.mode ? ` (${res.mode})` : ""}${res.demo ? " [synthetic demo data]" : ""}`,
    res.window ? `Window: ${res.window.cols}x${res.window.rows} px${res.window.pixel_size_m ? `, ~${Math.round(res.window.pixel_size_m)} m per pixel` : ""}` : "",
    `Headline: ${it.headline}`,
    ...it.points.map((p) => `Key point: ${p}`),
    "Measurements (label: value -> plain reading):",
    ...res.metrics.slice(0, 40).map((m, i) => `- ${m.label}: ${m.value} -> ${it.items[i].read}`),
    ...(res.images || []).slice(0, 10).map((im) => `Image: ${im.name}${im.legend ? ` (${Number(im.legend.min).toFixed(1)} to ${Number(im.legend.max).toFixed(1)} ${im.legend.unit})` : ""}`),
    ...(res.notes || []).slice(0, 6).map((n) => `Note: ${n}`),
  ];
  return lines.filter(Boolean).join("\n").slice(0, 6000);
}
