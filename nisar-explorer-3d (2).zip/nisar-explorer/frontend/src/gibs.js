// NASA GIBS NISAR backscatter (GCOV false colour). Uses WMS so no tile-matrix guessing is needed.
export const BS_LAYER = "NISAR_L2_Geocoded_Polarimetric_Covariance";
export const BS_LAYER_12D = BS_LAYER + "_12Day"; // NASA's own rolling 12-day composite (the one Worldview offers)
const WMS = "https://gibs.earthdata.nasa.gov/wms/epsg3857/best/wms.cgi";
const WORLD = "-20037508.34,-20037508.34,20037508.34,20037508.34";

const params = (layer, date, bbox) =>
  `SERVICE=WMS&REQUEST=GetMap&VERSION=1.3.0&LAYERS=${layer}&STYLES=&FORMAT=image/png&TRANSPARENT=TRUE` +
  `&CRS=EPSG:3857&WIDTH=256&HEIGHT=256&TIME=${date}&BBOX=${bbox}`;

// MapLibre fills in {bbox-epsg-3857} for every tile
export const bsTileUrl = (date, composite = false) =>
  `${WMS}?${params(composite ? BS_LAYER_12D : BS_LAYER, date, "{bbox-epsg-3857}")}`;

const iso = (d) => d.toISOString().slice(0, 10);

// does GIBS have any NISAR pixels for this UTC day? (draws a whole-world image and looks for non-transparent pixels)
export async function hasData(date, composite = false) {
  const res = await fetch(`${WMS}?${params(composite ? BS_LAYER_12D : BS_LAYER, date, WORLD)}`);
  if (!res.ok || !(res.headers.get("Content-Type") || "").startsWith("image/")) throw new Error(`GIBS returned ${res.status}`);
  const bmp = await createImageBitmap(await res.blob());
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0, 256, 256);
  const px = ctx.getImageData(0, 0, 256, 256).data;
  for (let i = 3; i < px.length; i += 4) if (px[i] > 0) return true;
  return false;
}

// walk back from today until a day has data
export async function findLatestDate(maxBack = 30, composite = false) {
  for (let i = 0; i <= maxBack; i++) {
    const date = iso(new Date(Date.now() - i * 864e5));
    if (await hasData(date, composite)) return date;
  }
  return null;
}

// which of these days have any imagery? -> [[date, true|false|null(error)], ...]
export const dayCoverage = (dates) =>
  Promise.all(dates.map((d) => hasData(d).then((v) => [d, v]).catch(() => [d, null])));

// Optical and rainfall context layers (visual comparison only)
export const CONTEXT_LAYERS = [
  { id: "MODIS_Terra_CorrectedReflectance_TrueColor", label: "MODIS Terra true colour (optical)", fmt: "image/jpeg" },
  { id: "VIIRS_SNPP_CorrectedReflectance_TrueColor", label: "VIIRS true colour (optical)", fmt: "image/jpeg" },
  { id: "IMERG_Precipitation_Rate", label: "IMERG rainfall rate", fmt: "image/png" },
];
export const contextTileUrl = (layer, date) => {
  const L = CONTEXT_LAYERS.find((c) => c.id === layer);
  return `${WMS}?SERVICE=WMS&REQUEST=GetMap&VERSION=1.3.0&LAYERS=${layer}&STYLES=&FORMAT=${L?.fmt || "image/png"}&TRANSPARENT=${L?.fmt === "image/png" ? "TRUE" : "FALSE"}` +
    `&CRS=EPSG:3857&WIDTH=256&HEIGHT=256&TIME=${date}&BBOX={bbox-epsg-3857}`;
};
