// Finding "before" and "after" NISAR files for a flood or earthquake.
// A usable pair comes from the SAME track, frame and flight direction (otherwise the two images do not line up):
// the last acquisition before the event and the first one on or after it.
const DAY = 864e5;
const pad = (n) => String(n).padStart(2, "0");
export const isoMinute = (ms) => { const d = new Date(ms); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; };

// the period to search: some time before the event and some after it
export function eventRange(ev, wide = false) {
  const t = Date.parse(ev.time);
  const b = wide ? 180 : 90, a = wide ? 120 : 45;
  return { start: `${isoMinute(t - b * DAY).slice(0, 10)}T00:00`, end: `${isoMinute(t + a * DAY).slice(0, 10)}T23:59` };
}

function inRing(x, y, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i], [xj, yj] = ring[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
export function covers(feature, lon, lat) {
  const g = feature?.geometry;
  if (!g) return false;
  const polys = g.type === "Polygon" ? [g.coordinates] : g.type === "MultiPolygon" ? g.coordinates : [];
  return polys.some((p) => p[0] && inRing(lon, lat, p[0]));
}

const dkey = (p) => [p.pathNumber, p.frameNumber, String(p.flightDirection || "").toUpperCase()].join("|");

// pairs for one product level, best first: files that cover the event, then the smallest gaps
export function suggestPairs(ev, granules, level) {
  const t = Date.parse(ev.time);
  const groups = new Map();
  for (const g of granules) {
    const p = g.properties || {};
    if (level && p.processingLevel !== level) continue;
    const ts = Date.parse(p.startTime);
    if (!Number.isFinite(ts)) continue;
    const k = dkey(p);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push({ g, ts });
  }
  const out = [];
  for (const [key, list] of groups) {
    const before = list.filter((x) => x.ts < t).sort((a, b) => b.ts - a.ts)[0];
    const after = list.filter((x) => x.ts >= t).sort((a, b) => a.ts - b.ts)[0];
    if (!before || !after) continue;
    const p = after.g.properties;
    const gapBefore = (t - before.ts) / DAY, gapAfter = (after.ts - t) / DAY;
    const cov = covers(before.g, ev.lon, ev.lat) && covers(after.g, ev.lon, ev.lat);
    out.push({ key, track: p.pathNumber, frame: p.frameNumber, direction: String(p.flightDirection || "").toLowerCase(), before: before.g, after: after.g, gapBefore, gapAfter, covers: cov, score: (cov ? 0 : 1000) + gapBefore + gapAfter });
  }
  return out.sort((a, b) => a.score - b.score);
}

// how many files exist on each side, to explain an empty result
export function sideCounts(ev, granules, level) {
  const t = Date.parse(ev.time);
  let before = 0, after = 0;
  for (const g of granules) {
    if (level && g.properties?.processingLevel !== level) continue;
    const ts = Date.parse(g.properties?.startTime);
    if (!Number.isFinite(ts)) continue;
    if (ts < t) before += 1; else after += 1;
  }
  return { before, after };
}

// the workbench analysis that fits the event and the product
export function modeFor(ev, level) {
  if (level === "GSLC") return "gslc_change";
  return ev.type === "flood" ? "flood" : "gcov_change";
}

export const fmtGap = (d) => (d < 1 ? "same day" : `${Math.round(d)} day${Math.round(d) === 1 ? "" : "s"}`);

function geomBbox(g) {
  const pts = [];
  const walk = (c) => (typeof c[0] === "number" ? pts.push(c) : c.forEach(walk));
  if (g?.coordinates) walk(g.coordinates);
  if (!pts.length) return null;
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

// the area to analyse: the event area cut down to what BOTH files really contain.
// null means "use the centre of the files" (demo files, or no useful overlap).
export function analysisArea(ev, before, after) {
  if (before?.properties?._demo || after?.properties?._demo) return null;
  const boxes = [ev.bbox, geomBbox(before?.geometry), geomBbox(after?.geometry)];
  if (boxes.some((b) => !b)) return null;
  const w = Math.max(...boxes.map((b) => b[0])), s = Math.max(...boxes.map((b) => b[1]));
  const e = Math.min(...boxes.map((b) => b[2])), n = Math.min(...boxes.map((b) => b[3]));
  if (e - w < 0.02 || n - s < 0.02) return null;
  const r = (x) => Math.round(x * 1000) / 1000;
  return [r(w), r(s), r(e), r(n)];
}
