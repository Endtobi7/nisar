import { useState } from "react";
import { downloadUrl, browseUrl } from "./api.js";
import { byCode } from "./products.js";
import AnalysisPanel from "./AnalysisPanel.jsx";

const fmtBytes = (b) => (b >= 1e9 ? (b / 1e9).toFixed(2) + " GB" : b >= 1e6 ? (b / 1e6).toFixed(0) + " MB" : b ? b + " B" : "–");
const totalBytes = (p) =>
  p.bytes && typeof p.bytes === "object" ? Object.values(p.bytes).reduce((a, x) => a + (x.bytes || 0), 0) : 0;
const list = (v) => (Array.isArray(v) ? v.join(", ") : v);

export default function Detail({ feature, onClose, auth, onNeedLogin, browseOn, browseBusy, browseMsg, onToggleBrowse, onShowBackscatter, drawnBbox, onProjectAnalysis, projectedIds, inBasket, onBasket, inspecting, onInspect, onDone }) {
  const [copied, setCopied] = useState(false);
  if (!feature) return null;
  const p = feature.properties;
  const rows = [
    ["Product", p.processingLevel],
    ["Start (UTC)", p.startTime],
    ["Stop (UTC)", p.stopTime],
    ["Orbit", p.flightDirection],
    ["Track / frame", `${p.pathNumber ?? "–"} / ${p.frameNumber ?? "–"}`],
    ["Polarization", list(p.mainBandPolarization)],
    ["Data maturity", p.dataMaturity],
    ["Pipeline", p.productionConfiguration],
    ["Frame coverage", p.frameCoverage],
    ["Size", fmtBytes(totalBytes(p))],
  ].filter(([, v]) => v && v !== "– / –");
  const browse = Array.isArray(p.browse) ? p.browse[0] : null;
  const info = byCode(p.processingLevel);

  const copy = async () => {
    try { await navigator.clipboard.writeText(location.href); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { /* ignore */ }
  };

  return (
    <aside className="detail" aria-label="Granule details">
      <header>
        <h2>{p.processingLevel} granule</h2>
        <button className="x" onClick={onClose} aria-label="Close details">×</button>
      </header>
      <p className="scene">{p.sceneName}</p>
      {browse && <img className="browse" src={browse} alt="Browse preview of the granule" loading="lazy" onError={(e) => { const el = e.currentTarget; if (!el.dataset.fb) { el.dataset.fb = "1"; el.src = browseUrl(browse, auth?.sid); } else el.style.display = "none"; }} />}
      <dl>
        {rows.map(([k, v]) => (<div key={k}><dt>{k}</dt><dd>{v}</dd></div>))}
      </dl>
      {p._demo && <p className="note">Demo data. Not a real NISAR product.</p>}
      {browseMsg && <p className="err" role="alert">{browseMsg}{browse === null && p.browse?.[0] && <> <a href={p.browse[0]} target="_blank" rel="noreferrer">Open the image link directly</a></>}</p>}
      {!browse && !p._demo && <p className="hint">No browse image is published for this granule. Use “Backscatter for this date” to see the radar image on the map.</p>}
      {browse && <p className="hint">Placement is exact when the granule’s KML file is found, otherwise approximate.</p>}
      {!p._demo && <p className="hint">Files are large (often several GB). The download streams through your backend.</p>}
      {info && (
        <details className="info" open>
          <summary>{info.name}</summary>
          {info.group === "radar" && <p className="note">Radar coordinates: the footprint is shown, but the file itself cannot be overlaid on a map without SAR software.</p>}
          <p className="plabel">Inside</p>
          <ul>{info.contains.map((c) => <li key={c}>{c}</li>)}</ul>
          <p className="plabel">You can extract</p>
          <ul>{info.extract.map((c) => <li key={c}>{c}</li>)}</ul>
          {info.pair && <p className="hint">Pair product: built from two acquisitions.</p>}
        </details>
      )}
      <AnalysisPanel key={p._id} feature={feature} auth={auth} drawnBbox={drawnBbox} onNeedLogin={onNeedLogin} onProject={onProjectAnalysis} projectedIds={projectedIds} inBasket={inBasket} onBasket={onBasket} inspecting={inspecting} onInspect={onInspect} onDone={onDone} />
      <div className="actions">
        {browse && <button className="btn" onClick={onToggleBrowse} disabled={browseBusy} aria-pressed={browseOn}>{browseBusy ? "Loading image…" : browseOn ? "Remove image from map" : "Project image on map"}</button>}
        {!p._demo && p.startTime && <button className="btn" onClick={() => onShowBackscatter(feature)}>Backscatter for this date</button>}
        {p._demo ? null : p.url && auth ? (
          <a className="btn solid" href={downloadUrl(auth.sid, p.url)}>Download file</a>
        ) : p.url ? (
          <button className="btn solid" onClick={onNeedLogin}>Sign in to download</button>
        ) : null}
        <button className="btn" onClick={copy}>{copied ? "Link copied" : "Copy share link"}</button>
      </div>
    </aside>
  );
}
