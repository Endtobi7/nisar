// floating toolbar over the map: basemap, 3D terrain, relief exaggeration, camera shortcuts
const BASES = [["dark", "Dark"], ["osm", "Streets"], ["sat", "Satellite"]];

export default function MapToolbar({ view3d, setView3d, onCmd, demIssue }) {
  const set = (patch) => setView3d({ ...view3d, ...patch });
  return (
    <div className="maptools" role="toolbar" aria-label="Map view">
      <div className="seg" role="group" aria-label="Basemap">
        {BASES.map(([k, l]) => (
          <button key={k} className={view3d.basemap === k ? "on" : ""} aria-pressed={view3d.basemap === k} onClick={() => set({ basemap: k })}>{l}</button>
        ))}
      </div>
      <button className={view3d.globe ? "tool on" : "tool"} aria-pressed={view3d.globe} onClick={() => set({ globe: !view3d.globe })} title="Show the Earth as a sphere. It flattens into the normal map as you zoom in.">Globe</button>
      <button className={view3d.terrain ? "tool on" : "tool"} aria-pressed={view3d.terrain} onClick={() => set({ terrain: !view3d.terrain })} title="Show the ground relief in 3D. Hold the right mouse button (or Ctrl + drag) to tilt and rotate.">3D terrain</button>
      {view3d.terrain && (
        <label className="relief" title="Exaggerate the relief to see small hills">
          <span>Relief ×{view3d.exaggeration.toFixed(1)}</span>
          <input type="range" min="1" max="4" step="0.1" value={view3d.exaggeration} onChange={(e) => set({ exaggeration: +e.target.value })} aria-label="Relief exaggeration" />
        </label>
      )}
      <button className="tool" onClick={() => onCmd("spin")} title="Turn the view by 90°">Rotate</button>
      <button className="tool" onClick={() => onCmd("flat")} title="Look straight down, north up">Top view</button>
      <button className="tool" onClick={() => onCmd("fit")} title="Zoom to all results">Fit results</button>
      {demIssue && <span className="toolwarn" role="alert">Elevation tiles could not load, so the map was set back to flat. Check your connection, then press 3D terrain again.</span>}
    </div>
  );
}
