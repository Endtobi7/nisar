import { mockSearch, mockEvents } from "./mock.js";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

// accepts "YYYY-MM-DD" or "YYYY-MM-DDTHH:MM" (UTC)
const toIso = (s, endOfDay) => (s.length === 10 ? `${s}T${endOfDay ? "23:59:59" : "00:00:00"}` : s.length === 16 ? `${s}:${endOfDay ? "59" : "00"}` : s) + "Z";

// the time window as milliseconds (UTC); open-ended when a field is empty
export const timeWindow = (f) => [f.start ? Date.parse(toIso(f.start, false)) : -Infinity, f.end ? Date.parse(toIso(f.end, true)) : Infinity];

export async function searchNisar(f) {
  if (f.mock) return mockSearch(f);
  const q = new URLSearchParams();
  if (f.bbox) q.set("bbox", f.bbox.join(","));
  if (f.start) q.set("start", toIso(f.start, false));
  if (f.end) q.set("end", toIso(f.end, true));
  if (f.levels.length) q.set("level", f.levels.join(","));
  if (f.direction) q.set("direction", f.direction);
  q.set("limit", "250");
  const res = await fetch(`${API}/api/search?${q}`);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Search failed (${res.status})`);
  }
  return res.json();
}

export const apiUrl = API;

async function call(path, opts) {
  const res = await fetch(`${API}${path}`, opts);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.detail || `Request failed (${res.status})`);
  return body;
}

export const login = (creds) =>
  call("/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(creds) });
export const whoami = (sid) => call(`/api/me?sid=${encodeURIComponent(sid)}`);
export const logout = (sid) => call(`/api/logout?sid=${encodeURIComponent(sid)}`, { method: "POST" }).catch(() => {});
export const downloadUrl = (sid, url) => `${API}/api/download?sid=${encodeURIComponent(sid)}&url=${encodeURIComponent(url)}`;
export const browseUrl = (url, sid) => `${API}/api/browse?url=${encodeURIComponent(url)}${sid ? `&sid=${encodeURIComponent(sid)}` : ""}`;

// ASF sometimes serves browse PNGs as binary/octet-stream, so identify images by their first bytes.
async function asImage(blob) {
  const h = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
  const is = (...b) => b.every((v, i) => h[i] === v);
  const type = is(0x89, 0x50, 0x4e, 0x47) ? "image/png"
    : is(0xff, 0xd8, 0xff) ? "image/jpeg"
    : is(0x47, 0x49, 0x46) ? "image/gif"
    : is(0x52, 0x49, 0x46, 0x46) && h[8] === 0x57 && h[9] === 0x45 ? "image/webp"
    : null;
  return type ? (blob.type === type ? blob : new Blob([blob], { type })) : null;
}

// Browse images are public, so try the browser first; fall back to the backend (works around missing CORS headers).
export async function fetchBrowse(src, sid) {
  try {
    const r = await fetch(src);
    if (r.ok) {
      const img = await asImage(await r.blob());
      if (img) return img;
    }
  } catch { /* usually CORS: use the backend */ }
  const res = await fetch(browseUrl(src, sid));
  if (!res.ok) {
    const b = await res.json().catch(() => ({}));
    const err = new Error(b.detail || `Could not load the browse image (HTTP ${res.status}).`);
    err.status = res.status;
    err.detail = b.detail;
    throw err;
  }
  const img = await asImage(await res.blob());
  if (!img) throw new Error("The server returned data that is not an image.");
  return img;
}

// small text sidecar files (KML): direct first, backend fallback
export async function fetchText(url, sid) {
  try {
    const r = await fetch(url);
    if (r.ok) return await r.text();
  } catch { /* usually CORS */ }
  const res = await fetch(`${API}/api/text?url=${encodeURIComponent(url)}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.text();
}

// ---- analysis endpoints (the backend streams small windows of the HDF5 files) ----
async function getJson(path, params) {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== "") q.set(k, Array.isArray(v) ? v.join(",") : typeof v === "object" ? JSON.stringify(v) : String(v)); });
  const res = await fetch(`${API}${path}?${q}`);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const e = new Error(body.detail || `Request failed (HTTP ${res.status}).`);
    e.status = res.status;
    e.detail = body.detail;
    throw e;
  }
  return body;
}

export const catalog = () => getJson("/api/catalog", {});
export const analyse = ({ url, sid, bbox, level, baselineDays, demo, want, params }) =>
  getJson("/api/analyse", { url, sid, bbox, level, baseline_days: baselineDays || 12, want, params: params && Object.keys(params).length ? params : undefined, demo: demo && !url ? "true" : undefined });
export const compare = ({ urlA, urlB, mode, sid, bbox, baselineDays, params }) =>
  getJson("/api/compare", { url_a: urlA, url_b: urlB, mode, sid, bbox, baseline_days: baselineDays || 12, params: params && Object.keys(params).length ? params : undefined });
export const runSeries = ({ urls, times, mode, sid, bbox, baselineDays, params }) =>
  getJson("/api/series", { urls, times, mode, sid, bbox, baseline_days: baselineDays || 12, params: params && Object.keys(params).length ? params : undefined });
export const pixelInfo = ({ url, lon, lat, sid, level }) => getJson("/api/pixel", { url, lon, lat, sid, level });
export const exportUrl = (rid, image, fmt) => `${API}/api/export?rid=${encodeURIComponent(rid)}&image=${encodeURIComponent(image)}&fmt=${fmt}`;

// Nisa, the AI assistant (the key lives on the server; this only asks the backend)
export async function nisaStatus() {
  try {
    const r = await fetch(`${API}/api/nisa/status`);
    if (!r.ok) return { enabled: false };
    return await r.json();
  } catch {
    return { enabled: false };
  }
}

export async function askNisa({ messages, context }) {
  const r = await fetch(`${API}/api/nisa`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ messages, context }) });
  if (!r.ok) {
    let d = "";
    try { d = (await r.json()).detail; } catch { /* ignore */ }
    throw new Error(d || `Assistant error ${r.status}`);
  }
  return (await r.json()).reply;
}

// floods and earthquakes from public feeds (USGS, GDACS, NASA EONET), or synthetic ones in demo mode
export async function fetchEvents({ types, start, end, minmag, mock }) {
  if (mock) {
    const ev = mockEvents({ types, minmag }).filter((e) => (!start || e.time.slice(0, 10) >= start) && (!end || e.time.slice(0, 10) <= end));
    return { events: ev.sort((a, b) => b.time.localeCompare(a.time)), warnings: [], sources: ["Demo"] };
  }
  const q = new URLSearchParams({ types: types.join(","), minmag: String(minmag) });
  if (start) q.set("start", start);
  if (end) q.set("end", end);
  const r = await fetch(`${API}/api/events?${q}`);
  if (!r.ok) {
    const b = await r.json().catch(() => ({}));
    throw new Error(b.detail || `Events failed (${r.status})`);
  }
  return r.json();
}
