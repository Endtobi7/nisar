import { GROUPS, PRODUCTS } from "./products.js";

const bboxText = (b) => (b ? `${b[0].toFixed(2)}, ${b[1].toFixed(2)} → ${b[2].toFixed(2)}, ${b[3].toFixed(2)}` : "Whole world");

const pad = (n) => String(n).padStart(2, "0");
const offsetText = () => { const m = -new Date().getTimezoneOffset(); return `UTC${m >= 0 ? "+" : "-"}${Math.floor(Math.abs(m) / 60)}${Math.abs(m) % 60 ? ":" + pad(Math.abs(m) % 60) : ""}`; };
const iso16 = (d) => d.toISOString().slice(0, 16);

export default function Filters({ filters, setFilters, drawing, setDrawing, onSearch, loading }) {
  const set = (patch) => setFilters({ ...filters, ...patch });
  const invalid = !!(filters.start && filters.end && filters.start > filters.end);
  const lastDays = (n) => set({ start: iso16(new Date(Date.now() - n * 864e5)), end: iso16(new Date()).slice(0, 11) + "23:59" });
  const toggleLevel = (l) =>
    set({ levels: filters.levels.includes(l) ? filters.levels.filter((x) => x !== l) : [...filters.levels, l] });

  return (
    <section className="filters" aria-label="Search filters">
      <div className="field">
        <span className="label">Area</span>
        <div className="aoi">
          <span className="aoi-text">{bboxText(filters.bbox)}</span>
          <button type="button" className={drawing ? "btn on" : "btn"} onClick={() => setDrawing(!drawing)}>
            {drawing ? "Drag on map…" : "Draw box"}
          </button>
          {filters.bbox && (
            <button type="button" className="btn ghost" onClick={() => set({ bbox: null })}>Clear</button>
          )}
        </div>
      </div>

      <div className="row">
        <label className="field">
          <span className="label">From (UTC)</span>
          <input type="datetime-local" value={filters.start} onChange={(e) => set({ start: e.target.value })} aria-invalid={invalid} />
        </label>
        <label className="field">
          <span className="label">To (UTC)</span>
          <input type="datetime-local" value={filters.end} onChange={(e) => set({ end: e.target.value })} aria-invalid={invalid} />
        </label>
      </div>

      <div className="presets">
        <button type="button" className="chip" onClick={() => lastDays(12)}>Last 12 days</button>
        <button type="button" className="chip" onClick={() => lastDays(30)}>Last 30 days</button>
        <button type="button" className="chip" onClick={() => set({ start: "2026-06-17T00:00", end: iso16(new Date()).slice(0, 11) + "23:59" })}>Since 17 June 2026</button>
      </div>
      {invalid ? <p className="err" role="alert">The start is after the end. Swap the two dates.</p> : <p className="hint">Times are UTC (your computer is {offsetText()}). A granule is kept when its start time falls inside the window.</p>}

      <label className="field">
        <span className="label">Match granules</span>
        <select value={filters.timeMode} onChange={(e) => set({ timeMode: e.target.value })}>
          <option value="start">that start inside the window (recommended)</option>
          <option value="overlap">whose time span touches the window (pair products span 12+ days)</option>
        </select>
      </label>

      <div className="field">
        <span className="label">Product type</span>
        {GROUPS.map((g) => (
          <div key={g.id} className="pgroup">
            <span className="hint">{g.title}</span>
            <div className="chips">
              {PRODUCTS.filter((p) => p.group === g.id).map((p) => (
                <button key={p.code} type="button" title={p.name} className={filters.levels.includes(p.code) ? "chip on" : "chip"} aria-pressed={filters.levels.includes(p.code)} onClick={() => toggleLevel(p.code)}>
                  {p.code}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="row">
        <label className="field">
          <span className="label">Orbit</span>
          <select value={filters.direction} onChange={(e) => set({ direction: e.target.value })}>
            <option value="">Any</option>
            <option value="ASCENDING">Ascending</option>
            <option value="DESCENDING">Descending</option>
          </select>
        </label>
        <label className="check">
          <input type="checkbox" checked={filters.mock} onChange={(e) => set({ mock: e.target.checked })} />
          Demo data (no backend)
        </label>
      </div>

      <button type="button" className="search" onClick={() => onSearch()} disabled={loading || !filters.levels.length || invalid}>
        {loading ? "Searching…" : "Search NISAR"}
      </button>
    </section>
  );
}
