import { describe, expect, it } from "vitest";
import { analysisArea, covers, eventRange, modeFor, sideCounts, suggestPairs } from "./eventPairs.js";

const sq = (lon, lat, r = 1) => ({ type: "Polygon", coordinates: [[[lon - r, lat - r], [lon + r, lat - r], [lon + r, lat + r], [lon - r, lat + r], [lon - r, lat - r]]] });
const g = (day, { track = 82, frame = 100, dir = "ASCENDING", level = "GCOV", lon = 0, lat = 0, r = 1 } = {}) => ({
  geometry: sq(lon, lat, r),
  properties: { startTime: `2026-08-${String(day).padStart(2, "0")}T06:00:00Z`, pathNumber: track, frameNumber: frame, flightDirection: dir, processingLevel: level, _id: `${level}-${track}-${frame}-${dir}-${day}` },
});
const ev = { type: "flood", time: "2026-08-15T00:00:00Z", lon: 0, lat: 0 };

describe("event before/after pairs", () => {
  it("takes the last file before and the first on or after the event, same track/frame/direction", () => {
    const list = [g(1), g(8), g(13), g(19), g(25)];
    const [p] = suggestPairs(ev, list, "GCOV");
    expect(p.before.properties.startTime).toContain("08-13");
    expect(p.after.properties.startTime).toContain("08-19");
    expect(p.gapBefore).toBeCloseTo(1.75, 1);
    expect(p.covers).toBe(true);
  });
  it("never mixes tracks, frames or directions", () => {
    const list = [g(13, { track: 82 }), g(19, { track: 119 }), g(14, { frame: 101 }), g(20, { dir: "DESCENDING" })];
    expect(suggestPairs(ev, list, "GCOV")).toEqual([]);
    expect(sideCounts(ev, list, "GCOV")).toEqual({ before: 2, after: 2 });
  });
  it("keeps products apart", () => {
    const list = [g(13, { level: "GCOV" }), g(19, { level: "GSLC" })];
    expect(suggestPairs(ev, list, "GCOV")).toEqual([]);
    expect(suggestPairs(ev, list, "GSLC")).toEqual([]);
  });
  it("ranks files that cover the event first, even with bigger gaps", () => {
    const list = [g(14, { track: 1, lon: 40 }), g(16, { track: 1, lon: 40 }), g(5, { track: 2 }), g(30, { track: 2 })];
    const out = suggestPairs(ev, list, "GCOV");
    expect(out.map((p) => p.track)).toEqual([2, 1]);
    expect(out[0].covers).toBe(true);
    expect(out[1].covers).toBe(false);
  });
  it("an acquisition on the event date counts as after", () => {
    const list = [g(10), { ...g(15), properties: { ...g(15).properties, startTime: "2026-08-15T00:00:00Z" } }];
    expect(suggestPairs(ev, list, "GCOV")[0].after.properties.startTime).toContain("08-15");
  });
  it("point in footprint", () => {
    expect(covers(g(1), 0.5, 0.5)).toBe(true);
    expect(covers(g(1), 2, 0)).toBe(false);
    expect(covers({ geometry: null }, 0, 0)).toBe(false);
  });
  it("search range and analysis mode", () => {
    expect(eventRange(ev)).toEqual({ start: "2026-05-17T00:00", end: "2026-09-29T23:59" });
    expect(eventRange(ev, true).start < eventRange(ev).start).toBe(true);
    expect(modeFor(ev, "GCOV")).toBe("flood");
    expect(modeFor({ type: "earthquake" }, "GCOV")).toBe("gcov_change");
    expect(modeFor(ev, "GSLC")).toBe("gslc_change");
  });
  it("analysis area is the event area cut to both files", () => {
    const e = { ...ev, bbox: [-0.5, -0.5, 1.5, 0.5] };
    expect(analysisArea(e, g(13, { lon: 0, r: 1 }), g(19, { lon: 0.4, r: 1 }))).toEqual([-0.5, -0.5, 1, 0.5]);
    expect(analysisArea(e, g(13, { lon: 40 }), g(19, { lon: 40 }))).toBeNull();
    const demo = { ...g(13), properties: { ...g(13).properties, _demo: true } };
    expect(analysisArea(e, demo, g(19))).toBeNull();
  });
});
