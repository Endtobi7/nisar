// Demo footprints so the UI works without the backend (tick "Demo data").
// Mimics NISAR: 12-day repeat, slanted frames, ascending and descending tracks.
const rng = (seed) => () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);

function frame(lng, lat, dir) {
  const w = 1.9, h = 2.3, slant = dir === "ASCENDING" ? 0.5 : -0.5;
  return [
    [lng, lat],
    [lng + w, lat + slant * 0.4],
    [lng + w + slant * 0.5, lat + h],
    [lng + slant * 0.5, lat + h - slant * 0.4],
    [lng, lat],
  ];
}

export function mockSearch(f) {
  const [w, s, e, n] = f.bbox || [-14, 24, 6, 38];
  const rand = rng(42);
  const levels = f.levels.length ? f.levels : ["GCOV"];
  const feats = [];
  const t0 = new Date("2026-06-17T00:00:00Z").getTime();
  const tracks = [
    { dir: "ASCENDING", path: 82, lng: w + (e - w) * 0.25, lat: s + (n - s) * 0.2, hour: 18 },
    { dir: "DESCENDING", path: 119, lng: w + (e - w) * 0.55, lat: s + (n - s) * 0.1, hour: 6 },
  ];
  for (const t of tracks) {
    for (let k = 0; k < 10; k++) {
      const start = new Date(t0 + k * 12 * 864e5 + t.hour * 36e5 + (t.dir === "ASCENDING" ? 0 : 3 * 864e5));
      const ts = start.toISOString().slice(0, 16);
      const lo = f.start.length === 10 ? `${f.start}T00:00` : f.start;
      const hi = f.end.length === 10 ? `${f.end}T23:59` : f.end;
      if (ts < lo || ts > hi) continue;
      if (f.direction && f.direction !== t.dir) continue;
      for (let j = 0; j < 3; j++) {
        const lat = t.lat + j * 2.1 + rand() * 0.1;
        const level = levels[(k + j) % levels.length];
        const stop = new Date(start.getTime() + 25e3);
        const stamp = start.toISOString().replace(/[-:]/g, "").slice(0, 15);
        const name = `NISAR_L2_PR_${level}_${String(k + 1).padStart(3, "0")}_${t.path}_${t.dir[0]}_${String(j + 1).padStart(3, "0")}_DEMO_${stamp}`;
        feats.push({
          type: "Feature",
          geometry: { type: "Polygon", coordinates: [frame(t.lng, lat, t.dir)] },
          properties: {
            sceneName: name,
            fileName: name + ".h5",
            startTime: start.toISOString(),
            stopTime: stop.toISOString(),
            processingLevel: level,
            flightDirection: t.dir,
            pathNumber: t.path,
            frameNumber: 100 + j,
            mainBandPolarization: ["HH", "HV"],
            productionConfiguration: "PR",
            dataMaturity: "PROVISIONAL",
            bytes: { [name + ".h5"]: { bytes: 2.4e9 + rand() * 1.5e9, format: "HDF5" } },
            browse: [],
            url: `demo:${level}:${k}:${t.dir === "ASCENDING" ? "Ascending" : "Descending"}`,
            _demo: true,
          },
        });
      }
    }
  }
  return new Promise((r) => setTimeout(() => r({ type: "FeatureCollection", features: feats }), 400));
}

// synthetic events that fall inside the demo data window (17 June to October 2026)
const DEMO_EVENTS = [
  { id: "demo:flood-souss", type: "flood", title: "Demo flood: Souss-Massa, Morocco", place: "Morocco", time: "2026-08-20T00:00:00Z", end: "2026-08-24T00:00:00Z", lat: 30.4, lon: -9.4, severity: "orange", source: "Demo" },
  { id: "demo:quake-haouz", type: "earthquake", title: "Demo M 6.4: Al Haouz, Morocco", place: "Morocco", time: "2026-09-10T12:30:00Z", end: null, lat: 31.1, lon: -8.4, magnitude: 6.4, severity: "orange", source: "Demo" },
  { id: "demo:flood-sylhet", type: "flood", title: "Demo flood: Sylhet, Bangladesh", place: "Bangladesh", time: "2026-08-28T00:00:00Z", end: "2026-09-06T00:00:00Z", lat: 24.9, lon: 91.9, severity: "red", source: "Demo" },
  { id: "demo:quake-turkey", type: "earthquake", title: "Demo M 6.1: Eastern Turkey", place: "Turkey", time: "2026-07-25T03:10:00Z", end: null, lat: 38.4, lon: 38.3, magnitude: 6.1, severity: "green", source: "Demo" },
];
export function mockEvents({ types, minmag }) {
  return DEMO_EVENTS.filter((e) => types.includes(e.type) && (e.type !== "earthquake" || e.magnitude >= minmag)).map((e) => {
    const half = e.type === "earthquake" ? 0.7 : 0.6;
    return { ...e, bbox: [e.lon - half, e.lat - half, e.lon + half, e.lat + half], url: null, demo: true };
  });
}
