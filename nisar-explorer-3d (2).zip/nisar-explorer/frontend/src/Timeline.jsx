// bottom dock: acquisitions per day as a timeline. Click a bar to keep only that day.
const day = (f) => (f.properties.startTime || "").slice(0, 10);
const short = (d) => (d ? new Date(d + "T00:00:00Z").toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" }) : "");

export default function Timeline({ features, dayFilter, setDayFilter, selectedDay, loading }) {
  const counts = {};
  features.forEach((f) => { counts[day(f)] = (counts[day(f)] || 0) + 1; });
  const days = Object.keys(counts).filter(Boolean).sort();
  const max = Math.max(1, ...Object.values(counts));
  const mid = days[Math.floor(days.length / 2)];
  return (
    <section className="timeline" aria-label="Acquisitions per day">
      <div className="tl-head">
        <b>Timeline</b>
        <span>{days.length ? `${features.length} granules over ${days.length} day${days.length === 1 ? "" : "s"}` : loading ? "Searching…" : "Search to see acquisitions over time"}</span>
        {dayFilter && <button className="link" onClick={() => setDayFilter(null)}>Show all dates</button>}
      </div>
      <div className="tl-bars">
        {days.map((d) => (
          <button key={d} className={`tl-bar${d === dayFilter ? " on" : ""}${d === selectedDay ? " sel" : ""}`} onClick={() => setDayFilter(d === dayFilter ? null : d)} title={`${d}: ${counts[d]}`} aria-label={`${d}: ${counts[d]} granules`}>
            <span style={{ height: `${Math.max(10, (counts[d] / max) * 100)}%` }} />
          </button>
        ))}
        {!days.length && <div className="tl-empty" />}
      </div>
      <div className="tl-axis"><span>{short(days[0])}</span><span>{days.length > 2 ? short(mid) : ""}</span><span>{short(days[days.length - 1])}</span></div>
    </section>
  );
}
