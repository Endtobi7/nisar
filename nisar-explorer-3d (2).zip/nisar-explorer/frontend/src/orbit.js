// NISAR orbit tracker: TLE from CelesTrak (via backend, with direct fallback), propagated in the browser with SGP4.
import * as sat from "satellite.js";
import { apiUrl } from "./api.js";

const NORAD = 65053;
const CELESTRAK = `https://celestrak.org/NORAD/elements/gp.php?CATNR=${NORAD}&FORMAT=TLE`;
const EMPTY = { type: "FeatureCollection", features: [] };

async function fetchTle() {
  for (const url of [`${apiUrl}/api/tle`, CELESTRAK]) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const lines = (await res.text()).split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
      const i = lines.findIndex((l) => l.startsWith("1 "));
      if (i >= 0 && lines[i + 1]?.startsWith("2 ")) return [lines[i], lines[i + 1]];
    } catch { /* try next source */ }
  }
  throw new Error("Could not load NISAR orbital elements. Is the backend running?");
}

function at(rec, date) {
  const pv = sat.propagate(rec, date);
  if (!pv || !pv.position) return null;
  const g = sat.eciToGeodetic(pv.position, sat.gstime(date));
  const v = pv.velocity;
  return { lat: sat.degreesLat(g.latitude), lon: sat.degreesLong(g.longitude), alt: g.height, speed: Math.hypot(v.x, v.y, v.z) };
}

// ground track as a MultiLineString, split where it crosses the antimeridian
function track(rec, from, minutes, stepSec = 30) {
  const lines = [];
  let cur = [];
  let prev = null;
  for (let s = 0; s <= minutes * 60; s += stepSec) {
    const p = at(rec, new Date(from.getTime() + s * 1000));
    if (!p) continue;
    if (prev && Math.abs(p.lon - prev.lon) > 180) { lines.push(cur); cur = []; }
    cur.push([p.lon, p.lat]);
    prev = p;
  }
  if (cur.length > 1) lines.push(cur);
  return { type: "Feature", properties: {}, geometry: { type: "MultiLineString", coordinates: lines } };
}

class OrbitTracker {
  constructor() {
    this.state = { status: "idle", message: "", pos: null, past: EMPTY, future: EMPTY, time: null };
    this.listeners = new Set();
    this.rec = null;
    this.timer = null;
    this.lastTrack = 0;
    this.running = false;
    this.subscribe = this.subscribe.bind(this);
    this.getSnapshot = this.getSnapshot.bind(this);
  }
  subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  getSnapshot() { return this.state; }
  set(patch) { this.state = { ...this.state, ...patch }; this.listeners.forEach((f) => f()); }

  async start() {
    if (this.running) return;
    this.running = true;
    try {
      if (!this.rec) {
        this.set({ status: "loading", message: "" });
        const [l1, l2] = await fetchTle();
        this.rec = sat.twoline2satrec(l1, l2);
      }
      if (!this.running) return;
      this.tick();
      this.timer = setInterval(() => this.tick(), 1000);
    } catch (e) {
      this.running = false;
      this.set({ status: "error", message: e.message });
    }
  }
  stop() {
    this.running = false;
    clearInterval(this.timer);
    this.timer = null;
    this.set({ status: "idle", pos: null, past: EMPTY, future: EMPTY });
  }
  tick() {
    const now = new Date();
    const pos = at(this.rec, now);
    if (!pos) { this.set({ status: "error", message: "Orbit propagation failed (stale TLE?)." }); return; }
    const patch = { status: "ok", pos, time: now };
    if (now - this.lastTrack > 30000) {
      this.lastTrack = now;
      patch.past = track(this.rec, new Date(now - 50 * 60000), 50);
      patch.future = track(this.rec, now, 110); // a bit over one ~99 min orbit
    }
    this.set(patch);
  }
}

export const tracker = new OrbitTracker();
