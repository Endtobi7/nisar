import { useMemo } from "react";
import { exportUrl } from "./api.js";
import { openReport } from "./report.js";
import { interpret, Summary, Numbers, Charts, Figure } from "./Interpretation.jsx";

// shows any analysis result: the plain-language reading first, then numbers, charts and images
export default function ResultView({ res, idPrefix, projectedIds = [], onProject, title, context }) {
  const it = useMemo(() => interpret(res), [res]);
  const geo = res.images.filter((i) => i.georeferenced);
  const allOnMap = geo.length > 0 && geo.every((im) => projectedIds.includes(`${idPrefix}::${im.name}`));
  return (
    <div className="result">
      {res.demo && <p className="note">Demo analysis on synthetic data. Not a real NISAR measurement.</p>}
      <p className="hint">
        {res.product}{res.window ? ` · ${res.window.cols}×${res.window.rows} px${res.window.pixel_size_m ? ` (~${Math.round(res.window.pixel_size_m)} m)` : ""}` : ""}
        {res.identification?.trackNumber != null ? ` · track ${res.identification.trackNumber}` : ""}
        {res.identification?.frameNumber != null ? ` · frame ${res.identification.frameNumber}` : ""}
        {res.identification?.orbitPassDirection ? ` · ${String(res.identification.orbitPassDirection).toLowerCase()}` : ""}
      </p>
      <Summary it={it} />
      <div className="figbtns top">
        <button className="btn solid" onClick={() => openReport(res, title || res.product, context)}>Open printable report</button>
        {geo.length > 0 && <button className="btn" disabled={allOnMap} onClick={() => geo.forEach((im) => onProject(im, `${idPrefix}::${im.name}`))}>{allOnMap ? "All results on the 3D map" : "Show all results on 3D map"}</button>}
      </div>
      <Charts res={res} />
      <section aria-label="Images">
        <h4 className="sec">Maps and images</h4>
        <div className="figs">
          {res.images.map((im) => (
            <Figure key={im.name} im={im} id={`${idPrefix}::${im.name}`} projectedIds={projectedIds} onProject={onProject} rid={res.rid} exportUrl={exportUrl} />
          ))}
        </div>
      </section>
      <Numbers res={res} it={it} />
      <section className="caveats" aria-label="Limits">
        <h4 className="sec">Keep in mind</h4>
        <ul>{[...it.caveats, ...res.notes].map((n) => <li key={n}>{n}</li>)}</ul>
      </section>
    </div>
  );
}
