const day = (f) => (f.properties.startTime || "").slice(0, 10);
const time = (f) => (f.properties.startTime || "").slice(11, 16);
// pair products (interferograms, offsets) cover two acquisitions: show the whole span
const span = (f) => {
  const a = Date.parse(f.properties.startTime), b = Date.parse(f.properties.stopTime);
  return Number.isFinite(a) && Number.isFinite(b) && b - a > 864e5 ? `${f.properties.startTime.slice(0, 10)} → ${f.properties.stopTime.slice(0, 10)}` : "";
};

function Coverage({ features, dayFilter, setDayFilter }) {
  const counts = {};
  features.forEach((f) => { counts[day(f)] = (counts[day(f)] || 0) + 1; });
  const days = Object.keys(counts).sort();
  if (!days.length) return null;
  const max = Math.max(...Object.values(counts));
  return (
    <div className="coverage" aria-label="Acquisitions per day">
      <div className="coverage-head">
        <span>Acquisitions per day</span>
        {dayFilter && <button className="link" onClick={() => setDayFilter(null)}>Show all dates</button>}
      </div>
      <div className="bars">
        {days.map((d) => (
          <button key={d} className={d === dayFilter ? "bar on" : "bar"} onClick={() => setDayFilter(d === dayFilter ? null : d)} title={`${d}: ${counts[d]}`} aria-label={`${d}: ${counts[d]} granules`}>
            <span style={{ height: `${Math.max(12, (counts[d] / max) * 100)}%` }} />
          </button>
        ))}
      </div>
      <div className="axis"><span>{days[0]}</span><span>{days[days.length - 1]}</span></div>
    </div>
  );
}

export default function Results({ all, features, status, selectedId, onPick, onHover, dayFilter, setDayFilter }) {
  if (status.state === "idle")
    return <div className="empty">Draw a box on the map (or search the whole world), then press <b>Search NISAR</b>.</div>;
  if (status.state === "loading") return <div className="empty">Searching the ASF archive…</div>;
  if (status.state === "error")
    return <div className="empty error"><b>Search failed.</b> {status.message}<br />Is the backend running? Start it with <code>uvicorn main:app --reload</code>, or tick “Demo data”.</div>;
  if (!all.length)
    return <div className="empty"><b>No NISAR granules found.</b> Widen the date range, clear the area, or add more product types. Calibrated data only starts on 2026-06-17.</div>;

  return (
    <>
      <div className="count">{features.length} granule{features.length === 1 ? "" : "s"}{all.length >= 250 ? " (limit reached — narrow your search)" : ""}{status.hidden > 0 ? ` · ${status.hidden} hidden: they start outside your time window` : ""}</div>
      <ul className="list">
        {features.map((f) => {
          const p = f.properties;
          const id = p._id;
          return (
            <li key={id}>
              <button className={id === selectedId ? "item on" : "item"} onClick={() => onPick(id)} onMouseEnter={() => onHover(id)} onMouseLeave={() => onHover(null)}>
                <span className="item-top">
                  <b>{p.processingLevel || "NISAR"}</b>
                  <span>{day(f)} {time(f)} UTC</span>
                </span>
                <span className="item-sub">
                  {(p.flightDirection || "").toLowerCase()} · path {p.pathNumber ?? "–"} · frame {p.frameNumber ?? "–"}{span(f) ? ` · pair ${span(f)}` : ""}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </>
  );
}
