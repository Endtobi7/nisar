import { interpret, explainImage, explainSeries, LEVEL_LABEL } from "./interpret.js";
import { SeriesChart, groupSeries, Hist } from "./Chart.jsx";

// "What this means": headline, key points and next steps for any analysis result
export function Summary({ it }) {
  return (
    <section className={`reading tone-${it.tone}`} aria-label="What this means">
      <p className="reading-tag">What this means</p>
      <h3 className="reading-head">{it.headline}</h3>
      {it.points.length > 0 && (
        <ul className="reading-points">{it.points.map((t, i) => <li key={i}>{t}</li>)}</ul>
      )}
      <details className="reading-next">
        <summary>What to do next</summary>
        <ul>{it.next.map((t) => <li key={t}>{t}</li>)}</ul>
      </details>
    </section>
  );
}

// each number with its meaning in plain words
export function Numbers({ res, it }) {
  return (
    <section aria-label="Every number explained">
      <h4 className="sec">Every number, explained</h4>
      <ul className="mlist">
        {res.metrics.map((m, i) => {
          const x = it.items[i];
          return (
            <li key={m.label + i} className={`mrow lv-${x.level}`}>
              <div className="mtop"><span className="mlabel">{m.label}</span><span className="mval">{m.value}</span></div>
              <p className="mread"><span className="pill">{LEVEL_LABEL[x.level]}</span> {x.read}</p>
              <details className="mwhat"><summary>What is this?</summary><p>{x.what}{m.note ? ` ${m.note}.` : ""}</p></details>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function Charts({ res }) {
  const groups = groupSeries(res.series);
  if (!groups.length) return null;
  return (
    <section aria-label="Charts">
      <h4 className="sec">Charts</h4>
      {groups.map((g, i) => (
        <div key={i}>
          <SeriesChart group={g} />
          <p className="explain">{explainSeries(g)}</p>
        </div>
      ))}
    </section>
  );
}

export function Figure({ im, id, projectedIds, onProject, rid, exportUrl }) {
  const ex = explainImage(im);
  const slug = (n) => n.replace(/[^a-z0-9]+/gi, "_").slice(0, 40);
  return (
    <figure className="fig">
      <img src={im.png} alt={im.name} />
      <figcaption>
        <b>{im.name}</b>
        {im.legend && <span> {Number(im.legend.min).toFixed(1)} to {Number(im.legend.max).toFixed(1)} {im.legend.unit}</span>}
      </figcaption>
      <div className="explain">
        <p><b>Shows:</b> {ex.shows}</p>
        <p><b>How to read it:</b> {ex.reading}</p>
        {ex.spread && <p>{ex.spread}</p>}
      </div>
      <Hist hist={im.hist} unit={im.legend?.unit} />
      <div className="figbtns">
        {im.georeferenced
          ? <button className="btn" disabled={projectedIds.includes(id)} onClick={() => onProject(im, id)}>{projectedIds.includes(id) ? "On the 3D map" : "Show on 3D map"}</button>
          : <small>preview only</small>}
        {rid && im.hist && <a className="btn ghost" href={exportUrl(rid, im.name, "geotiff")} title="GeoTIFF with map coordinates (map-ready products)">GeoTIFF</a>}
        {rid && im.hist && <a className="btn ghost" href={exportUrl(rid, im.name, "csv")}>CSV</a>}
        <a className="btn ghost" href={im.png} download={`${slug(im.name)}.png`}>PNG</a>
      </div>
    </figure>
  );
}

export { interpret };
