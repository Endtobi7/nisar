import { useEffect, useMemo, useState } from "react";
import { GROUPS, PRODUCTS } from "./products.js";
import { GUIDE } from "./guideData.js";

const UI = {
  en: { title: "NISAR guide", products: "Products", analyses: "Analyses", intro: "Every file is HDF5 (.h5). Pair products (interferograms, offsets) combine two dates 12 days or more apart.",
        search: "Search an analysis", all: "All", ready: "Ready in the app", partial: "Partly", guide: "Guide only", sec: "All sections", needs: "Needs", tells: "What it tells you", how: "How it is calculated",
        formulas: "Formulas", result: "Result", caution: "Caution", where: "Where to run it", count: (n) => `${n} analyses shown`, inside: "Inside", extract: "You can extract", s: "Search" },
  fr: { title: "Guide NISAR", products: "Produits", analyses: "Analyses", intro: "Chaque fichier est au format HDF5 (.h5). Les produits de paires (interférogrammes, décalages) combinent deux dates espacées d'au moins 12 jours.",
        search: "Chercher une analyse", all: "Toutes", ready: "Disponibles dans l'application", partial: "Partielles", guide: "Guide seulement", sec: "Toutes les sections", needs: "Nécessite", tells: "Ce qu'elle indique", how: "Comment elle est calculée",
        formulas: "Formules", result: "Résultat", caution: "Attention", where: "Où la lancer", count: (n) => `${n} analyses affichées`, inside: "Contenu", extract: "Vous pouvez extraire", s: "Chercher" },
};
const WHERE = {
  search: { en: "Sidebar: search filters", fr: "Barre latérale : filtres de recherche" },
  results: { en: "Results list", fr: "Liste de résultats" },
  layers: { en: "Layers panel (on the map)", fr: "Panneau Couches (sur la carte)" },
  insights: { en: "Coverage and next passes (under the results)", fr: "Couverture et prochains passages (sous les résultats)" },
  analyse: { en: "Granule panel → Analyse this file", fr: "Panneau du granule → Analyser ce fichier" },
  extra: { en: "Granule panel → Analyse this file → tick it under Extra analyses", fr: "Panneau du granule → Analyser ce fichier → cocher dans Extra analyses" },
  pair: { en: "Analysis workbench → Two files", fr: "Atelier d'analyse → Deux fichiers" },
  series: { en: "Analysis workbench → Time series", fr: "Atelier d'analyse → Séries temporelles" },
  tools: { en: "Buttons under each result image, and Inspect a point", fr: "Boutons sous chaque image de résultat, et Inspecter un point" },
  guide: { en: "Guide only (not built)", fr: "Guide seulement (non réalisé)" },
};
const PRODUCT_FR = { contains: "Contenu", extract: "Vous pouvez extraire" };

export default function GuideDialog({ onClose, onSearch, initialTab = "analyses" }) {
  const [lang, setLang] = useState(() => (navigator.language || "en").toLowerCase().startsWith("fr") ? "fr" : "en");
  const [tab, setTab] = useState(initialTab);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [sec, setSec] = useState("all");
  const t = UI[lang];

  useEffect(() => {
    const esc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    return GUIDE.items.filter((i) =>
      (status === "all" || i.status === status) && (sec === "all" || String(i.sec) === sec) &&
      (!s || [i.name.en, i.name.fr, i.tells.en, i.tells.fr, i.product, i.id].join(" ").toLowerCase().includes(s)));
  }, [q, status, sec]);
  const counts = { ready: GUIDE.items.filter((i) => i.status === "ready").length, partial: GUIDE.items.filter((i) => i.status === "partial").length, guide: GUIDE.items.filter((i) => i.status === "guide").length };

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog wide" role="dialog" aria-modal="true" aria-labelledby="guide-title">
        <header className="dhead">
          <h2 id="guide-title">{t.title}</h2>
          <span className="dright">
            <button className={lang === "fr" ? "chip on" : "chip"} onClick={() => setLang("fr")}>FR</button>
            <button className={lang === "en" ? "chip on" : "chip"} onClick={() => setLang("en")}>EN</button>
            <button className="x" onClick={onClose} aria-label="Close guide">×</button>
          </span>
        </header>
        <div className="tabs" role="tablist">
          <button role="tab" aria-selected={tab === "analyses"} className={tab === "analyses" ? "tab on" : "tab"} onClick={() => setTab("analyses")}>{t.analyses} ({GUIDE.items.length})</button>
          <button role="tab" aria-selected={tab === "products"} className={tab === "products" ? "tab on" : "tab"} onClick={() => setTab("products")}>{t.products} ({PRODUCTS.length})</button>
        </div>

        {tab === "products" && (
          <>
            <p className="hint">{t.intro}</p>
            {GROUPS.map((g) => (
              <section key={g.id}>
                <h3>{g.title}</h3>
                <p className="hint">{g.note}</p>
                <div className="pgrid">
                  {PRODUCTS.filter((p) => p.group === g.id).map((p) => (
                    <article key={p.code} className="pcard">
                      <header><b>{p.code}</b><span className="badge">{p.level}</span>{p.pair && <span className="badge alt">2 dates</span>}</header>
                      <p className="pname">{p.name} · {p.pixel}</p>
                      <p className="plabel">{t.inside}</p>
                      <ul>{p.contains.map((c) => <li key={c}>{c}</li>)}</ul>
                      <p className="plabel">{t.extract}</p>
                      <ul>{p.extract.map((c) => <li key={c}>{c}</li>)}</ul>
                      <button className="btn" onClick={() => onSearch(p.code)}>{t.s} {p.code}</button>
                    </article>
                  ))}
                </div>
              </section>
            ))}
          </>
        )}

        {tab === "analyses" && (
          <>
            <div className="gfilters">
              <input type="search" placeholder={t.search} value={q} onChange={(e) => setQ(e.target.value)} aria-label={t.search} />
              <select value={sec} onChange={(e) => setSec(e.target.value)} aria-label="Section">
                <option value="all">{t.sec}</option>
                {GUIDE.sections.map((s, i) => <option key={i} value={i}>{i + 3}. {s.title[lang]}</option>)}
              </select>
              <div className="chips">
                {[["all", t.all], ["ready", `${t.ready} (${counts.ready})`], ["partial", `${t.partial} (${counts.partial})`], ["guide", `${t.guide} (${counts.guide})`]].map(([k, l]) => (
                  <button key={k} className={status === k ? "chip on" : "chip"} aria-pressed={status === k} onClick={() => setStatus(k)}>{l}</button>
                ))}
              </div>
            </div>
            <p className="hint">{t.count(shown.length)}</p>
            {GUIDE.sections.map((s, si) => {
              const rows = shown.filter((i) => i.sec === si);
              if (!rows.length) return null;
              return (
                <section key={si}>
                  <h3>{si + 3}. {s.title[lang]}</h3>
                  <p className="hint">{s.intro[lang]}</p>
                  {rows.map((i) => (
                    <details key={i.id} className="gitem">
                      <summary>
                        <span className="gid">{i.id}</span> <b>{i.name[lang]}</b>
                        <span className={`badge s-${i.status}`}>{t[i.status]}</span>
                        {i.difficulty !== "-" && <span className="badge alt">{i.difficulty}</span>}
                      </summary>
                      <p className="hint"><b>{t.where}:</b> {WHERE[i.where][lang]}{i.note ? ` — ${i.note[lang]}` : ""}</p>
                      <p><b>{t.needs}:</b> {i.needs[lang]} · <span className="hint">{i.product}</span></p>
                      <p><b>{t.tells}:</b> {i.tells[lang]}</p>
                      <p className="plabel">{t.how}</p>
                      <ol className="gsteps">{i.steps[lang].map((x, k) => <li key={k}>{x}</li>)}</ol>
                      {i.formulas.length > 0 && <><p className="plabel">{t.formulas}</p>{i.formulas.map((f) => <pre key={f} className="gformula">{f}</pre>)}</>}
                      {i.out && <p><b>{t.result}:</b> {i.out[lang]}</p>}
                      {i.caution && <p className="note"><b>{t.caution}:</b> {i.caution[lang]}</p>}
                    </details>
                  ))}
                </section>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
}
