// Shareable state lives in the URL hash: #bbox=..&start=..&end=..&lvl=..&dir=..&sel=..&mock=1&v=lng,lat,z
import { PRODUCTS } from "./products.js";
export const LEVELS = PRODUCTS.map((p) => p.code);

const today = () => new Date().toISOString().slice(0, 10);

export const DEFAULT_FILTERS = {
  bbox: null, // [w, s, e, n]
  start: "2026-06-17T00:00", // first calibrated L-band observations (UTC)
  end: `${today()}T23:59`,
  levels: ["GCOV"],
  direction: "",
  mock: false,
  timeMode: "start", // "start": granule starts inside the window; "overlap": its time span touches the window
};
export const DEFAULT_VIEW = [10, 25, 2.2]; // lng, lat, zoom

const daysAgo = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
// GIBS lags behind acquisition, so default to a few days back
export const DEFAULT_LAYERS = { bs: false, date: daysAgo(3), days: 12, opacity: 1, orbit: false, mode: "stack" };

const nums = (s, n) => {
  const a = (s || "").split(",").map(Number);
  return a.length === n && a.every(Number.isFinite) ? a : null;
};

const withTime = (s, t) => (s.includes("T") ? s : `${s}T${t}`);

export function readHash() {
  const p = new URLSearchParams(location.hash.replace(/^#\/?/, ""));
  const filters = {
    ...DEFAULT_FILTERS,
    bbox: nums(p.get("bbox"), 4),
    start: withTime(p.get("start") || DEFAULT_FILTERS.start, "00:00"),
    end: withTime(p.get("end") || DEFAULT_FILTERS.end, "23:59"),
    levels: p.get("lvl") ? p.get("lvl").split(",").filter((l) => LEVELS.includes(l)) : DEFAULT_FILTERS.levels,
    direction: p.get("dir") || "",
    mock: p.get("mock") === "1",
    timeMode: p.get("tm") === "overlap" ? "overlap" : "start",
  };
  const days = parseInt(p.get("bn"), 10);
  const layers = {
    ...DEFAULT_LAYERS,
    bs: p.get("bs") === "1",
    date: /^\d{4}-\d{2}-\d{2}$/.test(p.get("bd") || "") ? p.get("bd") : DEFAULT_LAYERS.date,
    days: days >= 1 && days <= 12 ? days : 12,
    orbit: p.get("orbit") === "1",
    mode: p.get("bm") === "c" ? "composite" : "stack",
  };
  return { filters, view: nums(p.get("v"), 3) || DEFAULT_VIEW, sel: p.get("sel") || null, layers };
}

export function writeHash(filters, view, sel, layers) {
  const p = new URLSearchParams();
  if (filters.bbox) p.set("bbox", filters.bbox.map((x) => +x.toFixed(3)).join(","));
  p.set("start", filters.start);
  p.set("end", filters.end);
  p.set("lvl", filters.levels.join(","));
  if (filters.direction) p.set("dir", filters.direction);
  if (filters.mock) p.set("mock", "1");
  if (filters.timeMode === "overlap") p.set("tm", "overlap");
  if (view) p.set("v", view.map((x) => +x.toFixed(3)).join(","));
  if (sel) p.set("sel", sel);
  if (layers?.bs) { p.set("bs", "1"); p.set("bd", layers.date); p.set("bn", String(layers.days)); if (layers.mode === "composite") p.set("bm", "c"); }
  if (layers?.orbit) p.set("orbit", "1");
  history.replaceState(null, "", "#" + p.toString());
}
