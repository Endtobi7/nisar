import { catalog } from "./api.js";

let promise = null;
// the list of analyses the backend offers (loaded once); null when the backend is too old
export const loadCatalog = () => (promise ||= catalog().catch(() => { promise = null; return null; }));
export const family = (code) => ({ GUNW: "UNW", RUNW: "UNW", GOFF: "OFF", ROFF: "OFF", GSLC: "SLC", RSLC: "SLC" }[code] || code);
