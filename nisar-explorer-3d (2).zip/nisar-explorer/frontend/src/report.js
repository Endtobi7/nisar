// Detailed printable report: summary, every number explained, charts, images, limits, glossary.
// Opens in a new tab; use the Print button (or Ctrl+P) and choose "Save as PDF".
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { interpret, explainImage, explainSeries, LEVEL_LABEL } from "./interpret.js";
import { SeriesChart, groupSeries } from "./Chart.jsx";

const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

const GLOSSARY = [
  [/backscatter|\bdB\b|gamma-0|sigma-0/i, "Backscatter (dB)", "The share of the radar signal that returns to the satellite, on a logarithmic decibel scale. Lower (more negative) means darker."],
  [/\bHH\b|\bHV\b|\bVV\b|polari[sz]ation|cross-pol/i, "Polarisation (HH, HV, VV)", "The orientation of the transmitted and received radar wave. HH and VV are the same orientation on both ways; HV mixes them and is sensitive to vegetation volume."],
  [/coheren/i, "Coherence", "A 0 to 1 score of how stable the surface was between two dates. High means the phase can be trusted; low means the surface changed."],
  [/line-of-sight|displacement|phase|fringe|interferogram|GUNW|velocity/i, "Line of sight and phase", "Interferometry measures the change in distance between ground and satellite. One full colour cycle (fringe) of the phase equals about 12 cm of motion at NISAR's L-band wavelength."],
  [/speckle|looks|ENL/i, "Speckle and looks", "Radar images are naturally grainy. Averaging several looks smooths the grain at the cost of detail."],
  [/offset|GOFF|speed|glacier/i, "Offset tracking", "Following patterns between two images to measure large motion (glaciers, landslides) that is too big for phase methods."],
  [/GCOV/i, "GCOV", "Geocoded covariance product: terrain-corrected backscatter on a map grid."],
  [/z-score|anomaly/i, "Z-score", "How many standard deviations a value is from its usual level. Beyond ±2 is unusual."],
  [/DEM|slope|shadow|layover/i, "Radar shadow and layover", "Steep terrain can hide ground from the radar (shadow, appears dark) or fold it over (layover, appears bright). A DEM helps mask these."],
];

export function openReport(res, title, context = {}) {
  const w = window.open("", "_blank");
  if (!w) return false;
  w.document.write(buildReport(res, title, context));
  w.document.close();
  return true;
}

export function buildReport(res, title, context = {}) {
  const it = interpret(res);
  const now = new Date().toISOString().slice(0, 16).replace("T", " ");
  const idn = res.identification ? Object.entries(res.identification).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join("") : "";
  const bbox = context.bbox ? context.bbox.map((n) => Number(n).toFixed(3)).join(", ") : "";
  const grans = (context.granules || []).map((g) => `<li>${esc(g.processingLevel || "")} · ${esc((g.startTime || "").slice(0, 16).replace("T", " "))} UTC · ${esc(String(g.flightDirection || "").toLowerCase())} · track ${esc(g.pathNumber ?? "?")} frame ${esc(g.frameNumber ?? "?")}<br><small>${esc(g.sceneName || "")}</small></li>`).join("");

  const scope = [
    ["Analysis", res.product],
    res.window ? ["Window", `${res.window.cols} × ${res.window.rows} pixels${res.window.pixel_size_m ? `, about ${Math.round(res.window.pixel_size_m)} m per pixel` : ""}`] : null,
    bbox ? ["Area (west, south, east, north)", bbox] : null,
    ["Generated", `${now} UTC`],
  ].filter(Boolean).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join("");

  const rows = res.metrics.map((m, i) => {
    const x = it.items[i];
    return `<tr class="lv-${x.level}"><td><b>${esc(m.label)}</b></td><td class="val">${esc(m.value)}</td><td><span class="pill">${esc(LEVEL_LABEL[x.level])}</span> ${esc(x.read)}<div class="what">${esc(x.what)}${m.note ? " " + esc(m.note) + "." : ""}</div></td></tr>`;
  }).join("");

  const charts = groupSeries(res.series).map((g) => `<div class="chartbox">${renderToStaticMarkup(createElement(SeriesChart, { group: g }))}<p class="cap">${esc(explainSeries(g))}</p></div>`).join("");

  const figs = res.images.map((im) => {
    const ex = explainImage(im);
    const range = im.legend ? ` (${Number(im.legend.min).toFixed(1)} to ${Number(im.legend.max).toFixed(1)} ${esc(im.legend.unit)})` : "";
    return `<figure class="fig"><img src="${im.png}" alt=""><figcaption><b>${esc(im.name)}</b>${range}<br><b>Shows:</b> ${esc(ex.shows)}<br><b>How to read it:</b> ${esc(ex.reading)}${ex.spread ? `<br>${esc(ex.spread)}` : ""}</figcaption></figure>`;
  }).join("");

  const allText = [res.product, ...res.metrics.map((m) => m.label + " " + m.value), ...res.images.map((i) => i.name), ...res.notes].join(" ");
  const gloss = GLOSSARY.filter(([re]) => re.test(allText)).map(([, t, d]) => `<dt>${esc(t)}</dt><dd>${esc(d)}</dd>`).join("");

  const notes = [...it.caveats, ...res.notes].map((n) => `<li>${esc(n)}</li>`).join("");

  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${esc(title)} – report</title><style>
  @page{size:A4;margin:16mm 14mm 18mm}
  *{box-sizing:border-box}
  body{font:13px/1.5 "Public Sans",system-ui,Segoe UI,Calibri,sans-serif;color:#12232e;margin:0;background:#e9edea}
  .page{max-width:840px;margin:18px auto;background:#fff;padding:34px 40px;box-shadow:0 4px 24px rgba(0,0,0,.12)}
  .bar{position:sticky;top:0;z-index:2;display:flex;gap:10px;justify-content:center;align-items:center;padding:10px;background:#12232e;color:#fff}
  .bar button{font:inherit;font-weight:600;padding:7px 16px;border:0;border-radius:6px;background:#2fd1c5;color:#06201e;cursor:pointer}
  .bar span{font-size:12px;opacity:.8}
  .cover{border-bottom:4px solid #0b7a75;padding-bottom:14px;margin-bottom:18px}
  .kicker{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#0b7a75;font-weight:700;margin:0}
  h1{font-size:26px;line-height:1.2;margin:4px 0 4px}
  .sub{color:#5a6b76;margin:0}
  h2{font-size:16px;margin:26px 0 8px;padding-bottom:4px;border-bottom:1px solid #d3dad6;break-after:avoid}
  h2 em{font-style:normal;color:#0b7a75;margin-right:6px}
  p{margin:6px 0}
  table{border-collapse:collapse;width:100%;font-size:12.5px}
  td,th{border-bottom:1px solid #e1e6e3;padding:6px 8px;vertical-align:top;text-align:left}
  tr{break-inside:avoid}
  .meta td:first-child{width:34%;color:#5a6b76}
  .val{white-space:nowrap;font-weight:600}
  .what{font-size:11.5px;color:#5a6b76;margin-top:3px}
  .pill{display:inline-block;font-size:10px;font-weight:700;letter-spacing:.03em;text-transform:uppercase;padding:1px 7px;border-radius:999px;background:#dfe6e3;color:#33454f}
  .lv-good .pill{background:#d6f1ec;color:#0a5c57}.lv-watch .pill{background:#fff0c7;color:#7a5200}.lv-alert .pill{background:#ffd9cb;color:#9a2f06}
  .summary{border:1px solid #cfe3df;border-left:6px solid #0b7a75;background:#f2faf8;padding:12px 16px;border-radius:6px;break-inside:avoid}
  .summary.tone-watch{border-left-color:#e8a200;background:#fffaf0;border-color:#f0e2bd}
  .summary.tone-alert{border-left-color:#d9480f;background:#fff6f2;border-color:#f3d4c6}
  .summary h3{font-size:18px;margin:0 0 6px}
  .summary ul{margin:6px 0 0;padding-left:18px}
  .summary li{margin-bottom:3px}
  figure{margin:14px 0;break-inside:avoid}
  .fig img{max-width:100%;border:1px solid #d3dad6;display:block;background:#33454f}
  figcaption{font-size:12px;color:#33454f;margin-top:4px}
  .chartbox{break-inside:avoid;margin:12px 0}.cap{font-size:12px;color:#33454f;margin:2px 0 0}
  .chart{margin:0}.chart svg{width:100%;max-width:520px;height:auto}
  .c-plot{fill:#fff;stroke:#d3dad6}.c-grid{stroke:#e7ece9}.c-tick{fill:#5a6b76}
  .legend{display:flex;gap:4px 12px;flex-wrap:wrap;font-size:11px;color:#5a6b76}.legend i{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:4px}
  dl{margin:0}dt{font-weight:700;margin-top:8px}dd{margin:0;color:#33454f}
  ul.pl{padding-left:18px}ul.pl li{margin-bottom:5px}
  .demo{background:#fff1d6;padding:7px 12px;border-radius:6px;margin:10px 0}
  small{color:#5a6b76}
  footer{margin-top:28px;padding-top:8px;border-top:1px solid #d3dad6;font-size:11px;color:#5a6b76}
  @media print{body{background:#fff}.bar{display:none}.page{box-shadow:none;margin:0;padding:0;max-width:none}h2{break-after:avoid}}
  </style></head><body>
  <div class="bar"><button onclick="window.print()">Print / Save as PDF</button><span>Choose “Save as PDF” as the printer to keep a file.</span></div>
  <main class="page">
    <header class="cover"><p class="kicker">NISAR Explorer · analysis report</p><h1>${esc(title)}</h1><p class="sub">${esc(res.product)} · ${esc(now)} UTC</p></header>
    ${res.demo ? '<p class="demo"><b>Demo analysis on synthetic data.</b> Not a real NISAR measurement.</p>' : ""}

    <h2><em>1</em>Summary</h2>
    <div class="summary tone-${it.tone}"><h3>${esc(it.headline)}</h3>${it.points.length ? `<ul>${it.points.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>` : ""}</div>

    <h2><em>2</em>Scope and data</h2>
    <table class="meta">${scope}${idn}</table>
    ${grans ? `<p><b>Granules used</b></p><ul class="pl">${grans}</ul>` : ""}

    <h2><em>3</em>Each result, explained</h2>
    <p>Every measurement is listed with its value, a plain-language reading and a short definition. Labels show how much attention a value deserves.</p>
    <table><thead><tr><th>Measurement</th><th>Value</th><th>Meaning</th></tr></thead><tbody>${rows}</tbody></table>

    ${charts ? `<h2><em>4</em>Charts</h2>${charts}` : ""}
    ${figs ? `<h2><em>${charts ? 5 : 4}</em>Maps and images</h2>${figs}` : ""}

    <h2><em>${6 - (charts ? 0 : 1) - (figs ? 0 : 1)}</em>Key points and next steps</h2>
    <p><b>In general</b></p><ul class="pl">${it.points.map((p) => `<li>${esc(p)}</li>`).join("") || "<li>No key point was extracted.</li>"}</ul>
    <p><b>What to do next</b></p><ul class="pl">${it.next.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>

    <h2><em>${7 - (charts ? 0 : 1) - (figs ? 0 : 1)}</em>Limits of this analysis</h2>
    <ul class="pl">${notes}</ul>
    ${gloss ? `<h2><em>${8 - (charts ? 0 : 1) - (figs ? 0 : 1)}</em>Glossary</h2><dl>${gloss}</dl>` : ""}
    <footer>Data: NASA/ISRO NISAR via ASF DAAC. Calibrated products are provisional. Interpretations are automatic and use rules of thumb: confirm important findings with other data.</footer>
  </main></body></html>`;
}
