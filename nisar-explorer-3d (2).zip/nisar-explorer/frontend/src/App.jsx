import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import MapView from "./MapView.jsx";
import Filters from "./Filters.jsx";
import Results from "./Results.jsx";
import Detail from "./Detail.jsx";
import LoginDialog from "./LoginDialog.jsx";
import LayerPanel from "./LayerPanel.jsx";
import GuideDialog from "./GuideDialog.jsx";
import Workbench from "./Workbench.jsx";
import Insights from "./Insights.jsx";
import PixelPanel from "./PixelPanel.jsx";
import MapToolbar from "./MapToolbar.jsx";
import Mascot from "./Mascot.jsx";
import Timeline from "./Timeline.jsx";
import Hero from "./Hero.jsx";
import Events from "./Events.jsx";
import { eventRange, analysisArea } from "./eventPairs.js";
import { interpret, digest } from "./interpret.js";
import { tracker } from "./orbit.js";
import { fitCoords, defaultMode } from "./fit.js";
import { exactCorners } from "./kml.js";
import { searchNisar, whoami, logout, fetchBrowse, pixelInfo, timeWindow, fetchEvents } from "./api.js";
import { readHash, writeHash } from "./hash.js";

export default function App() {
  const init = useMemo(readHash, []);
  const [filters, setFilters] = useState(init.filters);
  const [features, setFeatures] = useState([]);
  const [status, setStatus] = useState({ state: "idle" });
  const [selectedId, setSelectedId] = useState(init.sel);
  const [hoveredId, setHoveredId] = useState(null);
  const [drawing, setDrawing] = useState(false);
  const [fitKey, setFitKey] = useState(0);
  const [focus, setFocus] = useState(null);
  const [dayFilter, setDayFilter] = useState(null);
  const view = useRef(init.view);
  const [auth, setAuth] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem("edl") || "null"); } catch { return null; }
  });
  const [loginOpen, setLoginOpen] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [wbOpen, setWbOpen] = useState(false);
  const [basket, setBasket] = useState([]); // granules chosen for two-file and series analyses
  const [inspect, setInspect] = useState(null); // granule whose pixel values are read on the next map click
  const [pixelRes, setPixelRes] = useState(null);
  const [pixelErr, setPixelErr] = useState("");
  const [pin, setPin] = useState(null);
  const [context, setContext] = useState({ layer: "", date: init.layers.date, opacity: 0.8 });
  const [compare, setCompare] = useState({ on: false, a: "", b: "", t: 0.5 });
  const [layers, setLayers] = useState(init.layers);
  const [follow, setFollow] = useState(false);
  const [overlays, setOverlays] = useState([]); // projected browse images: {id, url, coords, label}
  const [overlayOpacity, setOverlayOpacity] = useState(0.85);
  const [browseMsg, setBrowseMsg] = useState("");
  const [browseBusy, setBrowseBusy] = useState(false);
  const [bsIssue, setBsIssue] = useState(false);
  const [view3d, setView3d] = useState({ terrain: true, exaggeration: 1.6, basemap: "sat", globe: true });
  const [areaKey, setAreaKey] = useState(0);
  const [ovFocus, setOvFocus] = useState(null);
  const [mapCmd, setMapCmd] = useState(null);
  const [demIssue, setDemIssue] = useState(false);
  const [wbSeen, setWbSeen] = useState(false); // the workbench stays mounted once opened, so results survive a trip to the map
  const [analysisDone, setAnalysisDone] = useState(false);
  const autoTerrain = useRef(false);
  const [tab, setTab] = useState("search");
  const [intro, setIntro] = useState(() => { try { return localStorage.getItem("nisar-intro") !== "1"; } catch { return true; } });
  const [fly, setFly] = useState(null);
  const [tourReq, setTourReq] = useState(0);
  const [lastResult, setLastResult] = useState(null);
  const [events, setEvents] = useState([]);
  const [eventStatus, setEventStatus] = useState({ state: "idle" });
  const [selEventId, setSelEventId] = useState(null);
  const [wbPreset, setWbPreset] = useState(null);

  const removeOverlay = (id) =>
    setOverlays((list) => {
      const o = list.find((x) => x.id === id);
      if (o) URL.revokeObjectURL(o.url);
      return list.filter((x) => x.id !== id);
    });
  const setOverlayMode = async (id, mode) => {
    const o = overlays.find((x) => x.id === id);
    if (!o || !o.blob) return;
    const coords = await fitCoords(o.blob, o.feature, mode, o.exact);
    setOverlays((list) => list.map((x) => (x.id === id ? { ...x, mode, coords } : x)));
  };
  // a georeferenced analysis image: exact corners come from the file itself
  const projectImage = (img, id, label) => {
    setOverlays((list) => (list.some((o) => o.id === id) ? list : [...list, { id, url: img.png, feature: null, blob: null, mode: "kml", exact: img.corners, coords: img.corners, label }]));
    setOvFocus({ coords: img.corners, t: Date.now() });
    if (!autoTerrain.current) { autoTerrain.current = true; setView3d((v) => (v.terrain ? v : { ...v, terrain: true })); }
  };
  const inBasket = (f) => !!f && basket.some((b) => b.properties._id === f.properties._id);
  const toggleBasket = (f) => setBasket((list) => (list.some((b) => b.properties._id === f.properties._id) ? list.filter((b) => b.properties._id !== f.properties._id) : [...list, f]));
  const startInspect = (f) => {
    if (inspect) return setInspect(null);
    if (!f.properties._demo && !auth) return setLoginOpen(true);
    setInspect(f);
  };
  const onMapClick = async (ll) => {
    const f = inspect;
    if (!f) return;
    setInspect(null); setPin({ lon: ll.lng, lat: ll.lat }); setPixelErr(""); setPixelRes(null);
    try {
      setPixelRes(await pixelInfo({ url: f.properties.url, lon: ll.lng, lat: ll.lat, sid: auth?.sid, level: f.properties.processingLevel }));
    } catch (err) {
      if (err.status === 401) setLoginOpen(true);
      setPixelErr(err.message);
    }
  };
  const opacities = useMemo(() => {
    if (!compare.on || !compare.a || !compare.b) return null;
    return { [compare.a]: overlayOpacity * (1 - compare.t), [compare.b]: overlayOpacity * compare.t };
  }, [compare, overlayOpacity]);
  const clearOverlays = () =>
    setOverlays((list) => {
      list.forEach((o) => URL.revokeObjectURL(o.url));
      return [];
    });

  useEffect(() => { layers.orbit ? tracker.start() : tracker.stop(); }, [layers.orbit]);
  useEffect(() => setBrowseMsg(""), [selectedId]);
  useEffect(() => setBsIssue(false), [layers.bs, layers.date]);

  const signedIn = (a) => { setAuth(a); sessionStorage.setItem("edl", JSON.stringify(a)); setLoginOpen(false); };
  const signOut = () => { if (auth) logout(auth.sid); setAuth(null); sessionStorage.removeItem("edl"); };

  // drop a stale session (e.g. backend restarted)
  useEffect(() => {
    if (auth) whoami(auth.sid).catch(() => { setAuth(null); sessionStorage.removeItem("edl"); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const runSearch = useCallback(async (f) => {
    setStatus({ state: "loading" });
    setDayFilter(null);
    try {
      const gj = await searchNisar(f);
      const feats = (gj.features || [])
        .filter((x) => x.geometry)
        .map((x) => ({ ...x, properties: { ...x.properties, _id: x.properties.sceneName || x.properties.fileID || String(x.id) } }))
        .sort((a, b) => (b.properties.startTime || "").localeCompare(a.properties.startTime || ""));
      const [t0, t1] = f.timeMode === "overlap" ? [-Infinity, Infinity] : timeWindow(f);
      const inside = feats.filter((x) => { const t = Date.parse(x.properties.startTime); return !Number.isFinite(t) || (t >= t0 && t <= t1); });
      setFeatures(inside);
      setStatus({ state: "done", hidden: feats.length - inside.length });
      setFitKey((k) => k + 1);
    } catch (e) {
      setFeatures([]);
      setStatus({ state: "error", message: e.message });
    }
  }, []);

  // run the search encoded in a shared link
  useEffect(() => {
    if (init.filters.bbox || init.sel) runSearch(init.filters);
  }, [init, runSearch]);

  useEffect(() => writeHash(filters, view.current, selectedId, layers), [filters, selectedId, layers]);

  const visible = useMemo(
    () => (dayFilter ? features.filter((f) => (f.properties.startTime || "").startsWith(dayFilter)) : features),
    [features, dayFilter]
  );
  const selected = features.find((f) => f.properties._id === selectedId) || null;

  const toggleBrowse = async () => {
    const f = selected;
    if (!f) return;
    const id = f.properties._id;
    if (overlays.some((o) => o.id === id)) return removeOverlay(id);
    const src = Array.isArray(f.properties.browse) ? f.properties.browse[0] : null;
    if (!src) return;
    setBrowseBusy(true);
    setBrowseMsg("");
    try {
      let blob;
      try {
        blob = await fetchBrowse(src, auth?.sid);
      } catch (err) {
        if (err.status === 401) setLoginOpen(true);
        if (err.status === 404 && err.detail === "Not Found")
          throw new Error("Your backend is out of date (it has no /api/browse). Stop it, then start it again from the newest nisar-explorer\\backend folder.");
        throw err;
      }
      const url = URL.createObjectURL(blob);
      const label = `${f.properties.processingLevel || "NISAR"} ${(f.properties.startTime || "").slice(0, 16).replace("T", " ")}`;
      const exact = await exactCorners(f, auth?.sid).catch(() => null); // from the granule's KML file
      const mode = exact ? "kml" : defaultMode(f);
      const coords = await fitCoords(blob, f, mode, exact);
      setOverlays((list) => (list.some((o) => o.id === id) ? list : [...list, { id, url, blob, feature: f, mode, exact, coords, label }]));
    } catch (e) {
      setBrowseMsg(e.message);
    } finally {
      setBrowseBusy(false);
    }
  };

  const showBackscatter = (f) => {
    setLayers((l) => ({ ...l, bs: true, date: f.properties.startTime.slice(0, 10), days: 1 }));
    setFocus({ id: f.properties._id, t: Date.now() });
  };

  const onDraw = (bbox) => {
    setFilters((f) => ({ ...f, bbox }));
    setDrawing(false);
    setAreaKey((k) => k + 1);
  };
  const onMove = (v) => {
    view.current = v;
    writeHash(filters, v, selectedId, layers);
  };
  const pick = (id) => { setSelectedId(id); setFocus({ id, t: Date.now() }); };

  // the dock follows what the person does
  useEffect(() => { if (selectedId) setTab("details"); }, [selectedId]);
  useEffect(() => { if (status.state === "done") setTab("granules"); }, [status.state]);
  const endIntro = (tour) => {
    setIntro(false);
    setFly({ center: [init.view[0], init.view[1]], zoom: init.view[2], t: Date.now() });
    try { localStorage.setItem("nisar-intro", "1"); } catch { /* ignore */ }
    if (tour) setTourReq((n) => n + 1);
  };
  const loadEvents = useCallback(async (p) => {
    setEventStatus({ state: "loading" });
    try {
      const d = await fetchEvents(p);
      setEvents(d.events || []);
      setEventStatus({ state: "done", warnings: d.warnings || [] });
    } catch (e) {
      setEvents([]);
      setEventStatus({ state: "error", message: e.message });
    }
  }, []);
  const selectedEvent = events.find((e) => e.id === selEventId) || null;
  // choosing an event takes you to the affected area, with the dates around it
  const selectEvent = (id) => {
    if (!id) { setSelEventId(null); return; }
    const ev = events.find((e) => e.id === id);
    if (!ev) return;
    setSelEventId(id);
    setTab("events");
    const { start, end } = eventRange(ev);
    setFilters((f) => ({ ...f, bbox: ev.bbox, start, end }));
    setAreaKey((k) => k + 1);
  };
  const mergeGranules = (list) => setFeatures((prev) => {
    const have = new Set(prev.map((x) => x.properties._id));
    const add = list.filter((x) => !have.has(x.properties._id));
    return add.length ? [...prev, ...add].sort((a, b) => (b.properties.startTime || "").localeCompare(a.properties.startTime || "")) : prev;
  });
  const showGranule = (g) => { mergeGranules([g]); pick(g.properties._id); };
  const analyseEventPair = (ev, p, level, mode) => {
    setBasket((b) => {
      const have = new Set(b.map((x) => x.properties._id));
      return [...b, ...[p.before, p.after].filter((x) => !have.has(x.properties._id))];
    });
    mergeGranules([p.before, p.after]);
    setFilters((f) => ({ ...f, bbox: analysisArea(ev, p.before, p.after) })); // the area both files really contain
    setWbPreset({ mode, aId: p.before.properties._id, bId: p.after.properties._id, t: Date.now() });
    setWbSeen(true);
    setWbOpen(true);
  };

  const onResult = (r) => {
    setAnalysisDone(true);
    if (r) { try { const it = interpret(r); setLastResult({ ...it, digest: digest(r, it) }); } catch { setLastResult(null); } }
  };
  const nisaContext = () => {
    const p = selected?.properties;
    return [
      `Side panel tab: ${tab}`,
      `Area: ${filters.bbox ? filters.bbox.map((n) => Number(n).toFixed(2)).join(", ") + " (west, south, east, north)" : "whole world"}`,
      `Dates (UTC): ${filters.start || "open"} to ${filters.end || "open"}`,
      `Granules found: ${features.length}${filters.mock ? " (demo data)" : ""}`,
      p ? `Selected granule: ${p.processingLevel}, ${p.startTime}, ${String(p.flightDirection || "").toLowerCase()}, track ${p.pathNumber}, frame ${p.frameNumber}, polarization ${p.polarization || "?"}` : "No granule selected",
      `Workbench holds ${basket.length} granule(s). 3D terrain: ${view3d.terrain ? "on" : "off"}. Globe: ${view3d.globe ? "on" : "off"}.`,
      selectedEvent ? `Selected event: ${selectedEvent.title}, ${selectedEvent.type}, ${selectedEvent.time}${selectedEvent.magnitude ? `, magnitude ${selectedEvent.magnitude}` : ""}` : "",
      lastResult ? `LATEST ANALYSIS RESULT\n${lastResult.digest}` : "No analysis has been run yet.",
    ].filter(Boolean).join("\n");
  };
  const nisaActions = {
    events: () => setTab("events"),
    draw: () => { setTab("search"); setDrawing(true); },
    search: () => runSearch(filters),
    terrain: () => setView3d((v) => ({ ...v, terrain: !v.terrain })),
    workbench: () => { setWbSeen(true); setWbOpen(true); },
    layers: () => setTab("layers"),
    guide: () => setGuideOpen(true),
  };
  const fmtDay = (v) => (v ? v.slice(0, 10) : "…");
  const tabs = [["search", "Search"], ["events", "Events"], ["granules", `Granules${features.length ? ` (${features.length})` : ""}`], ["layers", "Layers"], ["details", "Details"]];

  return (
    <div className={intro ? "app intro" : "app"}>
      <header className="topbar">
        <div className="logo"><span className="dot" aria-hidden="true" /><b>NISAR Explorer</b><small>Radar from space</small></div>
        <div className="ctx">
          <button className="ctxchip" onClick={() => setTab("search")} title="Change the area"><small>Area</small>{filters.bbox ? "Drawn box" : "Whole world"}</button>
          <button className="ctxchip" onClick={() => setTab("search")} title="Change the dates"><small>Dates (UTC)</small>{fmtDay(filters.start)} → {fmtDay(filters.end)}</button>
        </div>
        <nav className="tabsnav" role="tablist" aria-label="Side panel">
          {tabs.map(([k, l]) => (
            <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>
          ))}
        </nav>
        <div className="actions">
          <button className="link" onClick={() => setGuideOpen(true)}>Guide</button>
          <button className="link" onClick={() => { setWbSeen(true); setWbOpen(true); }}>Workbench ({basket.length})</button>
          <button className="link" onClick={() => setIntro(true)} title="Show the introduction again">Intro</button>
          {auth ? (
            <><span className="who">Earthdata: <b>{auth.user}</b></span><button className="link" onClick={signOut}>Sign out</button></>
          ) : (
            <button className="btn pill" onClick={() => setLoginOpen(true)} title="Downloads need an Earthdata login">Sign in</button>
          )}
        </div>
      </header>
      <main className="stage">
        <MapView events={events} selectedEventId={selEventId} onEventClick={selectEvent} fly={fly} view3d={view3d} areaKey={areaKey} ovFocus={ovFocus} mapCmd={mapCmd} features={visible} selectedId={selectedId} hoveredId={hoveredId} bbox={filters.bbox} drawing={drawing} view={init.view} fitKey={fitKey} focus={focus} layers={layers} follow={follow} overlays={overlays} overlayOpacity={overlayOpacity} opacities={opacities} context={context} inspect={!!inspect} pin={pin} onMapClick={onMapClick} onIssue={(k) => (k === "bs" ? setBsIssue(true) : k === "dem" ? (setDemIssue(true), setView3d((v) => ({ ...v, terrain: false }))) : setBrowseMsg("The browse image could not be drawn on the map."))} onDraw={onDraw} onSelect={pick} onHover={setHoveredId} onMove={onMove} />
        {intro ? (
          <Hero onStart={() => endIntro(false)} onTour={() => endIntro(true)} onFly={(at) => setFly({ ...at, t: Date.now() })} />
        ) : (
          <>
            <MapToolbar view3d={view3d} setView3d={(v) => { if (v.terrain) setDemIssue(false); setView3d(v); }} onCmd={(type) => setMapCmd({ type, t: Date.now() })} demIssue={demIssue} />
            <Mascot tourReq={tourReq} onTab={setTab} actions={nisaActions} result={lastResult} getContext={nisaContext} stage={{ searching: status.state === "loading", searched: status.state === "done", count: features.length, hasArea: !!filters.bbox, selected: !!selected, basket: basket.length, analysed: analysisDone, terrain: view3d.terrain, drawing, wbOpen, signedIn: !!auth }} />
            <PixelPanel res={pixelRes} error={pixelErr} onClose={() => { setPixelRes(null); setPixelErr(""); setPin(null); }} />
          </>
        )}
      </main>
      <aside className="dock" aria-label="Side panel">
        <div className="pane" hidden={tab !== "search"}>
          <Filters filters={filters} setFilters={setFilters} drawing={drawing} setDrawing={setDrawing} onSearch={() => runSearch(filters)} loading={status.state === "loading"} />
        </div>
        <div className="pane" hidden={tab !== "events"}>
          <Events events={events} status={eventStatus} selectedId={selEventId} selected={selectedEvent} onSelect={selectEvent} onLoad={loadEvents} onGranules={mergeGranules} onAnalyse={analyseEventPair} onShowGranule={showGranule} mock={!!filters.mock} />
        </div>
        <div className="pane results" hidden={tab !== "granules"}>
          <Results all={features} features={visible} status={status} selectedId={selectedId} onPick={pick} onHover={setHoveredId} dayFilter={dayFilter} setDayFilter={setDayFilter} />
          <Insights features={features} />
        </div>
        <div className="pane" hidden={tab !== "layers"}>
          <LayerPanel layers={layers} setLayers={setLayers} follow={follow} setFollow={setFollow} issue={bsIssue} overlays={overlays} onRemoveOverlay={removeOverlay} onOverlayMode={setOverlayMode} onClearOverlays={clearOverlays} overlayOpacity={overlayOpacity} setOverlayOpacity={setOverlayOpacity} context={context} setContext={setContext} compare={compare} setCompare={setCompare} />
        </div>
        <div className="pane" hidden={tab !== "details"}>
          {selected ? (
            <Detail feature={selected} onClose={() => { setSelectedId(null); setTab("granules"); }} auth={auth} onNeedLogin={() => setLoginOpen(true)} browseOn={overlays.some((o) => o.id === selected.properties._id)} browseBusy={browseBusy} browseMsg={browseMsg} onToggleBrowse={toggleBrowse} onShowBackscatter={showBackscatter} drawnBbox={filters.bbox} projectedIds={overlays.map((o) => o.id)} onProjectAnalysis={projectImage} onDone={onResult} inBasket={inBasket(selected)} onBasket={toggleBasket} inspecting={!!inspect} onInspect={startInspect} />
          ) : (
            <div className="empty">Nothing selected. Pick a granule in the list or click a footprint on the map to see what it holds and to analyse it.</div>
          )}
        </div>
        <footer className="foot">Data: NASA/ISRO NISAR via ASF DAAC. Calibrated products are provisional.</footer>
      </aside>
      <Timeline features={features} dayFilter={dayFilter} setDayFilter={setDayFilter} selectedDay={selected?.properties.startTime?.slice(0, 10)} loading={status.state === "loading"} />
      {guideOpen && <GuideDialog onClose={() => setGuideOpen(false)} onSearch={(code) => { setFilters((f) => ({ ...f, levels: [code] })); setGuideOpen(false); }} />}
      {wbSeen && <Workbench preset={wbPreset} open={wbOpen} basket={basket} onRemove={(id) => setBasket((l) => l.filter((b) => b.properties._id !== id))} onClear={() => setBasket([])} auth={auth} bbox={filters.bbox} onNeedLogin={() => setLoginOpen(true)} onProject={(im, id, label) => { projectImage(im, id, label); setWbOpen(false); }} projectedIds={overlays.map((o) => o.id)} onClose={() => setWbOpen(false)} onDone={onResult} />}
      {loginOpen && <LoginDialog onClose={() => setLoginOpen(false)} onSignedIn={signedIn} />}
    </div>
  );
}
