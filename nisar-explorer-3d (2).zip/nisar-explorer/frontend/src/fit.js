// Where to pin a browse image on the map.
//  auto    : crop away transparent edges, then stretch the visible part onto the footprint bounds
//  bounds  : stretch the whole image onto the footprint bounding box
//  corners : pin the image corners to the (slanted) footprint corners
const GEOCODED = ["GCOV", "GUNW", "GSLC", "GOFF", "SME2"];
export const defaultMode = (f) => (GEOCODED.includes(f.properties.processingLevel) ? "auto" : "corners");

function ring(f) {
  const g = f.geometry;
  return (g.type === "Polygon" ? g.coordinates[0] : g.coordinates[0][0]).slice(0, -1);
}

function boundsOf(f) {
  const r = ring(f);
  const lons = r.map((p) => p[0]);
  const lats = r.map((p) => p[1]);
  return [Math.min(...lons), Math.min(...lats), Math.max(...lons), Math.max(...lats)]; // w s e n
}

function boundsCorners([w, s, e, n]) {
  return [[w, n], [e, n], [e, s], [w, s]];
}

function footprintCorners(f) {
  const r = ring(f);
  if (r.length !== 4) return boundsCorners(boundsOf(f));
  const byLat = [...r].sort((a, b) => b[1] - a[1]);
  const top = byLat.slice(0, 2).sort((a, b) => a[0] - b[0]);
  const bot = byLat.slice(2).sort((a, b) => a[0] - b[0]);
  return [top[0], top[1], bot[1], bot[0]];
}

// fractions (0..1) of the image that hold real data, or null when the image has no transparent edges
async function validBox(blob) {
  const bmp = await createImageBitmap(blob);
  const k = Math.min(1, 600 / Math.max(bmp.width, bmp.height));
  const w = Math.max(1, Math.round(bmp.width * k));
  const h = Math.max(1, Math.round(bmp.height * k));
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0, w, h);
  const px = ctx.getImageData(0, 0, w, h).data;
  let x0 = w, y0 = h, x1 = -1, y1 = -1, clear = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (px[(y * w + x) * 4 + 3] < 12) { clear++; continue; }
      if (x < x0) x0 = x;
      if (x > x1) x1 = x;
      if (y < y0) y0 = y;
      if (y > y1) y1 = y;
    }
  }
  if (x1 < 0 || clear < w * h * 0.01) return null;
  return { fx0: x0 / w, fx1: (x1 + 1) / w, fy0: y0 / h, fy1: (y1 + 1) / h };
}

export async function fitCoords(blob, f, mode = defaultMode(f), exact = null) {
  if (mode === "kml" && exact) return exact;
  if (mode === "corners") return footprintCorners(f);
  const [w, s, e, n] = boundsOf(f);
  if (mode === "bounds") return boundsCorners([w, s, e, n]);
  const v = await validBox(blob).catch(() => null);
  if (!v) return boundsCorners([w, s, e, n]);
  // image fraction -> lon/lat, so the visible part spans exactly the footprint bounds
  const kx = (e - w) / (v.fx1 - v.fx0);
  const ky = (n - s) / (v.fy1 - v.fy0);
  const lon = (fx) => w + (fx - v.fx0) * kx;
  const lat = (fy) => n - (fy - v.fy0) * ky;
  return [[lon(0), lat(0)], [lon(1), lat(0)], [lon(1), lat(1)], [lon(0), lat(1)]];
}
