import { useMemo, useState } from "react";

const DAY = 864e5;
const fmtDate = (t) => new Date(t).toISOString().slice(0, 16).replace("T", " ");

// coverage insights computed from the current search results: revisit gaps and next passes
export default function Insights({ features }) {
  const [open, setOpen] = useState(false);

  const groups = useMemo(() => {
    const g = {};
    features.forEach((f) => {
      const p = f.properties;
      const t = Date.parse(p.startTime);
      if (!Number.isFinite(t)) return;
      (g[`${p.pathNumber ?? "?"}|${p.flightDirection ?? "?"}`] ||= []).push(t);
    });
    const now = Date.now();
    return Object.entries(g).map(([k, ts]) => {
      ts.sort((a, b) => a - b);
      const gaps = ts.slice(1).map((t, i) => (t - ts[i]) / DAY);
      const med = gaps.length ? [...gaps].sort((a, b) => a - b)[Math.floor(gaps.length / 2)] : null;
      let next = ts[ts.length - 1] + 12 * DAY;
      while (next <= now) next += 12 * DAY;
      const [path, dir] = k.split("|");
      return { path, dir, n: ts.length, first: ts[0], last: ts[ts.length - 1], med, max: gaps.length ? Math.max(...gaps) : null, next };
    }).sort((a, b) => a.next - b.next);
  }, [features]);

  if (!features.length) return null;
  return (
    <details className="insights" open={open} onToggle={(e) => setOpen(e.currentTarget.open)}>
      <summary>Coverage and next passes</summary>
      <div className="tablewrap">
        <table className="mini">
          <thead><tr><th>Track</th><th>Orbit</th><th>Count</th><th>Median gap</th><th>Longest gap</th><th>Next (predicted, UTC)</th></tr></thead>
          <tbody>
            {groups.map((g) => (
              <tr key={g.path + g.dir}>
                <td>{g.path}</td><td>{g.dir.toLowerCase()}</td><td>{g.n}</td>
                <td>{g.med == null ? "-" : `${g.med.toFixed(1)} d`}</td><td>{g.max == null ? "-" : `${g.max.toFixed(1)} d`}</td>
                <td>{fmtDate(g.next)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="hint">Next pass = latest acquisition of the track + 12-day steps (NISAR repeats every 12 days). It is a prediction: the observation plan can change.</p>
    </details>
  );
}
