import { useEffect, useMemo, useState } from "react";
import { searchNisar } from "./api.js";
import { eventRange, fmtGap, modeFor, sideCounts, suggestPairs } from "./eventPairs.js";

export const NISAR_START = "2026-06-17"; // public NISAR data starts here: earlier events cannot have files

const MODE_TEXT = { flood: "flood extent", gcov_change: "change map (damage, surface change)", gslc_change: "amplitude change" };
const day = (iso) => (iso || "").slice(0, 10);
const norm = (gj) =>
  (gj.features || [])
    .filter((x) => x.geometry)
    .map((x) => ({ ...x, properties: { ...x.properties, _id: x.properties.sceneName || x.properties.fileID || String(x.id) } }));

export default function Events({ events, status, selectedId, onSelect, onLoad, onGranules, onAnalyse, onShowGranule, mock, selected }) {
  const [types, setTypes] = useState({ flood: true, earthquake: true });
  const [minmag, setMinmag] = useState(5.5);
  const [from, setFrom] = useState(NISAR_START);
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));
  const [level, setLevel] = useState("GCOV");
  const [wide, setWide] = useState(false);
  const [found, setFound] = useState({ state: "idle", granules: [] });

  // (re)load the list when the controls change
  useEffect(() => {
    const t = Object.keys(types).filter((k) => types[k]);
    onLoad({ types: t.length ? t : ["flood", "earthquake"], start: from, end: to, minmag, mock });
  }, [types, minmag, from, to, mock]); // eslint-disable-line react-hooks/exhaustive-deps

  // looking for files whenever another event is selected (or the period is widened)
  useEffect(() => {
    if (!selected) { setFound({ state: "idle", granules: [] }); return undefined; }
    let dead = false;
    setFound({ state: "loading", granules: [] });
    const { start, end } = eventRange(selected, wide);
    searchNisar({ bbox: selected.bbox, start, end, levels: ["GCOV", "GSLC"], direction: "", mock })
      .then((gj) => {
        if (dead) return;
        const granules = norm(gj);
        setFound({ state: "done", granules });
        onGranules?.(granules);
      })
      .catch((e) => !dead && setFound({ state: "error", message: e.message, granules: [] }));
    return () => { dead = true; };
  }, [selected?.id, wide, mock]); // eslint-disable-line react-hooks/exhaustive-deps

  const levels = useMemo(() => ["GCOV", "GSLC"].filter((l) => found.granules.some((g) => g.properties.processingLevel === l)), [found]);
  const lvl = levels.includes(level) ? level : levels[0] || level;
  const pairs = useMemo(() => (selected ? suggestPairs(selected, found.granules, lvl).slice(0, 5) : []), [selected, found, lvl]);
  const counts = useMemo(() => (selected ? sideCounts(selected, found.granules, lvl) : null), [selected, found, lvl]);
  const early = selected && day(selected.time) < NISAR_START;

  return (
    <div className="events">
      <div className="evfilters">
        <div className="chips" role="group" aria-label="Event types">
          <button className={types.flood ? "chip on" : "chip"} aria-pressed={types.flood} onClick={() => setTypes((t) => ({ ...t, flood: !t.flood }))}>Floods</button>
          <button className={types.earthquake ? "chip on" : "chip"} aria-pressed={types.earthquake} onClick={() => setTypes((t) => ({ ...t, earthquake: !t.earthquake }))}>Earthquakes</button>
        </div>
        <div className="row">
          <label className="field"><span className="label">From</span><input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} /></label>
          <label className="field"><span className="label">To</span><input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} /></label>
        </div>
        {types.earthquake && (
          <label className="field"><span className="label">Earthquakes from magnitude</span>
            <select value={minmag} onChange={(e) => setMinmag(+e.target.value)}>{[4.5, 5, 5.5, 6, 6.5, 7].map((m) => <option key={m} value={m}>{m}</option>)}</select>
          </label>
        )}
        <p className="hint">NISAR public data starts on {NISAR_START}, so only events after that date can have before and after files.</p>
      </div>

      {status.state === "loading" && <p className="hint">Loading events…</p>}
      {status.state === "error" && <p className="err">{status.message}</p>}
      {(status.warnings || []).map((w) => <p key={w} className="note">{w}</p>)}

      {selected && (
        <section className="evdetail" aria-label="Selected event">
          <header>
            <span className={`evdot ${selected.type}`} aria-hidden="true" />
            <h3>{selected.title}</h3>
            <button className="x" onClick={() => onSelect(null)} aria-label="Close event">×</button>
          </header>
          <p className="hint">
            {selected.type === "earthquake" ? `Magnitude ${selected.magnitude}` : "Flood"} · {day(selected.time)}{selected.end && day(selected.end) !== day(selected.time) ? ` to ${day(selected.end)}` : ""}
            {selected.place ? ` · ${selected.place}` : ""} · {selected.source}{selected.severity ? ` · alert ${selected.severity}` : ""}
            {selected.url && <> · <a href={selected.url} target="_blank" rel="noopener noreferrer">more about this event</a></>}
          </p>
          {selected.demo && <p className="note">Synthetic demo event, for trying the workflow.</p>}
          {early && <p className="note">This event happened before NISAR public data began, so no files are expected.</p>}

          <div className="evsteps">
            <b>Before and after files</b>
            {levels.length > 1 && (
              <div className="chips" role="group" aria-label="Product">
                {levels.map((l) => <button key={l} className={l === lvl ? "chip on" : "chip"} onClick={() => setLevel(l)}>{l}</button>)}
              </div>
            )}
            {found.state === "loading" && <p className="hint">Searching the archive around the event…</p>}
            {found.state === "error" && <p className="err">{found.message}</p>}
            {found.state === "done" && pairs.length === 0 && (
              <div className="evnone">
                <p>No usable pair yet.{counts ? ` Found ${counts.before} file${counts.before === 1 ? "" : "s"} before and ${counts.after} after the event, but none of the same track, frame and direction on both sides.` : ""}</p>
                {!wide && <button className="btn" onClick={() => setWide(true)}>Look further in time</button>}
                {wide && <p className="hint">Even the wider period has no pair. NISAR revisits every 12 days, so files after the event may not be published yet.</p>}
              </div>
            )}
            {pairs.map((p, i) => (
              <article key={p.key} className={`evpair${i === 0 ? " best" : ""}`}>
                <div className="evpair-top"><b>{i === 0 ? "Best match · " : ""}track {p.track} · frame {p.frame} · {p.direction}</b><span className={p.covers ? "badge" : "badge alt"}>{p.covers ? "covers the event" : "near the event"}</span></div>
                <div className="evpair-dates">
                  <button className="link" onClick={() => onShowGranule(p.before)}>Before: {day(p.before.properties.startTime)}</button> <small>({fmtGap(p.gapBefore)} before)</small><br />
                  <button className="link" onClick={() => onShowGranule(p.after)}>After: {day(p.after.properties.startTime)}</button> <small>({fmtGap(p.gapAfter)} after)</small>
                </div>
                <div className="actions">
                  <button className="btn solid" onClick={() => onAnalyse(selected, p, lvl, modeFor(selected, lvl))}>Analyse in workbench</button>
                </div>
                <small className="hint">Opens the workbench with this pair and the {MODE_TEXT[modeFor(selected, lvl)]} analysis chosen.</small>
              </article>
            ))}
          </div>
        </section>
      )}

      <p className="count">{events.length} event{events.length === 1 ? "" : "s"}</p>
      {status.state === "done" && events.length === 0 && <div className="empty">No events for these choices. Widen the dates, lower the magnitude, or turn another type on.</div>}
      <ul className="list">
        {events.map((e) => (
          <li key={e.id}>
            <button className={`item evitem${e.id === selectedId ? " on" : ""}`} onClick={() => onSelect(e.id)}>
              <span className="item-top"><b><span className={`evdot ${e.type}`} aria-hidden="true" />{e.title}</b></span>
              <span className="item-sub">{day(e.time)} · {e.type === "earthquake" ? `M ${e.magnitude}` : "flood"}{e.severity ? ` · ${e.severity}` : ""} · {e.source}</span>
            </button>
          </li>
        ))}
      </ul>
      <p className="hint">Sources: USGS earthquakes, GDACS and NASA EONET floods. Flood areas are approximate.</p>
    </div>
  );
}
