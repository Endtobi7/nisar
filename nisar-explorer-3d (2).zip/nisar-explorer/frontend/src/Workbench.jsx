import { useEffect, useMemo, useState } from "react";
import { compare, runSeries } from "./api.js";
import { loadCatalog } from "./catalogStore.js";
import ResultView from "./ResultView.jsx";

const PAIR_PARAMS = {
  gcov_change: [["k_sigma", "Change limit (x noise)", 3, 0.5], ["looks", "Looks in the average", 25, 1]],
  flood: [["water_core_db", "Water: very dark below (dB)", -20, 1], ["water_grow_db", "Water: grow into pixels below (dB)", -17, 1], ["max_slope", "Ignore terrain steeper than (degrees)", 10, 1], ["dem", "DEM file path (optional, GeoTIFF)", "", 0]],
  deforest: [["hv_drop", "HV drop (dB)", 2, 0.5]],
  coherence_change: [["drop", "Coherence drop", 0.3, 0.05]],
  vertical_ew: [["incidence", "Incidence angle (degrees)", 39, 1]],
};
const SERIES_PARAMS = { first_change: [["k_sigma", "Change limit (x sigma)", 3, 0.5]], velocity: [["coh_min", "Minimum coherence", 0.6, 0.05]] };

const label = (f) => {
  const p = f.properties;
  return `${p.processingLevel} · ${(p.startTime || "").slice(0, 16).replace("T", " ")} · ${String(p.flightDirection || "").toLowerCase()} · track ${p.pathNumber ?? "?"}`;
};

export default function Workbench({ preset, open = true, onDone, basket, onRemove, onClear, auth, bbox, onNeedLogin, onProject, projectedIds, onClose }) {
  const [tab, setTab] = useState("pair");
  const [cat, setCat] = useState(undefined);
  const items = useMemo(() => [...basket].sort((a, b) => (a.properties.startTime || "").localeCompare(b.properties.startTime || "")), [basket]);
  const [ia, setIa] = useState(0);
  const [ib, setIb] = useState(1);
  const [mode, setMode] = useState("");
  const [smode, setSmode] = useState("");
  const [params, setParams] = useState({});
  const [baseline, setBaseline] = useState(12);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState(null);
  const [resKey, setResKey] = useState("");

  useEffect(() => { loadCatalog().then(setCat); }, []);
  useEffect(() => {
    if (!open) return undefined;
    const esc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose, open]);

  // a pair sent from the events panel: select it and the matching analysis
  const [appliedPreset, setAppliedPreset] = useState(null);
  useEffect(() => {
    if (!preset || appliedPreset === preset.t) return;
    const i = items.findIndex((f) => f.properties._id === preset.aId), j = items.findIndex((f) => f.properties._id === preset.bId);
    if (i < 0 || j < 0) return;
    setTab("pair"); setIa(i); setIb(j); setMode(preset.mode); setRes(null); setAppliedPreset(preset.t);
  }, [preset, items, appliedPreset]);

  const A = items[ia], B = items[ib];
  const pairModes = (cat?.pairs || []).filter((m) => A && B && m.a.includes(A.properties.processingLevel) && m.b.includes(B.properties.processingLevel));
  const prods = [...new Set(items.map((f) => f.properties.processingLevel))];
  const seriesModes = (cat?.series || []).filter((m) => prods.length === 1 && m.product === prods[0]);
  const curPair = pairModes.find((m) => m.key === mode) || pairModes[0];
  const curSeries = seriesModes.find((m) => m.key === smode) || seriesModes[0];
  const fields = tab === "pair" ? PAIR_PARAMS[curPair?.key] || [] : SERIES_PARAMS[curSeries?.key] || [];
  const demo = items.length > 0 && items.every((f) => f.properties._demo);

  const go = async () => {
    if (!demo && !auth) return onNeedLogin();
    setBusy(true); setErr(""); setRes(null);
    try {
      const common = { sid: auth?.sid, bbox, baselineDays: baseline, params };
      if (tab === "pair") {
        const r = await compare({ urlA: A.properties.url, urlB: B.properties.url, mode: curPair.key, ...common });
        setRes(r);
        onDone?.(r);
        setResKey(`pair-${A.properties._id}-${B.properties._id}`);
      } else {
        const r = await runSeries({ urls: items.map((f) => f.properties.url), times: items.map((f) => f.properties.startTime), mode: curSeries.key, ...common });
        setRes(r);
        onDone?.(r);
        setResKey(`series-${curSeries.key}`);
      }
    } catch (e) {
      if (e.status === 401) onNeedLogin();
      setErr(e.status === 404 && e.detail === "Not Found" ? "Your backend is out of date. Restart it from the newest nisar-explorer\\backend folder." : e.message);
    } finally { setBusy(false); }
  };

  return (
    <div className="overlay" hidden={!open} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog workspace" role="dialog" aria-modal="true" aria-labelledby="wb-title">
        <header className="dhead"><h2 id="wb-title">Analysis workbench</h2><button className="x" onClick={onClose} aria-label="Close">×</button></header>
        <div className="wb-cols">
        <div className="wb-controls">
        <p className="hint">Combine several granules: select a granule on the map, press <b>Add to workbench</b> in its panel, then choose an analysis. Files must share track, frame, orbit direction and grid.</p>

        <div className="basket">
          <div className="coverage-head"><b>Workbench ({items.length})</b>{items.length > 0 && <button className="link" onClick={onClear}>Remove all</button>}</div>
          {items.length === 0 && <p className="hint">Empty. Add granules first.</p>}
          <ul className="ovlist">
            {items.map((f) => (
              <li key={f.properties._id}><span title={f.properties.sceneName}>{label(f)}</span><button className="x" onClick={() => onRemove(f.properties._id)} aria-label="Remove">×</button></li>
            ))}
          </ul>
        </div>

        <div className="tabs" role="tablist">
          <button role="tab" aria-selected={tab === "pair"} className={tab === "pair" ? "tab on" : "tab"} onClick={() => { setTab("pair"); setRes(null); setParams({}); }}>Two files</button>
          <button role="tab" aria-selected={tab === "series"} className={tab === "series" ? "tab on" : "tab"} onClick={() => { setTab("series"); setRes(null); setParams({}); }}>Time series</button>
        </div>

        {cat === null && <p className="err">The analyses list could not be loaded. Start (or restart) the newest backend.</p>}

        {tab === "pair" && (
          items.length < 2 ? <p className="hint">Add at least two granules.</p> : (
            <div className="wbform">
              <label className="field"><span className="label">File A</span>
                <select value={ia} onChange={(e) => { setIa(+e.target.value); setRes(null); }}>{items.map((f, i) => <option key={i} value={i}>{label(f)}</option>)}</select></label>
              <label className="field"><span className="label">File B</span>
                <select value={ib} onChange={(e) => { setIb(+e.target.value); setRes(null); }}>{items.map((f, i) => <option key={i} value={i}>{label(f)}</option>)}</select></label>
              {pairModes.length === 0 ? <p className="hint">No two-file analysis fits these two products. Examples: GCOV with GCOV (change, flood, deforestation), GUNW with GUNW (coherence change, vertical and east-west), GCOV with GUNW or SME2.</p> : (
                <label className="field"><span className="label">Analysis</span>
                  <select value={curPair.key} onChange={(e) => { setMode(e.target.value); setRes(null); }}>{pairModes.map((m) => <option key={m.key} value={m.key}>{m.title}</option>)}</select>
                  <span className="hint">{curPair.hint}</span></label>
              )}
            </div>
          )
        )}
        {tab === "series" && (
          prods.length > 1 ? <p className="hint">Time series need granules of one product type. Yours: {prods.join(", ")}.</p> :
          items.length < 3 ? <p className="hint">Add at least three granules of the same track and frame.</p> : (
            <div className="wbform">
              <label className="field"><span className="label">Analysis</span>
                <select value={curSeries?.key || ""} onChange={(e) => { setSmode(e.target.value); setRes(null); }}>{seriesModes.map((m) => <option key={m.key} value={m.key}>{m.title} (at least {m.min_files} files)</option>)}</select></label>
              {seriesModes.length === 0 && <p className="hint">No series analysis for {prods[0]}. Series exist for GCOV, GUNW, GOFF and SME2.</p>}
            </div>
          )
        )}

        {fields.map(([k, lab, def, step]) => (
          <label key={k} className="field"><span className="label">{lab}</span>{typeof def === "string"
            ? <input type="text" value={params[k] ?? def} onChange={(e) => setParams({ ...params, [k]: e.target.value })} />
            : <input type="number" step={step} value={params[k] ?? def} onChange={(e) => setParams({ ...params, [k]: +e.target.value })} />}</label>
        ))}
        {((tab === "series" && ["velocity", "speed_series"].includes(curSeries?.key)) || (tab === "pair" && curPair?.key === "goff_gunw")) && (
          <label className="field"><span className="label">Days between acquisitions of a pair</span><input type="number" min="1" value={baseline} onChange={(e) => setBaseline(+e.target.value || 12)} /></label>
        )}
        <p className="hint">Area: {bbox ? "your drawn box (it must lie inside all the granules)" : "the centre of the first granule"}.</p>
        <button className="btn solid" onClick={go} disabled={busy || (tab === "pair" ? !curPair || items.length < 2 : !curSeries || items.length < 3 || prods.length > 1)}>
          {busy ? "Reading the files…" : !demo && !auth ? "Sign in to analyse" : "Run analysis"}
        </button>
        {busy && <p className="hint">Several files are read in turn: this can take a minute or more.</p>}
        {err && <p className="err" role="alert">{err}</p>}
        </div>
        <div className="wb-results">
          {!res && !busy && <div className="wb-empty"><b>Results appear here</b><p>Pick an analysis on the left and press Run analysis. You get a plain-language reading, every number explained, charts, maps and a printable report.</p></div>}
          {busy && <div className="wb-empty"><b>Reading the files…</b><p>The satellite files are read in small windows, one after the other.</p></div>}
          {res && <ResultView res={res} idPrefix={resKey} projectedIds={projectedIds} onProject={(im, id) => onProject(im, id, `${res.product} · ${im.name}`)} title={res.product} context={{ granules: items.map((f) => f.properties), bbox }} />}
        </div>
        </div>
      </div>
    </div>
  );
}
