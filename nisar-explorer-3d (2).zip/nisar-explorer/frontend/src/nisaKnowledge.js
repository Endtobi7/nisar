// What Nisa can answer without any server: how the app works, radar terms, and every analysis in the guide.
import { GUIDE } from "./guideData.js";

const APP = [
  { k: ["event", "flood", "earthquake", "quake", "disaster", "before and after", "affected", "damage", "tremor", "inundation"], a: "Open the Events tab. It lists recent floods (GDACS, NASA EONET) and earthquakes (USGS) and shows them as markers on the globe. Pick one: I take you to the affected area, set the dates around it and look for NISAR files from the same track, frame and direction before and after the event. Then press Analyse in workbench to run the flood or change analysis on that pair.", act: "events", label: "Open Events" },
  { k: ["draw", "area", "box", "rectangle", "region", "zone", "bbox"], a: "Open the Search tab, press Draw box, drag a rectangle on the map and let go. The map zooms to it. Press Clear to go back to the whole world.", act: "draw", label: "Draw a box" },
  { k: ["search", "find data", "granule", "acquisition", "look for"], a: "Pick your dates and product type in the Search tab, then press Search NISAR. No account is needed to search. The results appear in the Granules tab and on the timeline.", act: "search", label: "Search now" },
  { k: ["login", "log in", "logged in", "sign in", "sign-in", "earthdata", "download", "account", "password", "cookie"], a: "Searching is public. Reading or analysing the real files needs a free NASA Earthdata login: press Sign in at the top right. Demo data needs no login." },
  { k: ["demo", "synthetic", "fake", "try it", "no login", "no backend"], a: "Tick Demo data in the Search tab to try everything with synthetic files. It is not real NISAR data, but every analysis works." },
  { k: ["3d", "terrain", "relief", "tilt", "mountain", "elevation", "hill"], a: "Press 3D terrain in the toolbar at the bottom of the map. The ground becomes relief, and your results are draped over it. Drag with the right mouse button to tilt and rotate, and use the Relief slider to exaggerate the hills.", act: "terrain", label: "Toggle 3D terrain" },
  { k: ["globe", "sphere", "planet", "spin"], a: "The Globe button turns the map into a sphere. It flattens into the normal map as you zoom in." },
  { k: ["basemap", "satellite", "dark", "streets", "background", "style"], a: "Dark, Streets and Satellite are in the map toolbar. Dark is built from OpenStreetMap, so it needs no key." },
  { k: ["layer", "gibs", "rain", "imerg", "mosaic", "orbit", "tracker", "overlay", "opacity", "crossfade"], a: "The Layers tab holds the NISAR backscatter mosaic, optical and rainfall context, the live orbit tracker, and the images you projected from analyses (with opacity and a crossfade).", act: "layers", label: "Open Layers" },
  { k: ["workbench", "compare", "two dates", "time series", "several", "before and after", "change"], a: "Add granules to the workbench from the Details tab, then open the Workbench at the top. It compares two dates (change, floods, damage, motion) or follows many dates over time.", act: "workbench", label: "Open the workbench" },
  { k: ["report", "print", "pdf", "paper"], a: "Every result has an Open printable report button. The report has a summary, each number explained, charts, images and limits. Use Print / Save as PDF." },
  { k: ["meaning", "interpret", "what does this result", "explain result", "numbers"], a: "Each result starts with What this means, then every number with a plain reading. Press What is this? under a number for its definition. Click Read aloud in my bubble to hear the headline." },
  { k: ["export", "geotiff", "csv", "qgis", "excel", "save image"], a: "Under each image you can export GeoTIFF (with map coordinates), CSV and PNG." },
  { k: ["tour", "help", "how do i start", "getting started", "lost"], a: "I can walk you through the screen in six steps.", act: "tour", label: "Take the tour" },
  { k: ["guide", "documentation", "how is it calculated", "method", "formula"], a: "The Guide lists every analysis with its method, formulas and cautions, in English and French.", act: "guide", label: "Open the guide" },
  { k: ["click", "pixel", "inspect", "value at"], a: "In Details, press Inspect a point, then click the map to read the exact value at that pixel." },
];

const TERMS = [
  { k: ["backscatter", "gamma", "sigma", "echo", "brightness"], a: "Backscatter is the share of the radar signal that returns to the satellite. It is shown in dB: more negative means darker. Calm water is very dark, vegetation is mid-range, buildings and rough rock are bright." },
  { k: ["db", "decibel"], a: "dB is a logarithmic scale. Every 3 dB is a doubling of power. For L-band backscatter, below about -20 dB is very dark (water or smooth ground), around -15 to -8 is typical vegetation and soil, above -8 is bright." },
  { k: ["polarisation", "polarization", "hh", "hv", "vv", "vh", "cross-pol", "co-pol"], a: "HH and VV send and receive the same wave orientation. HV and VH mix them, and respond to vegetation volume. A strong HV means more plants." },
  { k: ["coherence"], a: "Coherence is a 0 to 1 score of how stable the surface stayed between two dates. Above about 0.6 the phase can be trusted. Below 0.3 the surface changed too much (water, dense vegetation, damage)." },
  { k: ["interferogram", "fringe", "phase", "wrapped", "unwrapped", "insar", "line of sight", "displacement"], a: "Two passes over the same place give a phase difference. One full colour cycle (a fringe) is about 12 cm of ground motion toward or away from the satellite. Dense fringes mean fast change, and the result is relative to a reference level." },
  { k: ["speckle", "looks", "enl", "noise", "grain"], a: "Radar images are naturally grainy (speckle). Averaging several looks smooths it at the cost of detail. A higher equivalent number of looks means a cleaner image." },
  { k: ["gcov"], a: "GCOV is the geocoded backscatter product: terrain-corrected radar brightness on a map grid. Most analyses start from it." },
  { k: ["gunw"], a: "GUNW is the geocoded unwrapped interferogram at 80 m: it holds the ground motion between two dates, plus coherence." },
  { k: ["goff", "roff", "offset", "glacier", "feature tracking"], a: "GOFF holds pixel offsets from image matching. It is noisier than phase but measures fast motion such as glaciers and landslides." },
  { k: ["gslc", "rslc", "complex", "slc"], a: "GSLC and RSLC hold amplitude and phase for every pixel at full resolution. One date gives amplitude; phase needs two dates." },
  { k: ["sme2", "soil moisture", "wet", "dry"], a: "SME2 is the soil-moisture product on a 200 m grid with uncertainty layers. The analyses give dry and wet shares and anomalies against usual conditions." },
  { k: ["dem", "shadow", "layover", "slope", "steep"], a: "Steep terrain can hide ground from the radar (shadow, dark) or fold it over (layover, bright). Shadow can look like water, so give a DEM or check an optical image." },
  { k: ["flood", "inundation", "water map"], a: "Open water looks dark to radar. The flood analysis compares two dates and counts newly dark ground that was not permanent water. Radar shadow and wind-roughened water are the main traps, so confirm with optical data." },
  { k: ["deforest", "forest loss", "burn", "clear"], a: "Losing canopy lowers the cross-polarised (HV) signal. The deforestation analysis flags patches where HV dropped about 2 dB or more between the dates." },
  { k: ["subsidence", "uplift", "landslide", "earthquake", "deformation", "ground motion"], a: "Ground motion shows up as displacement along the line of sight in an interferogram. Under about 2 cm is usually noise and atmosphere; a smooth compact patch is more convincing than a broad gentle slope." },
  { k: ["rvi", "vegetation index"], a: "The radar vegetation index runs from about 0 for bare ground to 1 for dense vegetation. It is computed as 4 x HV / (HH + HV)." },
  { k: ["ascending", "descending", "track", "frame", "orbit direction", "pass"], a: "NISAR passes the same place from two directions, ascending and descending. Track and frame identify the strip and the piece along it. Two-date analyses need the same track, frame and direction." },
  { k: ["l-band", "wavelength", "nisar", "satellite", "mission"], a: "NISAR is a NASA-ISRO satellite with L-band radar (wavelength about 24 cm). It images almost all land and ice every 12 days, through cloud and darkness, and L-band penetrates vegetation better than shorter wavelengths." },
  { k: ["z-score", "anomaly"], a: "A z-score is how many standard deviations a value sits from its usual level. Beyond plus or minus 2 is unusual." },
];

const GUIDE_ITEMS = GUIDE.items.map((it) => ({ id: it.id, name: it.name.en, tells: it.tells?.en || "", needs: it.needs?.en || "", status: it.status, caution: it.caution?.en || "" }));
const STOP = new Set(["what", "does", "this", "that", "with", "from", "have", "your", "about", "mean", "means", "tell", "show", "analysis", "analyses", "how", "the", "and", "for", "can", "you", "are", "is", "do", "i", "to", "a", "of", "in", "it", "my", "me", "when", "where", "why", "which", "use"]);

const score = (q, k) => k.reduce((n, w) => n + (q.includes(w) ? (w.includes(" ") ? 3 : 2) : 0), 0);

export function answer(question) {
  const q = ` ${question.toLowerCase().replace(/[^a-z0-9\u00c0-\u017f\- ]/g, " ")} `;
  if (q.trim().length < 2) return null;
  const pad = (e) => ({ ...e, s: score(q.replace(/ +/g, " "), e.k.map((w) => (w.length <= 3 ? ` ${w} ` : w))) });
  const best = [...APP.map(pad), ...TERMS.map(pad)].sort((a, b) => b.s - a.s)[0];
  const toks = q.split(/ +/).filter((t) => t.length >= 3 && !STOP.has(t));
  const g = GUIDE_ITEMS.map((it) => ({ it, s: toks.filter((t) => it.name.toLowerCase().includes(t)).length })).filter((x) => x.s > 0).sort((a, b) => b.s - a.s);
  const gTop = g[0];
  if (gTop && gTop.s >= 2 && (!best || best.s < 4)) {
    const it = gTop.it;
    const extra = it.status === "ready" ? "" : it.status === "partial" ? " It is only partly built in this app." : " It is described in the guide but not built yet.";
    return { text: `${it.name}. ${it.tells} It needs: ${it.needs}.${it.caution ? ` Careful: ${it.caution}` : ""}${extra}`, act: "guide", label: "Open the guide", related: g.slice(1, 4).map((x) => x.it.name) };
  }
  if (best && best.s > 0) return { text: best.a, act: best.act, label: best.label, related: g.slice(0, 3).map((x) => x.it.name) };
  if (gTop) return { text: `${gTop.it.name}. ${gTop.it.tells} It needs: ${gTop.it.needs}.`, act: "guide", label: "Open the guide", related: g.slice(1, 4).map((x) => x.it.name) };
  return { text: "I don't know that one yet. Try asking about a radar term (coherence, dB, backscatter), an analysis (flood, deforestation, velocity) or how to do something (draw an area, 3D, report).", act: "guide", label: "Open the guide" };
}

export const SUGGESTIONS = ["How do I find floods or earthquakes?", "How do I draw an area?", "What is coherence?", "What does dB mean?", "How do I compare two dates?", "How do I see it in 3D?"].slice(0, 5);
