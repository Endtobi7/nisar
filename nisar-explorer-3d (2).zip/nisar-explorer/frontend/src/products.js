// NISAR science products (source: NISAR Data User Guide, nisar-docs.asf.alaska.edu/products-overview)
// mapReady = geocoded, can be overlaid on a map. Level 0/1 are in radar coordinates.
export const GROUPS = [
  { id: "map", title: "Map-ready (Level 2 and 3)", note: "Analysis-ready, open to everyone" },
  { id: "radar", title: "Radar specialist (Level 0 and 1)", note: "Radar coordinates, need SAR software (e.g. ISCE3)" },
];

export const PRODUCTS = [
  {
    code: "GCOV", analysis: ["Backscatter in dB per polarization (median, 5-95%)", "HV minus HH, radar vegetation index", "Grey and false-colour images, placed on the map"], name: "Geocoded Polarimetric Covariance", level: "L2", group: "map", pair: false, pixel: "10, 20 or 80 m",
    contains: ["Polarimetric covariance terms (backscatter power for HH, HV...)", "Mask, number of looks, terrain-correction factor"],
    extract: ["Backscatter in dB for each polarization", "HV/HH ratio (vegetation structure)", "Change between two dates: deforestation, burn scars, floods (water looks dark)", "Crop and soil-moisture signals"],
    uses: "Biomass, soil moisture, disturbance, inundation, crop mapping",
  },
  {
    code: "GUNW", analysis: ["Line-of-sight change in cm, relative to the window", "Spread before and after removing the ionosphere", "Coherence statistics and decorrelated share", "Change and coherence images, placed on the map"], name: "Geocoded Unwrapped Interferogram", level: "L2", group: "map", pair: true, pixel: "80 m",
    contains: ["Unwrapped interferogram", "Coherence, connected components, ionospheric phase screen and its uncertainty"],
    extract: ["Ground movement along the radar line of sight (cm or less): earthquakes, volcanoes, subsidence, landslides", "Coherence map: low values mark damage or heavy change"],
    uses: "Ground displacement and damage mapping",
  },
  {
    code: "GOFF", analysis: ["Bulk shift removed, noise level, relative motion", "Implied speed over the time between dates", "Motion and range-offset images, placed on the map"], name: "Geocoded Pixel Offsets", level: "L2", group: "map", pair: true, pixel: "80 m",
    contains: ["Along-track and slant-range offsets", "Offset variances, correlation peak, cross-offset variance, signal-to-noise ratio"],
    extract: ["Fast, large movements such as glacier and ice-sheet flow", "Velocity = offset divided by the time between dates (12 days)"],
    uses: "Glaciers and ice sheets",
  },
  {
    code: "GSLC", analysis: ["Amplitude in dB (3x3 averaged) with statistics", "Amplitude image, placed on the map"], name: "Geocoded Single Look Complex", level: "L2", group: "map", pair: false, pixel: "5 to 40 m",
    contains: ["Complex radar signal for each polarization, in map coordinates", "Lookup tables to backscatter, mask for water and shadow/layover"],
    extract: ["Amplitude images", "Your own interferograms and change maps from pairs of dates"],
    uses: "Custom amplitude and interferometric analysis",
  },
  {
    code: "SME2", analysis: ["Soil-moisture statistics for each estimate", "Soil-moisture image, placed on the map"], name: "Soil Moisture (EASE-Grid 2.0)", level: "L3", group: "map", pair: false, pixel: "200 m",
    contains: ["Three soil-moisture estimates (DSG, PMI, TSR algorithms)", "Uncertainty, crop type and vegetation water content, algorithm parameters"],
    extract: ["Soil-moisture maps at field scale"],
    uses: "Drought warning, irrigation, reservoirs, crop yield",
  },
  {
    code: "RSLC", analysis: ["Amplitude statistics on a crop from the middle of the frame", "Preview image (radar geometry, not placed on the map)"], name: "Range-Doppler Single Look Complex", level: "L1", group: "radar", pair: false, pixel: "radar geometry",
    contains: ["Full-resolution focused complex image per polarization", "Calibration coefficients, satellite position, lookup tables to backscatter"],
    extract: ["Amplitude and phase at full resolution", "Your own interferograms and time-series ground motion from stacks", "Small targets (buildings, ships), your own map grid"],
    uses: "Custom SAR processing",
  },
  {
    code: "RIFG", analysis: ["Coherence statistics on a central crop", "Wrapped-phase colour wheel and coherence preview"], name: "Range-Doppler Wrapped Interferogram", level: "L1", group: "radar", pair: true, pixel: "30 m",
    contains: ["Wrapped interferogram (ellipsoid and topography removed)", "Coherence magnitude"],
    extract: ["Phase fringes and coherence", "Grounding lines of glaciers", "Your own phase unwrapping"],
    uses: "Grounding-line detection",
  },
  {
    code: "RUNW", analysis: ["Line-of-sight change and coherence on a central crop", "Preview images (radar geometry)"], name: "Range-Doppler Unwrapped Interferogram", level: "L1", group: "radar", pair: true, pixel: "80 m",
    contains: ["Unwrapped interferogram", "Coherence, connected components, ionospheric phase screen and uncertainty"],
    extract: ["Line-of-sight ground displacement", "Your own corrections; combine many pairs into a time series"],
    uses: "Solid-earth displacement",
  },
  {
    code: "ROFF", analysis: ["Offsets, noise level and relative motion on a central crop", "Preview images (radar geometry)"], name: "Range-Doppler Pixel Offsets", level: "L1", group: "radar", pair: true, pixel: "90 m",
    contains: ["Along-track and range offsets (unfiltered)", "Variances, correlation peak, signal-to-noise ratio"],
    extract: ["Large motion where phase methods fail (fast glaciers)", "Expect outliers: you must filter them yourself"],
    uses: "Cryosphere",
  },
  {
    code: "RRSD", analysis: ["Nothing to analyse: raw pulses must be focused with SAR software (ISCE3) first"], name: "Radar Raw Signal Data (L0B)", level: "L0", group: "radar", pair: false, pixel: "raw pulses",
    contains: ["Corrected, aligned radar pulse data", "Starting point for every other NISAR product"],
    extract: ["Your own focused images with your choice of processing and calibration"],
    uses: "Radar research and algorithm development",
  },
];

export const byCode = (c) => PRODUCTS.find((p) => p.code === c || (c === "L0B" && p.code === "RRSD"));
