import { useEffect, useState } from "react";

// cinematic opening: the globe flies between chapters while big light headlines explain what radar can do
export const CHAPTERS = [
  { key: "The planet", h: "Explore our planet in radar.", p: "NISAR, the NASA–ISRO satellite, scans almost all land and ice every 12 days with L-band radar. Search its data, analyse it here, see it in 3D.", at: { center: [25, 12], zoom: 1.5 } },
  { key: "Through clouds", h: "See through clouds and night.", p: "Radar makes its own light. Forests, crops and wetlands show up in any weather, which optical satellites cannot promise.", at: { center: [-62, -4], zoom: 3.3 } },
  { key: "Moving ground", h: "Watch the ground move.", p: "Compare two passes and measure subsidence, landslides, earthquakes and glaciers to the centimetre.", at: { center: [-119.5, 36.5], zoom: 5.3 } },
  { key: "Water", h: "Track floods as they happen.", p: "Open water looks dark to radar. Map floods and shifting rivers within hours of a pass.", at: { center: [90, 23.5], zoom: 4.3 } },
];

export default function Hero({ onStart, onTour, onFly }) {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => { onFly?.(CHAPTERS[i].at); }, [i]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (paused) return undefined;
    const t = setInterval(() => setI((k) => (k + 1) % CHAPTERS.length), 7500);
    return () => clearInterval(t);
  }, [paused]);
  const c = CHAPTERS[i];
  return (
    <section className="hero" aria-label="Introduction" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <p className="hero-kicker">NISAR · L-band radar · {String(i + 1).padStart(2, "0")} / {String(CHAPTERS.length).padStart(2, "0")}</p>
      <div className="hero-copy" key={i}>
        <h2>{c.h}</h2>
        <p>{c.p}</p>
        <div className="hero-btns">
          <button className="hero-go" onClick={onStart}>Start exploring <span aria-hidden="true">→</span></button>
          <button className="hero-link" onClick={onTour}>Take the tour</button>
        </div>
      </div>
      <nav className="hero-chapters" aria-label="Chapters">
        {CHAPTERS.map((ch, k) => (
          <button key={ch.key} className={k === i ? "on" : ""} onClick={() => setI(k)} aria-current={k === i}>
            <i aria-hidden="true" />
            <span>{ch.key}</span>
          </button>
        ))}
      </nav>
    </section>
  );
}
