export default function PixelPanel({ res, error, onClose }) {
  if (!res && !error) return null;
  return (
    <aside className="pixelpanel" aria-label="Pixel values">
      <header><h2>Pixel inspector</h2><button className="x" onClick={onClose} aria-label="Close">×</button></header>
      {error && <p className="err" role="alert">{error}</p>}
      {res && (
        <>
          <p className="hint">{res.product} at {res.lat.toFixed(5)}, {res.lon.toFixed(5)}</p>
          <dl className="metrics">
            {res.layers.map((l, i) => (
              <div key={l.layer + i}><dt>{l.layer}</dt><dd>{l.value === null ? "no data" : Number(l.value).toPrecision(4)}{l.db != null && <small>{l.db.toFixed(1)} dB</small>}</dd></div>
            ))}
          </dl>
        </>
      )}
    </aside>
  );
}
