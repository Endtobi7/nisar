const COLORS = ["#2fd1c5", "#ff8a4c", "#a595ff", "#ffc83d", "#6aa7ff"];
const fmt = (v) => (Math.abs(v) >= 1000 || (Math.abs(v) < 0.01 && v !== 0) ? v.toExponential(1) : Number(v.toFixed(2)).toString());

// one chart for series that share the same axes (lines or scatter)
export function SeriesChart({ group }) {
  const W = 320, H = 150, L = 38, R = 8, T = 8, B = 28;
  const pts = group.flatMap((s) => s.x.map((x, i) => [x, s.y[i]])).filter(([x, y]) => y !== null && Number.isFinite(x) && Number.isFinite(y));
  if (!pts.length) return null;
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  let x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  if (x1 === x0) x1 = x0 + 1;
  if (y1 === y0) { y0 -= 0.5; y1 += 0.5; }
  const pad = (y1 - y0) * 0.08; y0 -= pad; y1 += pad;
  const sx = (x) => L + ((x - x0) / (x1 - x0)) * (W - L - R);
  const sy = (y) => T + (1 - (y - y0) / (y1 - y0)) * (H - T - B);
  const scatter = group[0].kind === "scatter";
  const labels = group[0].labels;
  return (
    <figure className="chart">
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={group.map((s) => s.name).join(", ")}>
        <rect className="c-plot" x={L} y={T} width={W - L - R} height={H - T - B} />
        {[0, 0.5, 1].map((t) => (
          <g key={t}>
            <line className="c-grid" x1={L} x2={W - R} y1={sy(y0 + (y1 - y0) * t)} y2={sy(y0 + (y1 - y0) * t)} />
            <text x={L - 4} y={sy(y0 + (y1 - y0) * t) + 3} className="c-tick" fontSize="9" textAnchor="end">{fmt(y0 + (y1 - y0) * t)}</text>
          </g>
        ))}
        {group.map((s, k) => {
          const c = COLORS[k % COLORS.length];
          if (scatter) return s.x.map((x, i) => <circle key={`${k}-${i}`} cx={sx(x)} cy={sy(s.y[i])} r="1.8" fill={c} fillOpacity="0.45" />);
          const d = s.x.map((x, i) => (s.y[i] === null ? null : `${sx(x).toFixed(1)},${sy(s.y[i]).toFixed(1)}`)).filter(Boolean);
          return (
            <g key={k}>
              <polyline points={d.join(" ")} fill="none" stroke={c} strokeWidth="1.8" />
              {s.x.length <= 40 && s.x.map((x, i) => (s.y[i] === null ? null : <circle key={i} cx={sx(x)} cy={sy(s.y[i])} r="2.2" fill={c} />))}
            </g>
          );
        })}
        <text className="c-tick" x={L} y={H - 14} fontSize="9">{labels ? labels[0] : fmt(x0)}</text>
        <text className="c-tick" x={W - R} y={H - 14} fontSize="9" textAnchor="end">{labels ? labels[labels.length - 1] : fmt(x1)}</text>
        <text className="c-tick" x={(L + W - R) / 2} y={H - 3} fontSize="9" textAnchor="middle">{group[0].xlabel}{group[0].ylabel ? ` · ${group[0].ylabel}` : ""}</text>
      </svg>
      <figcaption className="legend">
        {group.map((s, k) => <span key={k}><i style={{ background: COLORS[k % COLORS.length] }} />{s.name}</span>)}
      </figcaption>
    </figure>
  );
}

export function groupSeries(series = []) {
  const g = {};
  series.forEach((s) => { (g[`${s.xlabel}|${s.ylabel}|${s.kind || "line"}|${(s.name || "").split(":")[0]}`] ||= []).push(s); });
  return Object.values(g);
}

export function Hist({ hist, unit }) {
  if (!hist) return null;
  const max = Math.max(...hist.counts, 1);
  return (
    <div className="hist" aria-label="Histogram of the values">
      <div className="hbars">{hist.counts.map((c, i) => <span key={i} style={{ height: `${(c / max) * 100}%` }} />)}</div>
      <div className="haxis"><span>{fmt(hist.min)}</span><span>histogram {unit || ""}</span><span>{fmt(hist.max)}</span></div>
    </div>
  );
}
