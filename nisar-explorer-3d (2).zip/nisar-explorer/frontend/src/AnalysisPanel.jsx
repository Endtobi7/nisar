import { useEffect, useState } from "react";
import { analyse } from "./api.js";
import { byCode } from "./products.js";
import { loadCatalog, family } from "./catalogStore.js";
import ResultView from "./ResultView.jsx";

const bounds = (f) => {
  const g = f.geometry;
  const ring = g.type === "Polygon" ? g.coordinates[0] : g.coordinates[0][0];
  const lons = ring.map((p) => p[0]), lats = ring.map((p) => p[1]);
  return [Math.min(...lons), Math.min(...lats), Math.max(...lons), Math.max(...lats)];
};
const intersect = (a, b) => {
  const r = [Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.min(a[2], b[2]), Math.min(a[3], b[3])];
  return r[0] < r[2] && r[1] < r[3] ? r : null;
};

// [key, label, default, step, extras that use it]
const PARAMS = {
  GCOV: [["kclusters", "Land-cover groups (k)", 5, 1, "landcover"],
    ["water_core_db", "Water: very dark below (dB)", -20, 1, "water"], ["water_grow_db", "Water: grow into pixels below (dB)", -17, 1, "water"],
    ["max_slope", "Water: ignore terrain steeper than (degrees)", 10, 1, "water"], ["dem", "Water: DEM file path (optional, GeoTIFF)", "", 0, "water"]],
  UNW: [["deform_cm", "Moving more than (cm)", 2, 0.5, "deform_area"], ["coh_min", "Minimum coherence", 0.6, 0.05, "deform_area reliable"], ["looks", "Number of looks", 20, 1, "uncertainty"]],
  OFF: [["corr_min", "Minimum correlation peak", 0.1, 0.05, "quality"]],
  SLC: [["cfar_k", "Detection factor k", 6, 0.5, "cfar"]],
  SME2: [["dry", "Dry below", 0.15, 0.01, "drywet"], ["wet", "Wet above", 0.35, 0.01, "drywet"]],
};

export default function AnalysisPanel({ feature, auth, drawnBbox, onNeedLogin, onProject, projectedIds, inBasket, onBasket, inspecting, onInspect, onDone }) {
  const p = feature.properties;
  const info = byCode(p.processingLevel);
  const area = drawnBbox ? intersect(drawnBbox, bounds(feature)) : null;
  const [cat, setCat] = useState(undefined);
  const [want, setWant] = useState([]);
  const [params, setParams] = useState({});
  const [useArea, setUseArea] = useState(true);
  const [baseline, setBaseline] = useState(12);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState(null);
  const demo = !!p._demo;
  const isOffset = ["GOFF", "ROFF"].includes(p.processingLevel);
  useEffect(() => { loadCatalog().then(setCat); }, []);
  const extras = cat?.extras?.[p.processingLevel] || [];
  const fam = family(p.processingLevel);
  const shown = (PARAMS[fam] || []).filter(([, , , , used]) => used.split(" ").some((k) => want.includes(k)));
  const toggle = (k) => setWant((w) => (w.includes(k) ? w.filter((x) => x !== k) : [...w, k]));

  const run = async () => {
    if (!demo && !auth) return onNeedLogin();
    setBusy(true); setErr(""); setRes(null);
    try {
      const r = await analyse({ url: p.url, sid: auth?.sid, bbox: useArea && area ? area : null, level: p.processingLevel, baselineDays: baseline, want, params });
      setRes(r); onDone?.(r);
    } catch (e) {
      if (e.status === 401) onNeedLogin();
      setErr(e.status === 404 && e.detail === "Not Found" ? "Your backend is out of date (no /api/analyse). Restart it from the newest nisar-explorer\\backend folder." : e.message);
    } finally { setBusy(false); }
  };

  return (
    <details className="analysis" open>
      <summary>Analyse this file (no download)</summary>
      {info?.analysis && <ul className="hint-list">{info.analysis.map((t) => <li key={t}>{t}</li>)}</ul>}
      <p className="hint">Streams only a small window of the file through your backend. {demo ? "Demo granule: uses synthetic data." : "Needs your Earthdata sign-in."}</p>

      {extras.length > 0 && (
        <fieldset className="extras">
          <legend>Extra analyses</legend>
          {extras.map((x) => (
            <label key={x.key} className="check"><input type="checkbox" checked={want.includes(x.key)} onChange={() => toggle(x.key)} /> {x.title}</label>
          ))}
          <button type="button" className="link" onClick={() => setWant(want.length === extras.length ? [] : extras.map((x) => x.key))}>{want.length === extras.length ? "Clear all" : "Tick all"}</button>
        </fieldset>
      )}
      {cat === null && <p className="hint">Extra analyses need the newest backend (restart it after updating).</p>}
      {shown.length > 0 && (
        <div className="aparams">
          {shown.map(([k, label, def, step]) => (
            <label key={k} className="field"><span className="label">{label}</span>
              {typeof def === "string"
                ? <input type="text" value={params[k] ?? def} onChange={(e) => setParams({ ...params, [k]: e.target.value })} />
                : <input type="number" step={step} value={params[k] ?? def} onChange={(e) => setParams({ ...params, [k]: +e.target.value })} />}</label>
          ))}
        </div>
      )}

      <div className="aopts">
        <label className="check"><input type="radio" checked={useArea && !!area} disabled={!area} onChange={() => setUseArea(true)} /> Drawn area{!area && drawnBbox ? " (outside this granule)" : !drawnBbox ? " (draw a box first)" : ""}</label>
        <label className="check"><input type="radio" checked={!useArea || !area} onChange={() => setUseArea(false)} /> Centre of the granule</label>
        {(isOffset || want.includes("speed")) && (
          <label className="field"><span className="label">Days between the two acquisitions</span>
            <input type="number" min="1" max="3650" value={baseline} onChange={(e) => setBaseline(+e.target.value || 12)} /></label>
        )}
      </div>
      <div className="figbtns">
        <button className="btn solid" onClick={run} disabled={busy}>{busy ? "Reading the file…" : !demo && !auth ? "Sign in to analyse" : "Run analysis"}</button>
        <button className="btn" onClick={() => onBasket(feature)}>{inBasket ? "Remove from workbench" : "Add to workbench"}</button>
        <button className={inspecting ? "btn on" : "btn"} onClick={() => onInspect(feature)}>{inspecting ? "Click the map…" : "Inspect a point"}</button>
      </div>
      {busy && <p className="hint">This can take from a few seconds to a minute, depending on your connection.</p>}
      {err && <p className="err" role="alert">{err}</p>}
      {res && <ResultView res={res} idPrefix={p._id} projectedIds={projectedIds} onProject={(im, id) => onProject(im, id, `${p.processingLevel} · ${im.name}`)} title={`${p.processingLevel} ${p.startTime?.slice(0, 16).replace("T", " ")}`} context={{ granules: [p], bbox: useArea && area ? area : null }} />}
    </details>
  );
}
