import { useEffect, useState } from "react";
import { login } from "./api.js";

export default function LoginDialog({ onClose, onSignedIn }) {
  const [mode, setMode] = useState("password");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const esc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const r = await login(mode === "token" ? { token } : { username, password });
      onSignedIn(r);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const ready = mode === "token" ? token.trim() : username && password;

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="dialog" role="dialog" aria-modal="true" aria-labelledby="login-title" onSubmit={submit}>
        <h2 id="login-title">Sign in to NASA Earthdata</h2>
        <p className="hint">NISAR files can only be downloaded with a free Earthdata account.
          {" "}<a href="https://urs.earthdata.nasa.gov/users/new" target="_blank" rel="noreferrer">Create one</a>.</p>

        <div className="chips" role="tablist">
          <button type="button" role="tab" aria-selected={mode === "password"} className={mode === "password" ? "chip on" : "chip"} onClick={() => setMode("password")}>Username and password</button>
          <button type="button" role="tab" aria-selected={mode === "token"} className={mode === "token" ? "chip on" : "chip"} onClick={() => setMode("token")}>Token</button>
        </div>

        {mode === "password" ? (
          <>
            <label className="field"><span className="label">Earthdata username</span>
              <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" autoFocus /></label>
            <label className="field"><span className="label">Password</span>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
          </>
        ) : (
          <label className="field"><span className="label">Earthdata token</span>
            <input type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="Paste a token from your Earthdata profile" autoFocus />
            <span className="hint">Generate one at urs.earthdata.nasa.gov, under Generate Token. Safer than a password.</span></label>
        )}

        <p className="hint">Credentials go only to your own backend and stay in its memory until you sign out or it restarts.</p>
        {error && <p className="err" role="alert">{error}</p>}
        <div className="actions">
          <button type="submit" className="btn solid" disabled={busy || !ready}>{busy ? "Signing in…" : "Sign in"}</button>
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </div>
  );
}
