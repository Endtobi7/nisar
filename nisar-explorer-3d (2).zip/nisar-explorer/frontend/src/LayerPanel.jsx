import { useState, useSyncExternalStore } from "react";
import { tracker } from "./orbit.js";
import { findLatestDate, dayCoverage, CONTEXT_LAYERS } from "./gibs.js";

const addDays = (iso, n) => new Date(new Date(iso + "T00:00:00Z").getTime() + n * 864e5).toISOString().slice(0, 10);

function OrbitReadout() {
  const s = useSyncExternalStore(tracker.subscribe, tracker.getSnapshot);
  if (s.status === "loading") return <p className="hint">Loading orbital elements…</p>;
  if (s.status === "error") return <p className="err" role="alert">{s.message}</p>;
  if (s.status !== "ok") return null;
  const { lat, lon, alt, speed } = s.pos;
  return (
    <p className="orbit-read">
      {Math.abs(lat).toFixed(2)}°{lat >= 0 ? "N" : "S"} {Math.abs(lon).toFixed(2)}°{lon >= 0 ? "E" : "W"} · {alt.toFixed(0)} km · {speed.toFixed(2)} km/s
    </p>
  );
}

export default function LayerPanel({ layers, setLayers, follow, setFollow, issue, overlays, onRemoveOverlay, onOverlayMode, onClearOverlays, overlayOpacity, setOverlayOpacity, context, setContext, compare, setCompare }) {
  const [finding, setFinding] = useState(false);
  const [note, setNote] = useState("");
  const [open, setOpen] = useState(() => !window.matchMedia("(max-width: 800px)").matches);
  const set = (patch) => setLayers({ ...layers, ...patch });
  const findLatest = async () => {
    setFinding(true);
    setNote("");
    try {
      const d = await findLatestDate(30, layers.mode === "composite");
      if (d) { setLayers({ ...layers, date: d }); setNote(`Latest day with NISAR imagery: ${d}`); }
      else setNote("No NISAR imagery found in the last 30 days.");
    } catch (e) {
      setNote(`Could not reach NASA GIBS (${e.message}). Check your internet connection.`);
    } finally { setFinding(false); }
  };
  const checkCoverage = async () => {
    setFinding(true);
    setNote("");
    const dates = Array.from({ length: layers.days }, (_, i) => addDays(layers.date, -i));
    const res = await dayCoverage(dates);
    const ok = res.filter(([, v]) => v).length;
    const gaps = res.filter(([, v]) => v === false).map(([d]) => d.slice(5));
    const errs = res.filter(([, v]) => v === null).length;
    setNote(`Days with imagery: ${ok} of ${dates.length}.${gaps.length ? ` Empty: ${gaps.join(", ")}.` : ""}${errs ? ` ${errs} could not be checked.` : ""}`);
    setFinding(false);
  };
  const composite = layers.mode === "composite";
  const from = addDays(layers.date, -(layers.days - 1));

  return (
    <section className="layers" aria-label="Map layers">
      <header>
        <h2>Layers</h2>
        
      </header>
      {true && (
        <>
          <label className="check strong">
            <input type="checkbox" checked={layers.bs} onChange={(e) => set({ bs: e.target.checked })} />
            NISAR radar backscatter (false color, provisional)
          </label>
          {layers.bs && (
            <>
              <label className="field">
                <span className="label">View</span>
                <select value={layers.mode} onChange={(e) => set({ mode: e.target.value })}>
                  <option value="stack">Daily mosaics (use the slider)</option>
                  <option value="composite">NASA rolling 12-day composite</option>
                </select>
              </label>
              <label className="field">
                <span className="label">Latest day of the window (UTC)</span>
                <input type="date" value={layers.date} onChange={(e) => e.target.value && set({ date: e.target.value })} />
              </label>
              <button type="button" className="btn" onClick={findLatest} disabled={finding}>{finding ? "Checking NASA GIBS…" : "Find latest data"}</button>
              {note && <p className="hint" role="status">{note}</p>}
              {issue && <p className="err" role="alert">Some NASA tiles failed to load. Check your connection, then try Find latest data.</p>}
              {!composite && <div className="field">
                <span className="label">Days shown: <b>{layers.days}</b> ({from} → {layers.date})</span>
                <input type="range" min="1" max="12" step="1" value={layers.days} onChange={(e) => set({ days: +e.target.value })} aria-label="Number of days of NISAR coverage to show" />
                <div className="ticks" aria-hidden="true">{Array.from({ length: 12 }, (_, i) => <span key={i}>{i + 1}</span>)}</div>
              </div>}
              {!composite && <button type="button" className="btn ghost" onClick={checkCoverage} disabled={finding}>Check which days have data</button>}
              <label className="field">
                <span className="label">Opacity</span>
                <input type="range" min="0.2" max="1" step="0.05" value={layers.opacity} onChange={(e) => set({ opacity: +e.target.value })} />
              </label>
              <p className="hint">NISAR repeats every 12 days, but it maps mostly land and ice, so open ocean stays empty, and provisional processing may still have gaps. Blank map? Try an earlier date: NASA GIBS publishes with a delay.</p>
            </>
          )}
          <div className="field">
            <span className="label">Optical and rainfall context (NASA GIBS, visual only)</span>
            <select value={context.layer} onChange={(e) => setContext({ ...context, layer: e.target.value })}>
              <option value="">None</option>
              {CONTEXT_LAYERS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
            {context.layer && (
              <>
                <input type="date" value={context.date} onChange={(e) => e.target.value && setContext({ ...context, date: e.target.value })} aria-label="Date of the context layer" />
                <input type="range" min="0.2" max="1" step="0.05" value={context.opacity} onChange={(e) => setContext({ ...context, opacity: +e.target.value })} aria-label="Context layer opacity" />
                <p className="hint">Use it to check a water, burn or flood result by eye. Clouds hide the ground in optical images.</p>
              </>
            )}
          </div>
          {overlays.length > 0 && (
            <div className="field">
              <div className="coverage-head">
                <span>Projected images ({overlays.length})</span>
                <button className="link" onClick={onClearOverlays}>Remove all</button>
              </div>
              <ul className="ovlist">
                {overlays.map((o) => (
                  <li key={o.id}>
                    <span title={o.id}>{o.label}</span>
                    {o.blob && <select value={o.mode} onChange={(e) => onOverlayMode(o.id, e.target.value)} aria-label={`How ${o.label} is fitted to the footprint`}>
                      {o.exact && <option value="kml">Exact</option>}
                      <option value="auto">Fit: auto</option>
                      <option value="bounds">Fit: bounds</option>
                      <option value="corners">Fit: corners</option>
                    </select>}
                    <button className="x" onClick={() => onRemoveOverlay(o.id)} aria-label={`Remove ${o.label} from the map`}>×</button>
                  </li>
                ))}
              </ul>
              {overlays.length >= 2 && (
                <div className="field">
                  <label className="check"><input type="checkbox" checked={compare.on} onChange={(e) => setCompare({ ...compare, on: e.target.checked, a: compare.a || overlays[0].id, b: compare.b || overlays[1].id })} /> Compare two images (crossfade)</label>
                  {compare.on && (
                    <>
                      <select value={compare.a} onChange={(e) => setCompare({ ...compare, a: e.target.value })} aria-label="First image">{overlays.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select>
                      <select value={compare.b} onChange={(e) => setCompare({ ...compare, b: e.target.value })} aria-label="Second image">{overlays.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select>
                      <input type="range" min="0" max="1" step="0.02" value={compare.t} onChange={(e) => setCompare({ ...compare, t: +e.target.value })} aria-label="Crossfade between the two images" />
                    </>
                  )}
                </div>
              )}
              <label className="field">
                <span className="label">Image opacity</span>
                <input type="range" min="0.2" max="1" step="0.05" value={overlayOpacity} onChange={(e) => setOverlayOpacity(+e.target.value)} />
              </label>
            </div>
          )}
          <label className="check strong">
            <input type="checkbox" checked={layers.orbit} onChange={(e) => set({ orbit: e.target.checked })} />
            NISAR orbit tracker (live)
          </label>
          {layers.orbit && (
            <>
              <OrbitReadout />
              <label className="check"><input type="checkbox" checked={follow} onChange={(e) => setFollow(e.target.checked)} /> Follow satellite</label>
              <p className="hint">Solid line: next ~110 min. Dashed: last 50 min.</p>
            </>
          )}
        </>
      )}
    </section>
  );
}
