"""Accuracy tests: every check compares an analysis result with a number we know is true.

The existing tests (test_analyse.py) only prove that analyses RUN. These prove they are RIGHT.
Run with:  python -m pytest test_accuracy.py -v      (or: python test_accuracy.py)
"""
import math
import re
import warnings

import numpy as np

import analyse
import demo_data
import extras
import pairs
import series
from analyse import Ctx
from demo_data import N, make_demo

warnings.filterwarnings("ignore")


def num(text):
    """first number in a metric string"""
    return float(re.search(r"-?\d+(?:\.\d+)?", str(text)).group())


def metric(out, label_start):
    for m in out["metrics"]:
        if m["label"].startswith(label_start):
            return m["value"]
    raise KeyError(f"no metric starting with {label_start!r}; have {[m['label'] for m in out['metrics']]}")


def with_scene(**kw):
    """run make_demo with a custom water radius / no water (monkeypatches the field generator)"""
    orig = demo_data._fields

    def fields(t=None):
        rng, xx, yy, smooth, water, urban = orig(t)
        r = kw.get("water_radius", 70)
        water = ((xx - 150) ** 2 + (yy - 330) ** 2) < r ** 2 if r > 0 else np.zeros_like(water)
        return rng, xx, yy, smooth, water, urban

    demo_data._fields = fields
    return orig


def water_truth(r):
    yy, xx = np.mgrid[0:N, 0:N]
    return 100 * float((((xx - 150) ** 2 + (yy - 330) ** 2) < r ** 2).mean()) if r > 0 else 0.0


# ---------------------------------------------------------------- water map
def _water_share(r):
    orig = with_scene(water_radius=r)
    try:
        f = make_demo("GCOV")
        out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    finally:
        demo_data._fields = orig
    try:
        share = num(metric(out, "Water share"))
    except KeyError:
        share = 0.0  # analysis correctly refused to report water
    return share, out


def test_water_no_water_scene_reports_about_zero():
    share, out = _water_share(0)
    assert share < 1.0, f"no water in the scene but the app reports {share} % water"


def test_water_tiny_pond_not_inflated():
    share, _ = _water_share(10)
    assert abs(share - water_truth(10)) < 1.0, f"pond is {water_truth(10):.2f} %, app says {share} %"


def test_water_small_lake():
    share, _ = _water_share(70)
    assert abs(share - water_truth(70)) < 1.0


def test_water_big_lake():
    share, _ = _water_share(200)
    assert abs(share - water_truth(200)) < 2.0


def test_water_huge_lake_scene_mostly_water():
    share, _ = _water_share(300)
    assert abs(share - water_truth(300)) < 3.0


# ---------------------------------------------------------------- flood / change / deforestation
def _pair(mode, ta, tb, level="GCOV"):
    return pairs.run(make_demo(level, t=ta), make_demo(level, t=tb), Ctx(), mode)


def test_flood_new_water_matches_flooded_box():
    out = _pair("flood", 3, 5)
    truth_new = 100 * (379 - 250) * (469 - 380) / N ** 2   # box xx 251..379, yy 381..469
    got_new = num(metric(out, "New open water"))
    assert abs(got_new - truth_new) < 1.0, f"flooded box is {truth_new:.2f} %, app says {got_new} %"


def test_flood_permanent_water_matches_lake():
    out = _pair("flood", 3, 5)
    got = num(metric(out, "Permanent water"))
    assert abs(got - water_truth(70)) < 1.0


def test_flood_no_change_reports_no_new_water():
    out = _pair("flood", 3, 3)
    assert num(metric(out, "New open water")) < 0.5


def test_flood_scene_without_any_water_reports_none():
    orig = with_scene(water_radius=0)
    try:
        out = _pair("flood", 3, 3)
    finally:
        demo_data._fields = orig
    assert num(metric(out, "Permanent water")) < 1.0, "no water anywhere but flood analysis reports permanent water"


def test_deforestation_area():
    out = _pair("deforest", 3, 4)
    truth = 100 * (139 - 40) * (139 - 40) / N ** 2
    got = num(metric(out, "Vegetation loss"))
    assert abs(got - truth) < 1.0, f"cleared area is {truth:.2f} %, app says {got} %"


def test_deforestation_no_change():
    out = _pair("deforest", 3, 3)
    assert num(metric(out, "Vegetation loss")) < 0.5


def test_change_map_no_change_is_quiet():
    out = _pair("gcov_change", 3, 3)
    assert num(metric(out, "Brighter pixels")) < 0.5 and num(metric(out, "Darker pixels")) < 0.5


def test_coherence_loss_area():
    out = _pair("coherence_change", 3, 4, "GUNW")
    truth = 100 * (499 - 380) * 100 / N ** 2   # xx 381..499, yy 0..99
    got = num(metric(out, "Pixels that lost"))
    assert abs(got - truth) < 1.0, f"truth {truth:.2f} %, app says {got} %"


# ---------------------------------------------------------------- interferometry
def test_unw_phase_to_displacement_scale():
    f = make_demo("GUNW")
    out = analyse.run(f, Ctx(), "GUNW")
    # truth: bowl of 3 cm peak + a 0.002 rad/px ramp (=1.9 cm over the window); max |change| must be < peak+ramp
    peak = 3.0 + 0.002 * N * analyse.LAMBDA / (4 * math.pi) * 100
    assert num(metric(out, "Largest change")) <= peak + 0.2


def test_uncertainty_formula_cramer_rao():
    # coherence 0.9, 20 looks -> sigma_phi = sqrt((1-g^2)/(2 L g^2)) rad
    g, L = 0.9, 20.0
    expect = math.sqrt((1 - g ** 2) / (2 * L * g ** 2)) * analyse.LAMBDA / (4 * math.pi) * 100
    d = {"coh": np.full((40, 40), g), "gm": None, "cr": None, "geo": False}
    out = {"metrics": [], "images": [], "notes": []}
    extras.unw_uncertainty(out, Ctx(), d)
    assert abs(num(out["metrics"][0]["value"]) - expect) < 0.01


def test_gunw_decorrelated_share_matches_water_lake():
    out = analyse.run(make_demo("GUNW"), Ctx(), "GUNW")
    assert abs(num(metric(out, "Reliable pixels")) - (100 - water_truth(70))) < 1.0


# ---------------------------------------------------------------- offsets
def test_goff_speed_conversion():
    out = analyse.run(make_demo("GOFF"), Ctx(baseline_days=12), "GOFF")
    p95_m = num(metric(out, "Relative motion").split("/")[1])
    speed = num(metric(out, "Implied speed"))
    assert abs(speed - p95_m / 12 * 365.25) < 1.0


# ---------------------------------------------------------------- time series
def _geo(n=60):
    cr = [[-7.6, 33.7], [-7.5, 33.7], [-7.5, 33.6], [-7.6, 33.6]]
    gm = {"dx": 20.0, "dy": 20.0, "epsg": 32629, "left": 625000.0, "top": 3725000.0}
    return ((0, n, 0, n, 1), cr, gm, 20.0)


def test_velocity_recovers_known_rate():
    n, per_pair = 60, 1.0   # right half moves 1 cm per 12-day pair, left half is stable
    stack = []
    for _ in range(6):
        d = np.zeros((n, n))
        d[:, n // 2:] = per_pair
        stack.append({"arr": {"disp": d + 0.0, "coh": np.full((n, n), 0.9)}})
    dates = [f"2026-0{1 + i // 3}-{1 + 10 * (i % 3):02d}" for i in range(6)]
    out = {"metrics": [], "images": [], "notes": []}
    series.velocity(stack, list(range(0, 72, 12)), dates, Ctx(baseline_days=12), out, _geo(n))
    # velocity map is the image raw data; compare right-half vs left-half difference
    v = out["_raw"]["Line-of-sight velocity (mm/yr)"]["a"]
    diff = float(np.nanmedian(v[:, n // 2 + 2:]) - np.nanmedian(v[:, :n // 2 - 2]))
    truth = per_pair * 10 / 12 * 365.25   # mm/yr
    assert abs(diff - truth) / truth < 0.02, f"truth {truth:.0f} mm/yr, app says {diff:.0f}"


def test_sme_anomaly_can_reach_large_z():
    n = 30
    rng = np.random.default_rng(0)
    base = 0.2 + 0.01 * rng.standard_normal((n, n))
    cube = [base + 0.0, base + 0.0, base + 0.2]          # latest date is 20 sigma wetter
    stack = [{"arr": {"sm": c}} for c in cube]
    out = {"metrics": [], "images": [], "notes": []}
    series.sme_anomaly(stack, [0, 12, 24], ["a", "b", "c"], Ctx(), out, _geo(n))
    wet = num(metric(out, "Wetter than usual"))
    assert wet > 90, f"latest date is far wetter everywhere but only {wet} % flagged"
    z = out["_raw"]["Soil-moisture anomaly of the latest date (z-score)"]["a"]
    assert float(np.nanmedian(z)) > 5, f"a ~20 sigma wet event shows as z = {float(np.nanmedian(z)):.1f}"


def test_vertical_ew_recovers_pure_vertical():
    n = 40
    inc = math.radians(39.0)
    sa = type("S", (), {"ident": {"lookDirection": "Right"}})()
    sb = type("S", (), {"ident": {"lookDirection": "Right"}})()
    lat = 33.6
    psi = math.degrees(math.asin(math.cos(math.radians(98.4)) / math.cos(math.radians(lat))))
    heads = {"asc": psi, "desc": 180 - psi}

    def los(side, E, U):
        az = math.radians(heads[side] - 90)
        return math.sin(inc) * math.sin(az) * E + math.cos(inc) * U

    cr = [[-7.6, 33.65], [-7.5, 33.65], [-7.5, 33.55], [-7.6, 33.55]]
    gm = {"dx": 20.0, "dy": 20.0}
    calls = []

    def fake_unw(s, ctx, win=None, bbox=None):
        side = "asc" if not calls else "desc"
        calls.append(side)
        d = np.full((n, n), los(side, 0.0, 1.0) * 100)   # 1 m vertical -> cm in LOS
        d[0, 0] = d[0, 0]
        return d, np.full((n, n), 0.9), (0, n, 0, n, 1), cr, gm, 20.0, True

    orig = pairs._unw
    pairs._unw = fake_unw
    try:
        out = {"metrics": [], "images": [], "notes": []}
        pairs.vertical_ew(sa, sb, Ctx(), out)
    finally:
        pairs._unw = orig
    up = out["_raw"]["Vertical change (cm)"]["a"]
    east = out["_raw"]["East-west change (cm)"]["a"]
    assert abs(float(np.nanmedian(up)) - 100.0) < 1.0 and abs(float(np.nanmedian(east))) < 1.0


# ---------------------------------------------------------------- cosmetic / consistency
def test_cfar_targets_numbered_by_rank():
    f = make_demo("GSLC")
    out = analyse.run(f, Ctx(want=("cfar",)), "GSLC")
    labels = [m["label"] for m in out["metrics"] if m["label"].startswith("Target")]
    assert labels == [f"Target {i + 1}" for i in range(len(labels))], labels


def test_cfar_target_position_is_exact():
    """a planted corner reflector must be reported at its true map position (not shifted by a pixel)"""
    f = make_demo("GSLC")
    ds = f["science/LSAR/GSLC/grids/frequencyA/HH"]
    a = ds[()]
    R, C = 200, 300
    a[R - 1:R + 2, C - 1:C + 2] = 3.0
    ds[...] = a
    out = analyse.run(f, Ctx(want=("cfar",)), "GSLC")
    got = metric(out, "Target 1")
    lat, lon = (float(x) for x in re.findall(r"-?\d+\.\d+", got.split(" at ")[1]))
    gm = dict(epsg=demo_data.EPSG, left=625000.0, top=3725000.0, dx=20.0, dy=20.0)
    tlon, tlat = extras._ll(gm, [R], [C])
    off_m = math.hypot((lat - float(tlat[0])) * 111320, (lon - float(tlon[0])) * 111320 * math.cos(math.radians(lat)))
    assert off_m < 8, f"target reported {off_m:.0f} m from its true position (pixel is 20 m)"


# ---------------------------------------------------------------- remaining analyses (known synthetic truth)
def _stack_gcov(values, n=40):
    """values: list (per date) of dict pol -> constant linear power"""
    return [{"arr": {p: np.full((n, n), v) for p, v in d.items()}} for d in values]


def test_gcov_ts_constant_values():
    st = _stack_gcov([{"HH": 0.05, "HV": 0.01}] * 4)
    out = {"metrics": [], "images": [], "notes": []}
    series.gcov_ts(st, [0, 12, 24, 36], ["a", "b", "c", "d"], Ctx(), out, _geo(40))
    assert abs(num(metric(out, "HH mean backscatter")) - 10 * math.log10(0.05)) < 0.1
    assert abs(num(metric(out, "HV mean backscatter")) - (-20.0)) < 0.1
    assert abs(num(metric(out, "HH trend"))) < 0.01


def test_gcov_ts_trend_sign_and_size():
    # HH drops exactly 1 dB every 12 days -> -30.44 dB per year
    st = _stack_gcov([{"HH": 10 ** (-1.3 - 0.1 * i), "HV": 0.01} for i in range(5)])
    out = {"metrics": [], "images": [], "notes": []}
    series.gcov_ts(st, [0, 12, 24, 36, 48], list("abcde"), Ctx(), out, _geo(40))
    trend = float(re.search(r"(-?\d+(?:\.\d+)?) dB per year", metric(out, "HH trend")).group(1))
    assert abs(trend - (-1.0 / 12 * 365.25)) < 0.3, trend


def test_first_change_finds_date_and_area():
    t = [make_demo("GCOV", t=i) for i in range(6)]
    stack = [{"arr": {p: _read_pol(f, p) for p in ("HH", "HV")}} for f in t]
    out = {"metrics": [], "images": [], "notes": []}
    days = [12.0 * i for i in range(6)]
    series.first_change(stack, days, [f"2026-{1 + i:02d}-01" for i in range(6)], Ctx(), out, _geo(N))
    truth = 100 * (139 - 40) * (139 - 40) / N ** 2         # cleared box, HV -3.5 dB from date index 4
    got = num(metric(out, "Pixels that changed"))
    assert abs(got - truth) < 1.5, f"truth {truth:.2f} %, app says {got} %"
    day_map = out["_raw"]["Day of first change (days since the first date)"]["a"]
    assert abs(float(np.nanmedian(day_map)) - 48.0) < 0.1, "first change must be reported on date index 4 (day 48)"


def _read_pol(f, p):
    a = f[f"science/LSAR/GCOV/grids/frequencyA/{p}{p}"][()].astype(float)
    return np.where(a > 0, a, np.nan)


def test_temporal_average_constant_scene_has_zero_variability():
    st = _stack_gcov([{"HH": 0.05, "HV": 0.01}] * 5)
    out = {"metrics": [], "images": [], "notes": []}
    series.temporal_avg(st, list(range(5)), list("abcde"), Ctx(), out, _geo(40))
    assert abs(num(metric(out, "HH temporal average")) - 10 * math.log10(0.05)) < 0.1
    assert num(metric(out, "Variability")) < 0.01


def test_ascdesc_difference_is_exact():
    n = 60
    b = np.full((n, n), 0.02)
    a = 2.0 * b            # exactly +3.01 dB
    sa = sb = None

    class S:  # minimal stand-ins: gcov_pair is replaced below
        pass

    cr = [[-7.6, 33.65], [-7.5, 33.65], [-7.5, 33.55], [-7.6, 33.55]]
    orig = pairs.gcov_pair
    pairs.gcov_pair = lambda *_a, **_k: ("HH", a, b, (0, n, 0, n, 1), cr, {"dx": 20.0, "dy": 20.0}, 20.0)
    try:
        out = {"metrics": [], "images": [], "notes": []}
        pairs.gcov_ascdesc(S(), S(), Ctx(), out)
    finally:
        pairs.gcov_pair = orig
    assert abs(num(metric(out, "Difference ascending")) - 10 * math.log10(2)) < 0.02
    assert num(metric(out, "Pixels differing by more than 3 dB")) > 99      # 3.01 dB > 3 dB everywhere


def test_gslc_interferogram_phase_and_coherence():
    n = 60
    rng = np.random.default_rng(3)
    z1 = (rng.standard_normal((n, n)) + 1j * rng.standard_normal((n, n))) * 0.2
    z2 = z1 * np.exp(-1j * 0.5)            # same scene, 0.5 rad phase change
    cr = [[-7.6, 33.65], [-7.5, 33.65], [-7.5, 33.55], [-7.6, 33.55]]
    gm = {"dx": 20.0, "dy": 20.0}

    class S:
        def __init__(self, z): self.z = z
    sa, sb = S(z1), S(z2)
    ob, ow = pairs.base_window, pairs.other_window
    sa.read = lambda path, win: z1
    sb.read = lambda path, win: z2
    pairs.base_window = lambda s, name, ctx: ("p", (0, n, 0, n, 1), cr, gm, 20.0)
    pairs.other_window = lambda s, name, ctx, c: ("p", (0, n, 0, n, 1))
    orig_has = pairs._has
    pairs._has = lambda s, name: True
    try:
        out = {"metrics": [], "images": [], "notes": []}
        pairs.gslc_ifg(sa, sb, Ctx(), out)
    finally:
        pairs.base_window, pairs.other_window, pairs._has = ob, ow, orig_has
    assert num(metric(out, "Coherence (5x5")) > 0.99
    coh = out["_raw"]["Coherence"]["a"]
    assert float(np.nanmin(coh)) > 0.99


def test_gcov_gunw_removes_the_lake():
    out = pairs.run(make_demo("GCOV"), make_demo("GUNW"), Ctx(), "gcov_gunw")
    removed = num(metric(out, "Water-like pixels removed"))
    assert abs(removed - water_truth(70)) < 1.5, f"lake is {water_truth(70):.2f} %, app removes {removed} %"


def test_landcover_darkest_class_is_the_lake():
    f = make_demo("GCOV")
    out = analyse.run(f, Ctx(want=("landcover",)), "GCOV")
    first = next(m for m in out["metrics"] if m["label"].startswith("Class 1"))
    assert abs(num(first["value"]) - water_truth(70)) < 1.0


def test_decomposition_flags_the_urban_block_as_double_bounce():
    f = make_demo("GCOV")
    out = analyse.run(f, Ctx(want=("decomp",)), "GCOV")
    dom = metric(out, "Dominant mechanism")
    dbl = float(re.search(r"double-bounce (\d+\.\d+)", dom).group(1))
    urban = 100 * 89 * 79 / N ** 2                      # xx 331..419, yy 81..159
    assert 0.6 * urban < dbl < 1.2 * urban, f"urban block is {urban:.2f} % of the scene, double-bounce dominant on {dbl} %"


def test_velocity_uses_real_dates():
    n = 40
    stack = []
    for _ in range(5):
        d = np.zeros((n, n)); d[:, n // 2:] = 1.0            # 1 cm per pair
        stack.append({"arr": {"disp": d, "coh": np.full((n, n), 0.9)}})
    out = {"metrics": [], "images": [], "notes": []}
    # pairs are 12 days long but the files are 24 days apart -> time axis must follow the dates, with a warning
    series.velocity(stack, [0, 24, 48, 72, 96], list("abcde"), Ctx(baseline_days=12), out, _geo(n))
    v = out["_raw"]["Line-of-sight velocity (mm/yr)"]["a"]
    diff = float(np.nanmedian(v[:, n // 2 + 2:]) - np.nanmedian(v[:, :n // 2 - 2]))
    assert abs(diff - 10 / 24 * 365.25) / (10 / 24 * 365.25) < 0.03, diff
    assert any("not 12 days apart" in x for x in out["notes"])


def test_change_threshold_adapts_to_real_noise_and_finds_change():
    out = _pair("gcov_change", 3, 5)         # flooded box turns dark in HH
    truth = 100 * (379 - 250) * (469 - 380) / N ** 2
    got = num(metric(out, "Darker pixels"))
    assert abs(got - truth) < 1.5, f"flood box is {truth:.2f} % but darker pixels = {got} %"
    assert num(metric(out, "Brighter pixels")) < 0.5


def test_very_bright_share_urban_block():
    out = analyse.run(make_demo("GCOV"), Ctx(want=("bright",)), "GCOV")
    got = num(metric(out, "Very bright share"))
    assert abs(got - 100 * 89 * 79 / N ** 2) < 0.8, got


def test_sigma0_equals_gamma0_times_factor():
    out = analyse.run(make_demo("GCOV"), Ctx(want=("sigma0",)), "GCOV")
    f = make_demo("GCOV")
    fac = float(np.nanmedian(f["science/LSAR/GCOV/grids/frequencyA/rtcGammaToSigmaFactor"][()]))
    assert abs(num(metric(out, "Gamma-0 to sigma-0 factor")) - fac) < 0.01


def test_quality_reads_mask_and_looks():
    out = analyse.run(make_demo("GCOV"), Ctx(want=("quality",)), "GCOV")
    assert "25" in metric(out, "Number of looks")
    assert num(metric(out, "Mask: valid")) > 99.0


def test_enl_of_pure_speckle_is_one():
    n = 160
    rng = np.random.default_rng(5)
    z = (rng.standard_normal((n, n)) + 1j * rng.standard_normal((n, n))) / math.sqrt(2)
    I = np.abs(z) ** 2
    out = {"metrics": [], "images": [], "notes": []}
    extras.slc_enl(out, Ctx(), {"inten": I, "win": (0, n, 0, n, 1)})
    assert abs(num(out["metrics"][0]["value"]) - 1.0) < 0.15


def test_texture_cv_of_uniform_speckle():
    out = analyse.run(make_demo("GCOV"), Ctx(want=("texture",)), "GCOV")
    cv = num(metric(out, "HH texture"))
    assert 0.3 < cv < 0.7, cv                     # gamma speckle with 4 looks: 1/sqrt(4) = 0.5


def test_gslc_phase_concentration_random_vs_constant():
    n = 80
    rng = np.random.default_rng(1)
    z = rng.standard_normal((n, n)) + 1j * rng.standard_normal((n, n))
    out = {"metrics": [], "images": [], "notes": []}
    extras.slc_phase(out, Ctx(), {"z": z, "cr": None, "geo": False, "gm": None})
    assert num(out["metrics"][0]["value"]) < 0.05
    out = {"metrics": [], "images": [], "notes": []}
    extras.slc_phase(out, Ctx(), {"z": np.full((n, n), 2 + 2j), "cr": None, "geo": False, "gm": None})
    assert num(out["metrics"][0]["value"]) > 0.99


def test_gslc_amplitude_change_finds_planted_change():
    fa, fb = make_demo("GSLC"), make_demo("GSLC")
    ds = fb["science/LSAR/GSLC/grids/frequencyA/HH"]
    a = ds[()]
    a[100:180, 100:180] *= 0.2                     # patch 14 dB darker
    ds[...] = a
    out = pairs.run(fa, fb, Ctx(), "gslc_change")
    truth = 100 * 80 * 80 / N ** 2
    assert abs(num(metric(out, "Darker pixels")) - truth) < 1.2, metric(out, "Darker pixels")
    quiet = pairs.run(fa, make_demo("GSLC"), Ctx(), "gslc_change")
    assert num(metric(quiet, "Darker pixels")) < 0.5 and num(metric(quiet, "Brighter pixels")) < 0.5


# ================================================================ second audit: accuracy of masking, noise floors, untested analyses
def _o():
    return {"metrics": [], "images": [], "notes": []}


def _walk(f):
    paths = []
    f.visititems(lambda n, o: paths.append(n) if hasattr(o, "shape") else None)
    return paths


def _gm():
    return {"dx": 20.0, "dy": 20.0, "epsg": 32629, "left": 625000.0, "top": 3725000.0}


def test_gunw_garbage_phase_in_decorrelated_area_is_ignored():
    """phase over decorrelated pixels is meaningless: it must not set 'Largest change' or the reference"""
    base = analyse.run(make_demo("GUNW"), Ctx(), "GUNW")
    f = make_demo("GUNW")
    ph_p = next(p for p in _walk(f) if p.endswith("unwrappedPhase"))
    co_p = next(p for p in _walk(f) if p.endswith("coherenceMagnitude"))
    ph, co = f[ph_p][()], f[co_p][()]
    ph[co < 0.5] += 50.0                                   # 50 rad of garbage on the (decorrelated) lake
    f[ph_p][...] = ph
    out = analyse.run(f, Ctx(), "GUNW")
    assert abs(num(metric(out, "Largest change")) - num(metric(base, "Largest change"))) < 0.3, (metric(out, "Largest change"), metric(base, "Largest change"))
    assert abs(num(metric(out, "Spread")) - num(metric(base, "Spread"))) < 0.3


def test_unw_extremes_ignore_decorrelated_pixels():
    z = np.zeros((60, 60)); z[5:12, 5:12] = 500.0          # huge spike
    coh = np.full((60, 60), 0.9); coh[5:12, 5:12] = 0.1    # ... where the signal is decorrelated
    z[40:47, 40:47] = 2.0                                  # real, coherent change
    out = _o()
    extras.unw_extremes(out, Ctx(), {"disp": z, "coh": coh, "gm": None, "geo": False, "cr": None})
    assert num(metric(out, "Largest positive change")) < 3.0


def _goff_with(noise_only):
    f = make_demo("GOFF")
    if noise_only:
        rng = np.random.default_rng(4)
        for p in _walk(f):
            if p.endswith("alongTrackOffset") or p.endswith("slantRangeOffset"):
                f[p][...] = (1.5 + 0.3 * rng.standard_normal(f[p].shape)).astype(f[p].dtype)
    return analyse.run(f, Ctx(baseline_days=12), "GOFF")


def test_goff_pure_noise_is_not_reported_as_speed():
    out = _goff_with(True)
    assert "not significant" in metric(out, "Implied speed"), metric(out, "Implied speed")


def test_goff_real_flow_is_reported_as_speed():
    out = _goff_with(False)
    assert "not significant" not in metric(out, "Implied speed")
    assert 55 < num(metric(out, "Implied speed")) < 80      # demo flow 2.19 m / 12 d = 67 m/yr


def test_landcover_scene_without_water_has_no_water_class():
    orig = with_scene(water_radius=0)
    try:
        out = analyse.run(make_demo("GCOV"), Ctx(want=("landcover",)), "GCOV")
    finally:
        demo_data._fields = orig
    labels = [m["label"] for m in out["metrics"]]
    assert not any("water-like" in l for l in labels), labels


def test_strain_of_a_known_ramp():
    ramp = np.tile(np.arange(64) * 0.1, (64, 1))           # 0.1 cm per 20 m pixel = 50 microstrain
    out = _o()
    extras.unw_strain(out, Ctx(), {"disp": ramp, "gm": _gm(), "cr": None, "geo": False})
    assert abs(num(metric(out, "Line-of-sight strain")) - 50.0) < 1.5


def test_profile_of_a_known_ramp():
    ramp = np.tile(np.arange(64) * 0.1, (64, 1))
    out = _o()
    extras.unw_profile(out, Ctx(), {"disp": ramp, "gm": None, "cr": None, "geo": False})
    nums = [float(x) for x in re.findall(r"-?\d+\.\d+", metric(out, "Profile"))]
    assert abs(nums[0] - 0.0) < 0.2 and abs(nums[1] - 6.3) < 0.2, nums


def test_fringe_density_of_a_known_ramp():
    col = np.tile(np.arange(80), (80, 1))
    z = np.exp(1j * 2 * math.pi * 0.05 * col)              # 5 fringes per 100 pixels
    out = _o()
    extras.rifg_fringe(out, Ctx(), {"z": z, "cr": None, "geo": False, "gm": None})
    assert abs(num(metric(out, "Fringe density")) - 5.0) < 0.2


def test_flow_direction_and_consistency():
    a0, r0 = np.full((60, 60), 2.0), np.full((60, 60), 1.0)
    out = _o()
    extras.off_direction(out, Ctx(), {"a0": a0, "r0": r0, "mag": np.hypot(a0, r0), "cr": None, "geo": False, "gm": None})
    assert abs(num(metric(out, "Mean direction")) - math.degrees(math.atan2(2, 1))) < 1.0
    assert num(metric(out, "Direction consistency")) > 0.99


def test_deformation_area_of_a_known_patch():
    z = np.zeros((60, 60)); z[10:30, 10:30] = 3.0          # 400 pixels of 3 cm
    coh = np.full((60, 60), 0.9)
    out = _o()
    extras.unw_deform_area(out, Ctx(), {"disp": z, "coh": coh, "gm": _gm(), "cr": None, "geo": False})
    assert abs(num(metric(out, "Area moving more than")) - 0.16) < 0.005                    # 400 x 400 m2
    assert abs(num(metric(out, "Share of reliable")) - 100 * 400 / 3600) < 0.1


def test_reliable_mask_share():
    coh = np.full((60, 60), 0.9); coh[:, :30] = 0.3
    out = _o()
    extras.unw_reliable(out, Ctx(), {"disp": np.zeros((60, 60)), "coh": coh, "cr": None, "geo": False, "gm": None})
    assert abs(num(metric(out, "Pixels kept")) - 50.0) < 0.1


def test_dry_wet_shares():
    a = np.full((40, 40), 0.25); a[:20, :10] = 0.1; a[20:, 30:] = 0.4      # 12.5 % dry, 12.5 % wet
    out = _o()
    extras.sme_drywet(out, Ctx(), {"arrs": {"sm": a}, "names": ["sm"], "cr": None, "geo": False, "gm": None})
    assert abs(num(metric(out, "Dry")) - 12.5) < 0.1 and abs(num(metric(out, "Wet")) - 12.5) < 0.1


def test_first_change_quiet_on_a_stable_scene():
    stack = [{"arr": {p: _read_pol(make_demo("GCOV", t=i), p) for p in ("HH", "HV")}} for i in (0, 1, 2, 3, 3)]   # no event in any date
    out = _o()
    series.first_change(stack, [0.0, 12.0, 24.0, 36.0, 48.0], [f"2026-0{1 + i}-01" for i in range(5)], Ctx(), out, _geo(N))
    assert num(metric(out, "Pixels that changed")) < 0.5


def test_coherence_change_quiet_when_nothing_changed():
    out = _pair("coherence_change", 3, 3, "GUNW")
    assert num(metric(out, "Pixels that lost")) < 0.5


def test_empty_data_gives_a_clear_message_not_a_numpy_error():
    f = make_demo("GUNW")
    for p in _walk(f):
        if p.endswith("unwrappedPhase"):
            f[p][...] = 0
    out = analyse.run(f, Ctx(want=("all",)), "GUNW")
    assert not any("All-NaN" in n for n in out["notes"]), out["notes"]


def test_water_like_share_with_and_without_water():
    share, _ = _water_like(70)
    assert abs(share - water_truth(70)) < 1.0, share
    share0, _ = _water_like(0)
    assert share0 < 0.5, f"scene without water reports {share0} % water-like"


def _water_like(r):
    orig = with_scene(water_radius=r)
    try:
        out = analyse.run(make_demo("GCOV"), Ctx(), "GCOV")
    finally:
        demo_data._fields = orig
    return num(metric(out, "Water-like share")), out


def _gcov_with_mask(invalid_cols=100, fill_cols=30):
    f = make_demo("GCOV")
    mp = next(p for p in _walk(f) if p.endswith("/mask"))
    mk = f[mp][()]
    mk[:, :invalid_cols] = 0
    mk[:, -fill_cols:] = 255
    f[mp][...] = mk
    return f


def test_mask_invalid_and_fill_pixels_are_excluded():
    out = analyse.run(_gcov_with_mask(100, 30), Ctx(), "GCOV")
    truth_valid = 100 * (N - 130) / N
    assert abs(num(metric(out, "Valid pixels")) - truth_valid) < 0.5, metric(out, "Valid pixels")
    assert abs(num(metric(out, "Excluded by the mask")) - (100 - truth_valid)) < 0.5


def test_mask_decoded_in_quality_extra():
    out = analyse.run(_gcov_with_mask(100, 30), Ctx(want=("quality",)), "GCOV")
    assert abs(num(metric(out, "Mask: invalid or partly focused")) - 100 * 100 / N) < 0.1
    assert abs(num(metric(out, "Mask: outside the image")) - 100 * 30 / N) < 0.1
    assert abs(num(metric(out, "Mask: valid")) - 100 * 370 / N) < 0.1


def test_water_share_counts_only_valid_pixels():
    f = _gcov_with_mask(100, 30)
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    yy, xx = np.mgrid[0:N, 0:N]
    lake = ((xx - 150) ** 2 + (yy - 330) ** 2) < 70 ** 2
    valid = (xx >= 100) & (xx < N - 30)
    truth = 100 * float((lake & valid).sum()) / float(valid.sum())
    assert abs(num(metric(out, "Water share")) - truth) < 1.0, (metric(out, "Water share"), truth)


def test_masked_garbage_does_not_leak_into_statistics():
    """a very bright strip flagged invalid must not change the median or the bright share"""
    f = make_demo("GCOV")
    base = analyse.run(f, Ctx(want=("bright",)), "GCOV")
    f2 = make_demo("GCOV")
    mp = next(p for p in _walk(f2) if p.endswith("/mask"))
    hp = next(p for p in _walk(f2) if p.endswith("/HHHH"))
    mk, hh = f2[mp][()], f2[hp][()]
    mk[:, :60] = 0
    hh[:, :60] = 100.0
    f2[mp][...] = mk; f2[hp][...] = hh
    out = analyse.run(f2, Ctx(want=("bright",)), "GCOV")
    assert num(metric(out, "Very bright share")) < num(metric(base, "Very bright share")) + 0.5


# ================================================================ validation / calibration tool
import validate as V


def test_validate_confusion_hand_computed():
    c = V.confusion(np.array([1, 1, 0, 0, 1], bool), np.array([1, 0, 0, 1, 1], bool))
    assert (c["tp"], c["fp"], c["fn"], c["tn"]) == (2, 1, 1, 1)
    assert abs(c["precision"] - 2 / 3) < 1e-9 and abs(c["recall"] - 2 / 3) < 1e-9
    assert abs(c["iou"] - 0.5) < 1e-9
    assert abs(c["kappa"] - (0.6 - 0.52) / 0.48) < 1e-9            # po = 3/5, pe = 13/25


def test_validate_auc_hand_computed():
    ref = np.array([1, 1, 0, 0], bool)
    assert abs(V.auc(np.array([1.0, 2.0, 3.0, 4.0]), ref) - 1.0) < 1e-12                  # water darker than all land
    assert abs(V.auc(np.array([1.0, 3.0, 2.0, 4.0]), ref) - 0.75) < 1e-12                 # 3 of 4 pairs correct
    assert abs(V.auc(np.array([5.0, 5.0, 5.0, 5.0]), ref) - 0.5) < 1e-12                  # ties = no skill


def test_validate_threshold_sweep_finds_the_lake_threshold():
    f = make_demo("GCOV")
    hh = f["science/LSAR/GCOV/grids/frequencyA/HHHH"][()].astype(float)
    db = extras._smooth_db(hh)
    yy, xx = np.mgrid[0:N, 0:N]
    lake = ((xx - 150) ** 2 + (yy - 330) ** 2) < 70 ** 2
    rows, best, _ = V.sweep_threshold(db, lake)
    assert -24.0 < best["threshold"] < -14.0, best["threshold"]          # lake is -25 dB, land -12.7 dB
    assert best["f1"] > 0.95
    assert V.auc(db, lake) > 0.98


def test_validate_coherence_sweep_error_falls_as_coherence_rises():
    rng = np.random.default_rng(2)
    coh = rng.uniform(0.1, 0.99, 40000)
    sigma = np.sqrt((1 - coh ** 2) / (2 * 20 * coh ** 2)) * analyse.LAMBDA / (4 * math.pi) * 100   # Cramer-Rao, cm
    err = rng.standard_normal(coh.size) * sigma
    rows = V.coherence_sweep(coh, err)
    by = {round(r["limit"], 1): r for r in rows}
    assert by[0.9]["error_cm"] < by[0.6]["error_cm"] < by[0.3]["error_cm"]
    assert by[0.9]["kept"] < by[0.6]["kept"] < by[0.3]["kept"]


def test_validate_cli_on_real_geotiffs_with_different_resolution(tmp_path, capsys=None):
    import rasterio
    from rasterio.transform import from_origin
    n = 100
    pred = np.zeros((n, n), "uint8"); pred[20:60, 30:70] = 1                  # 40 x 40 px result, 20 m pixels
    tr_p = from_origin(625000, 3725000, 20, 20)
    ref = np.zeros((2 * n, 2 * n), "uint8"); ref[40:120, 60:140] = 1          # same square at 10 m pixels
    tr_r = from_origin(625000, 3725000, 10, 10)
    pp, rp = str(tmp_path / "pred.tif"), str(tmp_path / "ref.tif")
    for path, arr, tr in ((pp, pred, tr_p), (rp, ref, tr_r)):
        with rasterio.open(path, "w", driver="GTiff", height=arr.shape[0], width=arr.shape[1], count=1, dtype="uint8", crs="EPSG:32629", transform=tr) as d:
            d.write(arr, 1)
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        V.main(["compare", "--pred", pp, "--ref", rp])
    text = buf.getvalue()
    assert "F1 1.000" in text and "false alarms 0, misses 0" in text, text


# ================================================================ pair-network (SBAS) velocity
from datetime import datetime as _dt, timedelta as _td


def _network(n=40, noise_cm=0.0, bad_pair=None, seed=0):
    """dates 0,12,24,48,60 (one acquisition missing), 8 pairs; right half moves 0.5 cm per 12 days, left half is stable"""
    days = np.array([0, 12, 24, 48, 60.0])
    early = [0, 1, 2, 3, 0, 1, 2, 0]
    late = [1, 2, 3, 4, 2, 3, 4, 4]
    true_u = np.zeros((5, n, n)); true_u[:, :, n // 2:] = (0.5 * days / 12)[:, None, None]
    rng = np.random.default_rng(seed)
    D = np.stack([true_u[l] - true_u[e] for e, l in zip(early, late)])
    D = D + noise_cm * rng.standard_normal(D.shape)
    if bad_pair is not None:
        D[bad_pair, :, n // 2:] += 1.19                      # one unwrapping error (a full fringe)
    return days, early, late, D


def test_sbas_recovers_velocity_with_irregular_dates():
    days, early, late, D = _network()
    r = series.sbas_solve(D, np.ones_like(D), early, late, 5, days)
    truth = 0.5 * 10 / 12 * 365.25
    right = float(np.median(r["vel"][:, 25:])); left = float(np.median(r["vel"][:, :15]))
    assert abs(right - truth) / truth < 0.005, (right, truth)
    assert abs(left) < 0.5


def test_sbas_formal_uncertainty_matches_monte_carlo():
    n = 60
    days, early, late, D = _network(n=n, noise_cm=0.3, seed=1)
    W = np.full(D.shape, 1 / 0.3 ** 2)
    r = series.sbas_solve(D, W, early, late, 5, days)
    empirical = float(np.std(r["vel"][:, :n // 2]))                       # same true velocity (0) on the left half
    reported = float(np.nanmedian(r["sigma_v"]))
    assert abs(reported - empirical) / empirical < 0.12, (reported, empirical)


def test_sbas_misfit_flags_the_inconsistent_pair_only_where_it_is_wrong():
    days, early, late, D = _network(bad_pair=4)                           # pair (0,2) is wrong on the right half
    r = series.sbas_solve(D, np.ones_like(D), early, late, 5, days)
    assert float(np.nanmedian(r["misfit"][:, 25:])) > 0.1
    assert float(np.nanmedian(r["misfit"][:, :15])) < 1e-6


def test_sbas_limits_damage_of_one_bad_pair_compared_with_a_chain():
    days, early, late, D = _network(bad_pair=0)                           # the FIRST pair carries a 1.19 cm error
    truth = 0.5 * 10 / 12 * 365.25
    net = series.sbas_solve(D, np.ones_like(D), early, late, 5, days)
    chain_idx = [0, 1, 2, 3]                                              # a chain can only use the consecutive pairs
    ch = series.sbas_solve(D[chain_idx], np.ones_like(D[chain_idx]), [early[i] for i in chain_idx], [late[i] for i in chain_idx], 5, days)
    err_net = abs(float(np.median(net["vel"][:, 25:])) - truth)
    err_chain = abs(float(np.median(ch["vel"][:, 25:])) - truth)
    assert err_net < err_chain, (err_net, err_chain)


def test_sbas_unconnected_date_gives_nan_not_a_wrong_number():
    days = np.array([0, 12, 24, 36.0])
    D = np.zeros((2, 10, 10)); D[:, :, :] = 0.5
    r = series.sbas_solve(D, np.ones_like(D), [0, 1], [1, 2], 4, days)    # date 3 has no pair at all
    assert np.isnan(r["vel"]).all()


def _fake_unw_stack(n=40, names_with_pairs=True):
    days, early, late, D = _network(n=n)
    base = _dt(2026, 1, 1)
    stack = []
    for k in range(len(early)):
        pr = (base + _td(days=float(days[early[k]])), base + _td(days=float(days[late[k]])), "file metadata") if names_with_pairs else None
        stack.append({"arr": {"disp": D[k], "coh": np.full((n, n), 0.9)}, "pair": pr})
    return stack, days


def test_velocity_uses_the_pair_network_when_dates_are_known():
    stack, days = _fake_unw_stack()
    out = {"metrics": [], "images": [], "notes": []}
    series.velocity(stack, list(range(len(stack))), [f"p{i}" for i in range(len(stack))], Ctx(baseline_days=12), out, _geo(40))
    assert "8 pairs over 5 dates" in metric(out, "Pair network")
    v = out["_raw"]["Line-of-sight velocity (mm/yr)"]["a"]
    truth = 0.5 * 10 / 12 * 365.25
    assert abs(float(np.nanmedian(v[:, 25:])) - truth) / truth < 0.01
    assert "Velocity uncertainty (mm/yr)" in out["_raw"] and "Network misfit (cm)" in out["_raw"]


def test_velocity_falls_back_to_the_chain_without_pair_dates():
    stack, days = _fake_unw_stack(names_with_pairs=False)
    out = {"metrics": [], "images": [], "notes": []}
    series.velocity(stack[:4], [0.0, 12.0, 24.0, 48.0], list("abcd"), Ctx(baseline_days=12), out, _geo(40))
    assert not any(m["label"] == "Pair network" for m in out["metrics"])
    assert any("chained" in n for n in out["notes"])


def test_pair_dates_from_file_name_and_metadata():
    class F:  # minimal stand-ins for an open file
        def __init__(self, filename, data=None): self.filename, self.data = filename, data or {}
        def __getitem__(self, k): return np.array(self.data[k])
    class S:
        def __init__(self, f, idx): self.f, self.idx = f, idx
    name = "NISAR_L2_PR_GUNW_001_005_A_002_4005_SHNA_A_20260101T000000_20260101T000020_20260113T000000_20260113T000020_X05009_N_F_J_001.h5"
    got = series.pair_dates(S(F(name), {}) if False else S(F(name), {}))
    assert got and got[0] == _dt(2026, 1, 1) and got[1] == _dt(2026, 1, 13) and "file name" in got[2]
    md = {"/x/referenceZeroDopplerStartTime": "2026-02-01T10:00:00", "/x/secondaryZeroDopplerStartTime": "2026-02-13T10:00:00"}
    got2 = series.pair_dates(S(F("whatever.h5", md), md))
    assert got2 and got2[0] == _dt(2026, 2, 1, 10) and got2[1] == _dt(2026, 2, 13, 10) and got2[2] == "file metadata"
    assert series.pair_dates(S(F("single_acquisition.h5"), {})) is None        # never guessed


# ================================================================ optional DEM slope exclusion
def _write_dem(path, fn, res=10.0, extent=11000.0):
    import rasterio
    from rasterio.transform import from_origin
    n = int(extent / res)
    cols = (np.arange(n) * res)[None, :] * np.ones((n, 1))                 # metres east of the scene origin
    z = fn(cols).astype("float32")
    with rasterio.open(str(path), "w", driver="GTiff", height=n, width=n, count=1, dtype="float32", crs="EPSG:32629",
                       transform=from_origin(625000, 3725000, res, res)) as d:
        d.write(z, 1)


def test_dem_slope_of_a_known_plane(tmp_path):
    _write_dem(tmp_path / "dem.tif", lambda x: x * math.tan(math.radians(10.0)))          # 10 degree plane, 10 m DEM
    gm = {"dx": 20.0, "dy": 20.0, "epsg": 32629, "left": 625000.0, "top": 3725000.0}
    sl = extras.dem_slope(str(tmp_path / "dem.tif"), gm, (200, 200))
    assert abs(float(np.nanmedian(sl)) - 10.0) < 0.3


def _water_with_dem(tmp_path, fn):
    _write_dem(tmp_path / "dem.tif", fn)
    out = analyse.run(make_demo("GCOV"), Ctx(want=("water",), params={"dem": str(tmp_path / "dem.tif"), "max_slope": 10.0}), "GCOV")
    return out


def test_water_on_flat_terrain_is_kept_with_a_dem(tmp_path):
    out = _water_with_dem(tmp_path, lambda x: np.zeros_like(x))
    assert abs(num(metric(out, "Water share")) - water_truth(70)) < 1.0


def test_dark_patch_on_steep_terrain_is_not_called_water(tmp_path):
    # 30 degree slope under the whole lake (x < 5 km): that "water" is radar shadow, not a lake
    out = _water_with_dem(tmp_path, lambda x: np.where(x < 5000, x * math.tan(math.radians(30.0)), 5000 * math.tan(math.radians(30.0))))
    assert num(metric(out, "Water share")) < 1.0, metric(out, "Water share")
    assert "Excluded as steep terrain" in [m["label"] for m in out["metrics"]]


def test_flood_ignores_new_water_on_steep_terrain(tmp_path):
    _write_dem(tmp_path / "dem.tif", lambda x: np.where(x > 5000, (x - 5000) * math.tan(math.radians(30.0)), 0.0))   # flooded box (x>5 km) is steep
    ctx = Ctx(params={"dem": str(tmp_path / "dem.tif"), "max_slope": 10.0})
    out = pairs.run(make_demo("GCOV", t=3), make_demo("GCOV", t=5), ctx, "flood")
    assert num(metric(out, "New open water")) < 0.3, metric(out, "New open water")
    assert abs(num(metric(out, "Permanent water")) - water_truth(70)) < 1.0                 # the real lake is on flat ground


# ================================================================ change detection: real looks and chosen false-alarm rate
def test_change_threshold_uses_the_files_number_of_looks():
    def gc(nl):
        f = make_demo("GCOV")
        p = next(q for q in _walk(f) if q.endswith("/numberOfLooks"))
        f[p][...] = np.full(f[p].shape, nl, dtype=f[p].dtype)
        return f
    o100 = pairs.run(gc(100.0), gc(100.0), Ctx(), "gcov_change")
    o4 = pairs.run(gc(4.0), gc(4.0), Ctx(), "gcov_change")
    thr = lambda out: float(re.search(r"between ([\d.]+) and ([\d.]+) dB", " ".join(str(m.get("note", "")) for m in out["metrics"])).group(2))
    assert abs(thr(o100) - 4.343 * math.sqrt(2 / 100)) < 0.01       # upper bound follows the file's own looks
    assert abs(thr(o4) - 4.343 * math.sqrt(2 / 4)) < 0.01


def test_change_false_alarm_rate_sets_the_threshold():
    out = pairs.run(make_demo("GCOV", t=3), make_demo("GCOV", t=5), Ctx(params={"false_alarm": 0.0027}), "gcov_change")
    note = " ".join(str(m.get("note", "")) for m in out["metrics"])
    assert "3 x" in note or "3.0 x" in note or "3.00 x" in note, note              # 0.27 % two-sided = 3 sigma
    out2 = pairs.run(make_demo("GCOV", t=3), make_demo("GCOV", t=5), Ctx(params={"false_alarm": 0.05}), "gcov_change")
    assert "1.96 x" in " ".join(str(m.get("note", "")) for m in out2["metrics"])


# ================================================================ rivers: thin water next to dark dry ground
from scipy import ndimage as _ndi


def _river_scene(width, river_db=-24.0, plateau_db=-19.0, psf=0.8, with_river=True, L=16, seed=1):
    """land -12.5 dB, two dark DRY plateaus (not water), a meandering river `width` pixels wide blurred by a sensor PSF"""
    rng = np.random.default_rng(seed)
    f = make_demo("GCOV")
    g = f["science/LSAR/GCOV/grids/frequencyA"]
    yy, xx = np.mgrid[0:N, 0:N]
    river = (np.abs(yy - (250 + 60 * np.sin(xx / 55.0))) <= width / 2.0) if with_river else np.zeros((N, N), bool)
    plateau = (((xx - 90) ** 2 + (yy - 90) ** 2) < 55 ** 2) | (((xx - 400) ** 2 + (yy - 400) ** 2) < 60 ** 2)
    sp = lambda db: 10 ** (db / 10) * rng.gamma(L, 1.0 / L, (N, N))
    frac = _ndi.gaussian_filter(river.astype(float), psf) if psf > 0 else river.astype(float)
    for pol, land, riv, plat in (("HHHH", -12.5, river_db, plateau_db), ("VVVV", -11.5, river_db + 2, plateau_db + 1), ("HVHV", -19.5, river_db - 8, -27.0)):
        a = sp(land)
        a[plateau] = sp(plat)[plateau]
        a = a * (1 - frac) + sp(riv) * frac
        g[pol][...] = a.astype(g[pol].dtype)
    return f, river


def _river_scores(width, **kw):
    f, river = _river_scene(width, **kw)
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    mask = out["_raw"]["Water map"]["a"] > 0.5
    c = V.confusion(mask, river)
    return c["recall"], c["precision"], out


def test_river_6px_is_mapped_and_dark_dry_plateaus_are_not():
    rec, prec, _ = _river_scores(6)
    assert rec > 0.8 and prec > 0.9, (rec, prec)          # edge pixels are mixed with the banks, so recall is below 1


def test_river_4px_is_mapped_and_dark_dry_plateaus_are_not():
    rec, prec, _ = _river_scores(4)
    assert rec > 0.7 and prec > 0.9, (rec, prec)


def test_thin_2px_river_without_blur_is_still_found():
    rec, prec, _ = _river_scores(2, psf=0.0)
    assert rec > 0.9 and prec > 0.9, (rec, prec)


def test_dark_dry_plateaus_alone_are_not_water():
    f, _ = _river_scene(4, with_river=False)
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    assert num(metric(out, "Water share")) < 0.5


def test_water_report_tells_river_from_lake():
    _, _, out = _river_scores(6)
    assert "river-like" in metric(out, "Water region 1")
    orig = with_scene(water_radius=70)
    try:
        lake = analyse.run(make_demo("GCOV"), Ctx(want=("water",)), "GCOV")
    finally:
        demo_data._fields = orig
    assert "lake-like" in metric(lake, "Water region 1")


def test_water_limits_can_be_changed():
    f, river = _river_scene(6, river_db=-19.0)                  # a wind-roughened, brighter river: default limits miss it
    miss = analyse.run(f, Ctx(want=("water",)), "GCOV")["_raw"]["Water map"]["a"] > 0.5
    f2, river2 = _river_scene(6, river_db=-19.0)
    hit = analyse.run(f2, Ctx(want=("water",), params={"water_core_db": -17.0, "water_grow_db": -15.0}), "GCOV")["_raw"]["Water map"]["a"] > 0.5
    assert V.confusion(hit, river2)["recall"] > V.confusion(miss, river)["recall"] + 0.3


def test_dem_path_must_be_a_local_geotiff(tmp_path):
    for bad in ("http://example.com/dem.tif", "/etc/passwd", str(tmp_path / "missing.tif")):
        try:
            analyse.run(make_demo("GCOV"), Ctx(want=("water",), params={"dem": bad}), "GCOV")
            out = analyse.run(make_demo("GCOV"), Ctx(want=("water",), params={"dem": bad}), "GCOV")
        except Exception as ex:                      # a refusal must never become a read of that path
            raise AssertionError(f"{bad}: unexpected exception {ex}")
        assert any("local .tif" in n for n in out["notes"]), (bad, out["notes"])


# ================================================================ remaining analyses (third pass)
def _grp(f, name):
    p = next(q for q in _walk(f) if q.endswith("/" + name))
    return p, p.rsplit("/", 1)[0]


def test_speed_series_pure_noise_is_not_speed():
    rng = np.random.default_rng(3)
    stack = [{"arr": {"a": 0.3 * rng.standard_normal((50, 50)), "r": 0.3 * rng.standard_normal((50, 50))}} for _ in range(6)]
    out = _o()
    series.speed_series(stack, [12.0 * i for i in range(6)], [f"2026-0{1 + i}-01" for i in range(6)], Ctx(baseline_days=12), out, _geo(50))
    assert "not significant" in metric(out, "95th percentile speed"), metric(out, "95th percentile speed")


def test_speed_series_real_motion_is_reported():
    rng = np.random.default_rng(4)
    stack = []
    for _ in range(6):
        a, r = 0.3 * rng.standard_normal((50, 50)), 0.3 * rng.standard_normal((50, 50))
        a[:, 35:] += 5.0                                       # 30 % of the window moves 5 m per 12 days (the median stays on the stable ground)
        stack.append({"arr": {"a": a, "r": r}})
    out = _o()
    series.speed_series(stack, [12.0 * i for i in range(6)], [f"2026-0{1 + i}-01" for i in range(6)], Ctx(baseline_days=12), out, _geo(50))
    v = metric(out, "95th percentile speed")
    assert "not significant" not in v and abs(num(v) - 5.0 / 12 * 365.25) / (5.0 / 12 * 365.25) < 0.1, v


def test_coherence_series_values_and_drop():
    cohs = [0.9, 0.9, 0.85, 0.4, 0.4]
    stack = [{"arr": {"coh": np.full((30, 30), c)}} for c in cohs]
    dates = [f"2026-0{1 + i}-01" for i in range(5)]
    out = _o()
    series.coh_series(stack, list(range(5)), dates, Ctx(), out, _geo(30))
    assert abs(num(metric(out, "Mean coherence")) - np.mean(cohs)) < 0.01
    drop = metric(out, "Largest coherence drop")
    assert abs(num(drop) - (-0.45)) < 0.01 and dates[2] in drop and dates[3] in drop, drop


def _goff_gunw(sign):
    """offsets equal to +/- the interferometric displacement, so the right answer is known"""
    fa, fb = make_demo("GOFF"), make_demo("GUNW")
    pp, _ = _grp(fb, "unwrappedPhase")
    ph = fb[pp][()].astype(float)
    disp_m = ph * analyse.LAMBDA / (4 * math.pi)
    rp, _ = _grp(fa, "slantRangeOffset")
    fa[rp][...] = (sign * disp_m).astype(fa[rp].dtype)
    return pairs.run(fa, fb, Ctx(), "goff_gunw")


def test_goff_gunw_same_sign_agrees():
    out = _goff_gunw(+1.0)
    assert num(metric(out, "Correlation")) > 0.95
    assert not any("opposite signs" in n for n in out["notes"])


def test_goff_gunw_opposite_sign_is_detected_and_flipped():
    out = _goff_gunw(-1.0)
    assert any("opposite signs" in n for n in out["notes"]), out["notes"]
    assert num(metric(out, "Correlation")) > 0.95                         # after the flip the two agree
    assert abs(num(metric(out, "Agreement where both are valid").split("rms")[0])) < 0.3     # bias near zero


def test_crop_classes_exclude_the_fill_value():
    f = make_demo("SME2")
    p, _ = _grp(f, "cropType")
    a = f[p][()]
    a[:10, :] = 255                                                       # 20 % of the cells are fill
    f[p][...] = a
    f[p].attrs["_FillValue"] = np.uint8(255)
    out = analyse.run(f, Ctx(want=("vegcrop",)), "SME2")
    labels = [m["label"] for m in out["metrics"] if m["label"].startswith("cropType")]
    assert "cropType: class 255" not in labels, labels
    shares = [num(m["value"]) for m in out["metrics"] if m["label"].startswith("cropType: class")]
    assert abs(sum(shares) - 100.0) < 1.0, shares                         # shares are of the VALID cells


def test_soil_moisture_uncertainty_values():
    f = make_demo("SME2")
    p, _ = _grp(f, "soilMoistureUncertainty")
    f[p][...] = np.full(f[p].shape, 0.04, dtype=f[p].dtype)
    out = analyse.run(f, Ctx(want=("uncertainty",)), "SME2")
    assert abs(num(metric(out, "Soil-moisture uncertainty")) - 0.04) < 0.001


def _gunw_with_screen(units):
    f = make_demo("GUNW")
    pp, grp = _grp(f, "unwrappedPhase")
    xx = np.tile(np.arange(N), (N, 1))
    ds = f.create_dataset(grp + "/wetTroposphericPhaseScreen", data=(0.002 * xx).astype("float32"))   # the demo's phase ramp
    if units:
        ds.attrs["units"] = units
    return analyse.run(f, Ctx(want=("corrections",)), "GUNW")


def test_corrections_in_radians_remove_the_ramp():
    out = _gunw_with_screen(b"radians")
    v = metric(out, "Spread after troposphere and tide correction")
    after, before = (float(x) for x in re.findall(r"(\d+\.\d+) cm", v)[:2])
    ramp_std = 0.002 * N / math.sqrt(12) * analyse.LAMBDA / (4 * math.pi) * 100          # the demo ramp, in cm (0.548)
    assert abs(after - math.sqrt(before ** 2 - ramp_std ** 2)) < 0.05, (v, ramp_std)       # removing an independent ramp


def test_corrections_in_unknown_units_are_not_subtracted():
    for units in (b"meters", None):
        out = _gunw_with_screen(units)
        assert not any(m["label"].startswith("Spread after troposphere") for m in out["metrics"])
        assert any("units are not radians" in n for n in out["notes"]), out["notes"]


def test_offset_quality_removes_low_correlation_and_spikes():
    f = make_demo("GOFF")
    cp, _ = _grp(f, "correlationSurfacePeak")
    sp, _ = _grp(f, "snr")
    rp, _ = _grp(f, "slantRangeOffset")
    c = np.full((N, N), 0.5, "float32"); c[:, :100] = 0.02                  # 20 % of the scene below the 0.1 limit
    f[cp][...] = c
    f[sp][...] = np.full((N, N), 10.0, "float32")                           # flat SNR: nothing to remove
    r = f[rp][()]
    r[10:12, 300:325] = 80.0                                                # 50 spikes in the valid part
    f[rp][...] = r
    out = analyse.run(f, Ctx(want=("quality",)), "GOFF")
    kept = num(metric(out, "Pixels kept"))
    assert abs(kept - 80.0) < 0.5, kept


def test_gcov_sme2_recovers_a_known_relation():
    fa, fb = make_demo("GCOV"), make_demo("SME2")
    sp, _ = _grp(fb, "soilMoisture")
    sm = np.where(fb[sp][()] >= 0, fb[sp][()], 0.0).astype(float)
    big = np.kron(sm, np.ones((N // sm.shape[0], N // sm.shape[1])))        # soil moisture on the GCOV grid
    hp, _ = _grp(fa, "HHHH")
    fa[hp][...] = (10 ** ((-20.0 + 30.0 * big) / 10)).astype(fa[hp].dtype)  # backscatter = -20 dB + 30 dB x soil moisture
    out = pairs.run(fa, fb, Ctx(), "gcov_sme2")
    assert num(metric(out, "Correlation")) > 0.99
    assert abs(num(metric(out, "Straight-line fit")) - 3.0) < 0.1            # 30 dB per unit = 3.0 dB per 0.1


def test_gcov_sme2_unrelated_data_has_no_correlation():
    out = pairs.run(make_demo("GCOV"), make_demo("SME2"), Ctx(), "gcov_sme2")
    assert abs(num(metric(out, "Correlation"))) < 0.25


def test_noise_estimate_is_not_inflated_by_real_motion():
    rng = np.random.default_rng(8)
    x = 0.3 * rng.standard_normal((200, 200))
    moving = x.copy(); moving[:, 100:] += 5.0 * np.exp(-((np.arange(100)[None, :] - 50) ** 2) / 800.0)    # large smooth motion
    assert abs(analyse.noise_hf(x) - 0.3) < 0.02
    mad = 1.4826 * float(np.median(np.abs(moving - np.median(moving))))
    assert mad > 0.8                                             # the spread of the whole field is badly inflated by the motion
    assert abs(analyse.noise_hf(moving) - 0.3) < 0.06            # the neighbour-difference estimate is not


# ================================================================ lakes brighter than the usual limits (wind, gamma-0)
def _lake_scene(lake_db, radius=90, land_db=-12.5, L=16, seed=2):
    rng = np.random.default_rng(seed)
    f = make_demo("GCOV")
    g = f["science/LSAR/GCOV/grids/frequencyA"]
    yy, xx = np.mgrid[0:N, 0:N]
    lake = ((xx - 250) ** 2 + (yy - 250) ** 2) < radius ** 2
    sp = lambda db: 10 ** (db / 10) * rng.gamma(L, 1.0 / L, (N, N))
    for pol, land, wat in (("HHHH", land_db, lake_db), ("VVVV", land_db + 1, lake_db + 2), ("HVHV", -19.5, lake_db - 8)):
        a = sp(land)
        a[lake] = sp(wat)[lake]
        g[pol][...] = a.astype(g[pol].dtype)
    return f, lake


def test_calm_lake_is_in_the_strict_layer_not_the_uncertain_one():
    f, lake = _lake_scene(-24.0)
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    strict = out["_raw"]["Water map"]["a"] > 0.5
    assert V.confusion(strict, lake)["recall"] > 0.95
    assert not any(m["label"].startswith("Possible water") for m in out["metrics"])


def test_wind_roughened_lake_is_found_as_possible_water():
    f, lake = _lake_scene(-17.5)                                    # brighter than the -20 dB seed: the strict layer misses it
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    assert out["_raw"]["Water map"]["a"].sum() < 0.1 * lake.sum()
    poss = out["_raw"]["Possible water (uncertain)"]["a"] > 0.5
    c = V.confusion(poss, lake)
    assert c["recall"] > 0.9 and c["precision"] > 0.9, c
    assert "uncertain" in " ".join(m["label"] for m in out["metrics"]).lower()


def test_no_water_scene_has_no_possible_water():
    orig = with_scene(water_radius=0)
    try:
        out = analyse.run(make_demo("GCOV"), Ctx(want=("water",)), "GCOV")
    finally:
        demo_data._fields = orig
    assert not any(m["label"].startswith("Possible water") for m in out["metrics"])


def test_very_bright_lake_gets_an_explanation_with_numbers():
    f, lake = _lake_scene(-14.0, land_db=-9.0)                      # nothing is dark enough for any layer
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    note = " ".join(out["notes"])
    assert "darkest 1 %" in note and "raise both limits" in note, note


def test_raising_the_limits_finds_the_bright_lake():
    f, lake = _lake_scene(-17.5)
    hit = analyse.run(f, Ctx(want=("water",), params={"water_core_db": -16.0, "water_grow_db": -14.5}), "GCOV")["_raw"]["Water map"]["a"] > 0.5
    c = V.confusion(hit, lake)
    assert c["recall"] > 0.9 and c["precision"] > 0.9, c


def test_heterogeneous_land_does_not_create_possible_water():
    """real land is not one tidy class: a wide, smooth spread of backscatter must not be split into 'water'"""
    rng = np.random.default_rng(6)
    f = make_demo("GCOV")
    g = f["science/LSAR/GCOV/grids/frequencyA"]
    field = _ndi.gaussian_filter(rng.standard_normal((N, N)), 12)
    field = field / field.std() * 3.0                                    # 3 dB spread of smooth field patterns
    sp = lambda: rng.gamma(16, 1.0 / 16, (N, N))
    for pol, base in (("HHHH", -12.5), ("VVVV", -11.5), ("HVHV", -19.5)):
        g[pol][...] = (10 ** ((base + field) / 10) * sp()).astype(g[pol].dtype)
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    assert not any(m["label"].startswith("Possible water") for m in out["metrics"])
    assert num(metric(out, "Water share")) < 1.0


def test_dim_lake_3_5_db_below_land_is_still_found_as_possible_water():
    f, lake = _lake_scene(-16.5)
    out = analyse.run(f, Ctx(want=("water",)), "GCOV")
    c = V.confusion(out["_raw"]["Possible water (uncertain)"]["a"] > 0.5, lake)
    assert c["recall"] > 0.85 and c["precision"] > 0.9, c


if __name__ == "__main__":
    import sys
    import traceback
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                import inspect, tempfile, pathlib
                if "tmp_path" in inspect.signature(fn).parameters:
                    with tempfile.TemporaryDirectory() as td:
                        fn(pathlib.Path(td))
                else:
                    fn()
                print("PASS", name)
            except Exception as e:  # noqa
                bad += 1
                print("FAIL", name, "->", str(e).splitlines()[0][:150] if str(e) else repr(e))
    print(f"\n{bad} failing")
    sys.exit(1 if bad else 0)
