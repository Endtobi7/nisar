"""Analyses over MANY files (a time series). Files must share track, frame, orbit direction and grid."""
import math
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

import numpy as np

import analyse as A
import pairs as P
import render
from analyse import Ctx, Unsupported

M, IMG, nf, pct = A.M, A.IMG, A.nf, A.pct


def _t(s):
    return datetime.fromisoformat(str(s).replace("Z", "+00:00")).replace(tzinfo=None)


def _series(out, name, x, ys, xl, yl, labels=None):
    for nm, y in ys.items():
        out.setdefault("series", []).append({"name": f"{name}: {nm}" if name else nm, "x": [float(v) for v in x], "y": [None if not np.isfinite(v) else float(v) for v in y], "xlabel": xl, "ylabel": yl, "labels": labels})


# ---------- readers: one file -> dict of arrays + geo meta ----------
def rd_gcov(src, ctx):
    pols = [p for p in ("HH", "HV", "VV", "VH") if P._has(src, p + p)]
    if not pols:
        raise Unsupported("No GCOV diagonal layers found.")
    p0 = src.path(pols[0] + pols[0])
    win, cr, geo_, sp, gm = src.locate(p0, ctx)
    if not geo_:
        raise Unsupported("Series need geocoded products.")
    arr = {}
    for p in pols:
        a = src.read(src.path(p + p), win).astype(float)
        arr[p] = np.where(a > 0, a, np.nan)
    return {"arr": arr, "meta": (win, cr, gm, sp)}


def rd_unw(src, ctx):
    disp, coh, win, cr, gm, sp, geo_ = P._unw(src, ctx)
    if not geo_:
        raise Unsupported("Series need geocoded products.")
    return {"arr": {"disp": disp, "coh": coh}, "meta": (win, cr, gm, sp), "pair": pair_dates(src)}


def rd_off(src, ctx):
    pa = src.path("alongTrackOffset", prefer=("frequencyA", "layer1", "HH"))
    pr = src.path("slantRangeOffset", prefer=("frequencyA", "layer1", "HH"))
    win, cr, geo_, sp, gm = src.locate(pa, ctx)
    if not geo_:
        raise Unsupported("Series need geocoded products.")
    a, r = src.read(pa, win).astype(float), src.read(pr, win).astype(float)
    return {"arr": {"a": a, "r": r}, "meta": (win, cr, gm, sp)}


def rd_sme(src, ctx):
    names = [p for p in src.idx if "soilmoisture" in p.rsplit("/", 1)[-1].lower() and "uncert" not in p.lower()]
    if not names:
        raise Unsupported("No soil-moisture layer found.")
    names.sort(key=lambda p: (len(p), p))
    win, cr, geo_, sp, gm = src.locate(names[0], ctx)
    if not geo_:
        raise Unsupported("Series need geocoded products.")
    a = src.read(names[0], win).astype(float)
    return {"arr": {"sm": np.where((a >= 0) & np.isfinite(a), a, np.nan)}, "meta": (win, cr, gm, sp)}


def load_stack(opens, prod, reader, ctx):
    def one(op, c):
        f = op()
        try:
            return reader(P.Src(f, prod), c)
        finally:
            try:
                f.close()
            except Exception:
                pass

    first = one(opens[0], ctx)
    win, cr, gm, sp = first["meta"]
    c2 = Ctx(bbox=P.bbox_of(cr), max_px=ctx.max_px, default_px=ctx.default_px, baseline_days=ctx.baseline_days, params=ctx.params)
    with ThreadPoolExecutor(max_workers=4) as ex:
        rest = list(ex.map(lambda op: one(op, c2), opens[1:]))
    stack = [first] + rest
    shape = next(iter(first["arr"].values())).shape
    for s in stack[1:]:
        P.check_cover(cr, s["meta"][1])
        for k, a in s["arr"].items():
            s["arr"][k] = P.fit_to(a, shape)
    return stack, win, cr, gm, sp


# ---------- analyses ----------
def _pol(stack):
    return next((p for p in ("HH", "VV") if all(p in s["arr"] for s in stack)), None)


def gcov_ts(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    pols = [p for p in ("HH", "HV", "VV", "VH") if all(p in s["arr"] for s in stack)]
    ys = {p: np.array([10 * np.log10(np.nanmean(s["arr"][p])) for s in stack]) for p in pols}
    co = _pol(stack)
    if co and "HV" in ys:
        ys["HV - " + co] = ys["HV"] - ys[co]
    _series(out, "Backscatter", days, ys, "days since the first date", "dB", dates)
    ref = ys[co or pols[0]]
    slope = float(np.polyfit(days, ref, 1)[0] * 365.25) if len(days) > 1 else float("nan")
    M(out, "Dates", f"{len(days)} from {dates[0]} to {dates[-1]}")
    for p in pols:
        M(out, f"{p} mean backscatter", f"{nf(float(ys[p].mean()), 1)} dB, range {nf(float(ys[p].min()), 1)} to {nf(float(ys[p].max()), 1)} dB")
    M(out, f"{co or pols[0]} trend", f"{nf(slope, 2)} dB per year", "Short records give a very uncertain trend")
    dd = np.diff(ref)
    if len(dd):
        k = int(np.argmin(dd))
        M(out, "Largest drop between two dates", f"{nf(float(dd[k]), 2)} dB between {dates[k]} and {dates[k + 1]}")
        k = int(np.argmax(dd))
        M(out, "Largest rise between two dates", f"{nf(float(dd[k]), 2)} dB between {dates[k]} and {dates[k + 1]}")
    cube = np.stack([10 * np.log10(s["arr"][co or pols[0]]) for s in stack])
    sd = np.nanstd(cube, 0)
    hi = pct(sd, 98)[0] or 1e-6
    IMG(out, "Variability over time (std dev, dB)", render.colormap_png(sd, 0, hi, "viridis"), cr, True, {"min": 0, "max": hi, "unit": "dB"}, raw=sd, gm=gm)


def first_change(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    if len(stack) < 5:
        raise Unsupported("Date of first change needs at least 5 dates (3 baseline dates plus a change).")
    p = "HV" if all("HV" in s["arr"] for s in stack) else _pol(stack)
    cube = np.stack([P.db_of(P.multilook(s["arr"][p])) for s in stack])
    base = cube[:3]
    mu, sig = np.nanmean(base, 0), np.maximum(np.nanstd(base, 0), 1.0)
    thr = ctx.p("k_sigma", 3.0)
    exc = np.abs((cube - mu) / sig) > thr
    two = exc[3:-1] & exc[4:]
    has = two.any(0)
    first = np.argmax(two, 0) + 3
    day_map = np.where(has, np.asarray(days)[first], np.nan)
    v = np.isfinite(mu)
    t0 = _t(dates[0])
    M(out, "Layer used", p, "HV is preferred: most sensitive to vegetation change")
    M(out, "Pixels that changed", f"{nf(A.share(has, v), 1)} % - {P.gm_area(int((has & v).sum()), gm)}", f"Baseline = first 3 dates; change = more than {thr:g} sigma (at least 1 dB) on two dates in a row")
    if has.any():
        M(out, "Earliest change", (t0 + timedelta(days=float(np.nanmin(day_map)))).strftime("%Y-%m-%d"))
        M(out, "Latest first-change", (t0 + timedelta(days=float(np.nanmax(day_map)))).strftime("%Y-%m-%d"))
    hi = float(np.nanmax(day_map)) if has.any() else 1.0
    IMG(out, "Day of first change (days since the first date)", render.colormap_png(day_map, 0, max(hi, 1.0), "viridis"), cr, True, {"min": 0, "max": max(hi, 1.0), "unit": "days"}, raw=day_map, gm=gm)


def temporal_avg(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    p = _pol(stack) or "HV"
    cube = np.stack([s["arr"][p] for s in stack])
    mean = np.nanmean(cube, 0)
    cv = np.nanstd(cube, 0) / np.maximum(mean, 1e-12)
    d = P.db_of(mean)
    lo, hi = pct(d, 2, 98)
    M(out, f"{p} temporal average", f"median {nf(float(np.nanmedian(d)), 1)} dB over {len(stack)} dates", f"Speckle reduced by about a factor {math.sqrt(len(stack)):.1f}")
    M(out, "Variability (coefficient of variation)", f"median {nf(float(np.nanmedian(cv)), 2)}, 95th percentile {nf(pct(cv, 95)[0], 2)}", "Low = stable surfaces; high = changing (crops, water, wetlands)")
    IMG(out, f"{p} temporal average (dB)", render.colormap_png(d, lo, hi, "gray"), cr, True, {"min": lo, "max": hi, "unit": "dB"}, raw=d, gm=gm)
    a, b = pct(cv, 2, 98)
    IMG(out, "Coefficient of variation over time", render.colormap_png(cv, a, b, "viridis"), cr, True, {"min": a, "max": b, "unit": ""}, raw=cv, gm=gm)


def coh_series(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    mean = np.array([float(np.nanmean(s["arr"]["coh"])) for s in stack])
    good = np.array([A.share(s["arr"]["coh"] > 0.6, np.isfinite(s["arr"]["coh"])) for s in stack])
    _series(out, "Coherence", days, {"mean coherence": mean}, "days since the first date", "coherence", dates)
    _series(out, "Coherence", days, {"share above 0.6 (%)": good}, "days since the first date", "%", dates)
    M(out, "Mean coherence", f"{nf(float(mean.mean()), 2)} (range {nf(float(mean.min()), 2)} to {nf(float(mean.max()), 2)})")
    dd = np.diff(mean)
    if len(dd):
        k = int(np.argmin(dd))
        M(out, "Largest coherence drop", f"{nf(float(dd[k]), 2)} between {dates[k]} and {dates[k + 1]}", "Often a change event: damage, flooding, harvest, snow")
    cube = np.stack([s["arr"]["coh"] for s in stack])
    mc = np.nanmean(cube, 0)
    IMG(out, "Mean coherence over all pairs", render.colormap_png(mc, 0, 1, "gray"), cr, True, {"min": 0, "max": 1, "unit": ""}, raw=mc, gm=gm)



# ---------- pair network (SBAS-style) velocity ----------
import re as _re

_TS = _re.compile(r"(\d{8}T\d{6})")


def _parse_ts(x):
    x = str(x).strip()
    for fmt in ("%Y%m%dT%H%M%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(x[:26] if "%f" in fmt else x[:19], fmt)
        except ValueError:
            continue
    return None


def _scalar_text(f, p):
    v = f[p][()]
    v = v.decode() if isinstance(v, bytes) else v
    return v.item() if hasattr(v, "item") else v


def pair_dates(src):
    """(reference_datetime, secondary_datetime, where_it_came_from) of an interferometric pair, or None.
    1) metadata datasets whose names contain 'reference' / 'secondary' and 'ZeroDopplerStartTime';
    2) the file name, if it holds four acquisition times (reference start/end, secondary start/end).
    Anything else is not guessed."""
    try:
        ref = sec = None
        for p in src.idx:
            low = p.rsplit("/", 1)[-1].lower()
            if "zerodopplerstarttime" not in low:
                continue
            if "reference" in low:
                ref = _parse_ts(_scalar_text(src.f, p))
            elif "secondary" in low:
                sec = _parse_ts(_scalar_text(src.f, p))
        if ref and sec and ref != sec:
            return ref, sec, "file metadata"
    except Exception:
        pass
    try:
        ts = _TS.findall(str(getattr(src.f, "filename", "") or ""))
        if len(ts) >= 4:
            a, b = _parse_ts(ts[0]), _parse_ts(ts[2])
            if a and b and a != b:
                return a, b, "file name (first and third time stamps)"
    except Exception:
        pass
    return None


def sbas_solve(D, W, early, late, n_dates, t_days, chunk=20000):
    """Weighted least-squares inversion of a network of interferometric pairs.

    D: (K, H, W) change measured by each pair, in cm (NaN where unknown); pair k = u[late[k]] - u[early[k]].
    W: (K, H, W) weights = 1 / variance of that measurement (0 where unknown).
    Date 0 is the reference (u = 0). Returns dict with
      u        (n_dates, H, W)  cumulative change of every date in cm
      vel      (H, W)           line-of-sight velocity, straight-line fit to u(t), mm/yr
      sigma_v  (H, W)           formal 1-sigma of that velocity (from the weights), mm/yr
      misfit   (H, W)           weighted RMS of the pair residuals in cm (NaN without redundancy)
    Pixels where some date is not constrained by any valid pair are NaN."""
    K, H, Wd = D.shape
    m = n_dates - 1
    A_ = np.zeros((K, m))
    for k in range(K):
        if early[k] > 0:
            A_[k, early[k] - 1] = -1.0
        if late[k] > 0:
            A_[k, late[k] - 1] = 1.0
    t = np.asarray(t_days, float)
    tc = t - t.mean()
    sxx = float((tc ** 2).sum())
    cvec = tc[1:] / sxx                                   # velocity = sum_i c_i u_i (u_0 = 0 adds nothing)
    Df, Wf = D.reshape(K, -1), W.reshape(K, -1)
    P = Df.shape[1]
    u = np.full((n_dates, P), np.nan)
    sv = np.full(P, np.nan)
    mis = np.full(P, np.nan)
    for s0 in range(0, P, chunk):
        d = Df[:, s0:s0 + chunk]
        w = np.where(np.isfinite(d), Wf[:, s0:s0 + chunk], 0.0)
        d = np.where(np.isfinite(d), d, 0.0)
        N = np.einsum("km,kp,kn->pmn", A_, w, A_)                         # A' W A per pixel
        b = np.einsum("km,kp->pm", A_, w * d)                              # A' W d
        used = np.abs(A_).T @ (w > 0)                                      # pairs touching each date, (m, P)
        good = np.all(used > 0, axis=0)
        N[~good] = np.eye(m)
        N = N + 1e-12 * np.eye(m)
        x = np.linalg.solve(N, b[..., None])[..., 0]                      # (P, m)
        c_sol = np.linalg.solve(N, np.broadcast_to(cvec, (N.shape[0], m))[..., None])[..., 0]
        var_v = np.einsum("pm,m->p", c_sol, cvec)
        r = d - np.einsum("km,pm->kp", A_, x)
        nvalid = (w > 0).sum(0)
        dof = nvalid - m
        wr = np.where(dof > 0, np.sqrt((w * r * r).sum(0) / np.maximum(w.sum(0), 1e-30)), np.nan)
        x[~good] = np.nan
        u[1:, s0:s0 + chunk] = x.T
        u[0, s0:s0 + chunk] = np.where(good, 0.0, np.nan)
        sv[s0:s0 + chunk] = np.where(good, np.sqrt(np.maximum(var_v, 0)), np.nan)
        mis[s0:s0 + chunk] = np.where(good, wr, np.nan)
    ubar = np.nansum(u * tc[:, None], 0) / sxx
    vel = np.where(np.isfinite(u).all(0), ubar * 10.0 * 365.25, np.nan)   # cm/day -> mm/yr; never 0 for "unknown"
    return dict(u=u.reshape(n_dates, H, Wd), vel=vel.reshape(H, Wd), sigma_v=(sv * 10.0 * 365.25).reshape(H, Wd), misfit=mis.reshape(H, Wd))


def _network_velocity(stack, ctx, out, rr, cc, D, coh, gm, cr, geo, dates):
    """returns True if the network method was used"""
    pairs_ = [s.get("pair") for s in stack]
    if not all(pairs_) or ctx.p("network", 1) == 0:
        return False
    day = lambda d: d.replace(hour=0, minute=0, second=0, microsecond=0)
    stamps = sorted({day(x) for pr in pairs_ for x in pr[:2]})
    idx = {d: i for i, d in enumerate(stamps)}
    early = [idx[day(min(pr[0], pr[1]))] for pr in pairs_]
    late = [idx[day(max(pr[0], pr[1]))] for pr in pairs_]
    n = len(stamps)
    # keep the connected group that contains the first date; an unconnected pair cannot be tied to it
    comp = {0}
    changed = True
    while changed:
        changed = False
        for e, l in zip(early, late):
            if (e in comp) != (l in comp):
                comp |= {e, l}; changed = True
    keep = [k for k, (e, l) in enumerate(zip(early, late)) if e in comp and l in comp]
    if len(comp) < 3 or len(keep) < len(comp) - 1:
        return False
    if len(keep) < len(early):
        out["notes"].append(f"{len(early) - len(keep)} pair(s) are not connected to the first date and were left out.")
    remap = {old: new for new, old in enumerate(sorted(comp))}
    stamps = [stamps[i] for i in sorted(comp)]
    e2 = [remap[early[k]] for k in keep]; l2 = [remap[late[k]] for k in keep]
    t = np.array([(d - stamps[0]).total_seconds() / 86400.0 for d in stamps])
    L = ctx.p("looks", 20.0)
    g = np.clip(np.stack([stack[k]["arr"]["coh"] for k in keep]), 0.05, 0.99)
    sig = np.sqrt((1 - g ** 2) / (2 * L * g ** 2)) * A.LAMBDA / (4 * math.pi) * 100.0       # cm, Cramer-Rao
    Dk = D[keep]
    W = np.where(np.isfinite(Dk) & np.isfinite(sig), 1.0 / np.maximum(sig, 1e-6) ** 2, 0.0)
    res = sbas_solve(Dk, W, e2, l2, len(stamps), t)
    cm = ctx.p("coh_min", 0.6)
    keep_px = coh >= cm
    vel = np.where(keep_px, res["vel"], np.nan)
    sv = np.where(keep_px, res["sigma_v"], np.nan)
    mis = np.where(keep_px, res["misfit"], np.nan)
    lo, med, hi = pct(vel, 2, 50, 98)
    where = pairs_[0][2] if len({p[2] for p in pairs_}) == 1 else "file metadata or name"
    M(out, "Pair network", f"{len(keep)} pairs over {len(stamps)} dates ({nf(float(t[-1]), 0)} days)", f"Dates read from the {where}; every pair is used with its own dates and a coherence-based weight")
    M(out, "Reference point", X._where({"gm": gm}, rr, cc), "Most coherent pixel on average; every pair is measured relative to it")
    M(out, "Velocity (line of sight)", f"median {nf(med, 1)} mm/yr (2-98%: {nf(lo, 1)} to {nf(hi, 1)})")
    M(out, "Velocity uncertainty (formal, 1 sigma)", f"median {nf(float(np.nanmedian(sv)), 1)} mm/yr", "From the pair weights only: atmosphere and unwrapping errors are NOT included")
    if len(keep) > len(stamps) - 1:
        M(out, "Network misfit (median)", f"{nf(float(np.nanmedian(mis)), 2)} cm", "Pairs that disagree with each other (unwrapping errors, atmosphere). Check the misfit map")
    M(out, "Pixels kept", f"{nf(100 * np.isfinite(vel).sum() / vel.size, 1)} % (mean coherence of at least {cm:g})")
    _series(out, "Cumulative change", t, {"median of the window (cm)": np.nanmedian(res["u"], (1, 2))}, "days since the first date", "cm", [d.strftime("%Y-%m-%d") for d in stamps])
    lim = max(abs(lo), abs(hi), 1e-6)
    IMG(out, "Line-of-sight velocity (mm/yr)", render.colormap_png(vel, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "mm/yr"}, raw=vel, gm=gm)
    u_hi = A.pct(sv, 98)[0] or 1e-6
    IMG(out, "Velocity uncertainty (mm/yr)", render.colormap_png(sv, 0, u_hi, "viridis"), cr, True, {"min": 0, "max": u_hi, "unit": "mm/yr"}, raw=sv, gm=gm)
    if len(keep) > len(stamps) - 1:
        m_hi = A.pct(mis, 98)[0] or 1e-6
        IMG(out, "Network misfit (cm)", render.colormap_png(mis, 0, m_hi, "viridis"), cr, True, {"min": 0, "max": m_hi, "unit": "cm"}, raw=mis, gm=gm)
    out["notes"].append("Network velocity: all pairs are inverted together (least squares), so one bad pair does not carry into later dates as it does in a chain. Troposphere and ionosphere are not removed unless you apply them: seasonal atmosphere can look like slow motion. Signs follow the product's phase convention.")
    return True


def velocity(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    if len(stack) < 3:
        raise Unsupported("Velocity needs at least 3 pairs.")
    D = np.stack([s["arr"]["disp"] for s in stack])
    coh = np.nanmean(np.stack([s["arr"]["coh"] for s in stack]), 0)
    score = np.where(np.isfinite(coh), coh, -1)
    rr, cc = np.unravel_index(np.argmax(score), score.shape)
    ref = np.nanmedian(D[:, max(0, rr - 2):rr + 3, max(0, cc - 2):cc + 3], axis=(1, 2))
    D = D - ref[:, None, None]
    if _network_velocity(stack, ctx, out, rr, cc, D, coh, gm, cr, True, dates):
        return
    C = np.nancumsum(D, 0)
    step = ctx.baseline_days
    dd = np.asarray(days, float)
    real = len(dd) == len(stack) and bool(np.all(np.diff(dd) > 0))
    t = (dd - dd[0] + step) if real else (np.arange(len(stack)) + 1) * step   # end of each pair, from the REAL dates
    irregular = real and bool(np.any(np.abs(np.diff(dd) - step) > 2))
    tc = t - t.mean()
    Cm = C - np.nanmean(C, 0)
    slope = np.nansum(tc[:, None, None] * Cm, 0) / np.sum(tc ** 2)  # cm per day
    vel = slope * 10 * 365.25  # mm per year
    vel = np.where(coh >= ctx.p("coh_min", 0.6), vel, np.nan)
    lo, med, hi = pct(vel, 2, 50, 98)
    M(out, "Reference point", X._where({"gm": gm}, rr, cc), "Most coherent pixel on average; every pair is measured relative to it")
    M(out, "Velocity (line of sight)", f"median {nf(med, 1)} mm/yr (2-98%: {nf(lo, 1)} to {nf(hi, 1)})")
    M(out, "Pixels kept", f"{nf(100 * np.isfinite(vel).sum() / vel.size, 1)} % (mean coherence of at least {ctx.p('coh_min', 0.6):g})")
    _series(out, "Cumulative change", t, {"median of the window (cm)": np.nanmedian(C, (1, 2))}, "days (chained pairs)", "cm", dates)
    lim = max(abs(lo), abs(hi), 1e-6)
    IMG(out, "Line-of-sight velocity (mm/yr)", render.colormap_png(vel, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "mm/yr"}, raw=vel, gm=gm)
    if irregular:
        out["notes"].append(f"The dates are not {step:g} days apart (gaps: {', '.join(f'{g:g}' for g in np.diff(dd))} days). Chaining pairs assumes each pair starts where the last one ended, so a gap or overlap adds error: use a continuous series of pairs.")
    out["notes"].append(f"Pairs are chained as consecutive {step:g}-day steps, so errors add up and a short record gives an uncertain slope. Set the days between pairs if different. Signs follow the product's phase convention.")


def speed_series(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    p50, p95, nz = [], [], []
    to_speed = 365.25 / ctx.baseline_days
    rs = A.noise_hf
    for s in stack:
        a, r = s["arr"]["a"], s["arr"]["r"]
        mag = np.hypot(a - np.nanmedian(a), r - np.nanmedian(r)) * to_speed
        v = mag[np.isfinite(mag)]
        if not v.size:
            continue
        p50.append(float(np.median(v)))
        p95.append(float(np.percentile(v, 95)))
        # the 95th percentile of the 2-D noise alone (Rayleigh) is sqrt(2 ln 20) = 2.45 sigma
        nz.append(math.sqrt(2 * math.log(20)) * math.sqrt((rs(a) ** 2 + rs(r) ** 2) / 2) * to_speed)
    if not p50:
        raise A.Unsupported("No valid offsets in this window.")
    _series(out, "Speed", days[:len(p50)], {"median (m/yr)": np.array(p50), "95th percentile (m/yr)": np.array(p95)}, "days since the first date", "m/yr", dates[:len(p50)])
    noise = float(np.mean(nz))
    M(out, "Median speed", f"{nf(float(np.mean(p50)), 0)} m/yr on average (range {nf(min(p50), 0)} to {nf(max(p50), 0)})")
    if float(np.mean(p95)) <= 1.2 * noise:
        M(out, "95th percentile speed", f"not significant (below the noise floor of about {nf(noise, 0)} m/yr)", "The offsets show no motion clearly above the noise")
    else:
        M(out, "95th percentile speed", f"{nf(float(np.mean(p95)), 0)} m/yr on average (range {nf(min(p95), 0)} to {nf(max(p95), 0)})", f"Noise floor about {nf(noise, 0)} m/yr")
    if len(p95) > 1:
        k = int(np.argmax(np.abs(np.diff(p95))))
        M(out, "Largest speed change", f"{nf(p95[k + 1] - p95[k], 0)} m/yr between {dates[k]} and {dates[k + 1]}")
    out["notes"].append(f"Speed per file = relative offset over {ctx.baseline_days:g} days. Speeds near or below the noise floor are noise. Motion is measured relative to the window median: if more than half of the window moves, the speed is underestimated.")


def sme_anomaly(stack, days, dates, ctx, out, geo):
    win, cr, gm, sp = geo
    A.set_window(out, win, cr, True, sp)
    cube = np.stack([s["arr"]["sm"] for s in stack])
    # The latest date must NOT be part of its own reference: with it included, a z-score can never exceed
    # sqrt(n - 1) (1.4 for 3 dates), so even an extreme event would look ordinary.
    ref, latest = cube[:-1], cube[-1]
    mu, sd = np.nanmean(ref, 0), np.nanstd(ref, 0, ddof=1)
    scale = 100.0 if np.nanmax(cube) > 1.5 else 1.0          # percent or fraction
    z = (latest - mu) / np.maximum(sd, 0.005 * scale)         # floor: ignore differences below 0.005 m3/m3
    v = np.isfinite(z)
    _series(out, "Soil moisture", days, {"median": np.array([float(np.nanmedian(c)) for c in cube])}, "days since the first date", "soil moisture", dates)
    M(out, "Latest date", dates[-1])
    M(out, "Reference dates", f"{len(ref)} (all dates before the latest)")
    M(out, "Drier than usual (z below -1)", f"{nf(A.share(z < -1, v), 1)} %")
    M(out, "Wetter than usual (z above +1)", f"{nf(A.share(z > 1, v), 1)} %")
    IMG(out, "Soil-moisture anomaly of the latest date (z-score)", render.colormap_png(z, -3, 3, "earth"), cr, True, {"min": -3, "max": 3, "unit": "sigma"}, raw=z, gm=gm)
    out["notes"].append(f"The reference is only the {len(ref)} earlier date(s) you selected, so the spread is rough" + (" (use at least 5 dates for a fairer z-score)." if len(ref) < 4 else ".") + " A few months is too short for a true climatology.")


import extras as X  # noqa: E402  (X._where used above)

MODES = {
    "gcov_ts": ("Backscatter time series for a place", "GCOV", rd_gcov, gcov_ts, 3),
    "first_change": ("Date of first change", "GCOV", rd_gcov, first_change, 5),
    "temporal_avg": ("Temporal average and variability", "GCOV", rd_gcov, temporal_avg, 3),
    "coh_series": ("Coherence over time", "GUNW", rd_unw, coh_series, 3),
    "velocity": ("Ground-motion velocity (mm/yr)", "GUNW", rd_unw, velocity, 3),
    "speed_series": ("Glacier or ground speed series", "GOFF", rd_off, speed_series, 3),
    "sme_anomaly": ("Soil-moisture anomaly", "SME2", rd_sme, sme_anomaly, 3),
}
CATALOG = [{"key": k, "title": t, "product": p, "min_files": n} for k, (t, p, _, _, n) in MODES.items()]


def run(opens, times, ctx, mode):
    if mode not in MODES:
        raise Unsupported("Unknown series analysis.")
    title, prod, reader, fn, nmin = MODES[mode]
    if len(opens) < nmin:
        raise Unsupported(f"{title} needs at least {nmin} files (you selected {len(opens)}).")
    if len(opens) > 24:
        raise Unsupported("At most 24 files per series.")
    order = sorted(range(len(opens)), key=lambda i: times[i])
    opens, times = [opens[i] for i in order], [times[i] for i in order]
    stack, win, cr, gm, sp = load_stack(opens, prod, reader, ctx)
    ts = [_t(t) for t in times]
    days = [(t - ts[0]).total_seconds() / 86400 for t in ts]
    dates = [t.strftime("%Y-%m-%d") for t in ts]
    out = {"product": title, "identification": {}, "metrics": [], "images": [], "notes": [], "window": None, "mode": mode}
    fn(stack, days, dates, ctx, out, (win, cr, gm, sp))
    return out
