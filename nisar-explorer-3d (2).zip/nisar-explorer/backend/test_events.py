"""Tests for the events service. Feed payloads are small samples in the documented shapes; no network."""
import pytest
from fastapi.testclient import TestClient

import events
from main import app

client = TestClient(app)

USGS = {"features": [
    {"id": "us7000test", "properties": {"mag": 6.8, "place": "20 km S of Somewhere", "time": 1788000000000, "title": "M 6.8 - 20 km S of Somewhere", "alert": "orange", "url": "https://earthquake.usgs.gov/x"},
     "geometry": {"coordinates": [-8.4, 31.1, 18.0]}},
    {"id": "bad1", "properties": {"mag": None, "time": 1788000000000}, "geometry": {"coordinates": [0, 0, 1]}},
    {"id": "bad2", "properties": {"mag": 5.1, "time": 1788000000000}, "geometry": {}},
]}
GDACS = {"features": [
    {"bbox": [90.2, 23.5, 91.4, 24.6], "geometry": {"type": "Point", "coordinates": [90.8, 24.0]},
     "properties": {"eventtype": "FL", "eventid": 1102, "name": "Flood in Bangladesh", "country": "Bangladesh", "fromdate": "2026-08-20T00:00:00", "todate": "2026-08-30T00:00:00", "alertlevel": "Orange", "severitydata": {"severitytext": "Magnitude 5"}, "url": {"report": "https://gdacs.org/r"}}},
    {"geometry": {"type": "Point", "coordinates": [10.0, 40.0]}, "properties": {"eventtype": "EQ", "eventid": 5, "fromdate": "2026-08-20T00:00:00"}},
    {"geometry": {"type": "Point", "coordinates": [-6.0, 34.0]}, "properties": {"eventtype": "FL", "eventid": 1103, "name": "Flood point only", "fromdate": "2026-09-02"}},
]}
EONET = {"events": [
    {"id": "EONET_1", "title": "Flood, Bangladesh", "link": "https://eonet/1", "categories": [{"id": "floods"}],
     "geometry": [{"date": "2026-08-21T00:00:00Z", "type": "Point", "coordinates": [90.7, 24.1]}]},
    {"id": "EONET_2", "title": "Wildfire", "categories": [{"id": "wildfires"}], "geometry": [{"date": "2026-08-21T00:00:00Z", "type": "Point", "coordinates": [1, 1]}]},
]}


def test_parse_usgs():
    ev = events.parse_usgs(USGS)
    assert len(ev) == 1
    e = ev[0]
    assert e["type"] == "earthquake" and e["magnitude"] == 6.8 and e["severity"] == "orange"
    assert e["time"].endswith("Z") and e["lat"] == 31.1 and e["lon"] == -8.4
    w, s, ee, n = e["bbox"]
    assert w < -8.4 < ee and s < 31.1 < n


def test_quake_bbox_grows_with_magnitude():
    small, big = events.quake_bbox(0, 0, 5.0), events.quake_bbox(0, 0, 7.5)
    assert (big[2] - big[0]) > (small[2] - small[0])
    assert events.quake_bbox(179.9, 89.9, 8)[2] <= 180 and events.quake_bbox(179.9, 89.9, 8)[3] <= 90


def test_parse_gdacs_keeps_floods_only_and_pads_points():
    ev = events.parse_gdacs(GDACS)
    assert [e["id"] for e in ev] == ["gdacs:FL1102", "gdacs:FL1103"]
    assert ev[0]["bbox"] == [90.2, 23.5, 91.4, 24.6] and ev[0]["severity"] == "orange" and ev[0]["end"] == "2026-08-30T00:00:00Z"
    w, s, e, n = ev[1]["bbox"]
    assert e - w > 0.4 and n - s > 0.4 and ev[1]["time"] == "2026-09-02T00:00:00Z"


def test_parse_eonet_floods_only():
    ev = events.parse_eonet(EONET)
    assert len(ev) == 1 and ev[0]["type"] == "flood" and ev[0]["source"] == "NASA EONET"


def test_dedupe_prefers_gdacs():
    both = events.parse_eonet(EONET) + events.parse_gdacs(GDACS)
    out = events.dedupe(both)
    bd = [e for e in out if e["lon"] > 80]
    assert len(bd) == 1 and bd[0]["source"] == "GDACS"


def test_endpoint_merges_and_reports_a_failing_feed(monkeypatch):
    def fake_get(url, params):
        if url == events.USGS_URL:
            return {"features": [{"id": "u", "properties": {"mag": 6.0, "time": 1788000000000, "title": "M 6"}, "geometry": {"coordinates": [1, 2, 3]}}]}
        if url == events.GDACS_URL:
            raise RuntimeError("down")
        return EONET
    monkeypatch.setattr(events, "_get", fake_get)
    d = client.get("/api/events", params={"start": "2026-08-01", "end": "2026-09-30"}).json()
    assert any("GDACS" in w for w in d["warnings"])
    assert {e["type"] for e in d["events"]} <= {"earthquake", "flood"}
    assert d["sources"] == ["USGS", "NASA EONET"]
    assert [e["time"] for e in d["events"]] == sorted((e["time"] for e in d["events"]), reverse=True)


def test_endpoint_validation():
    assert client.get("/api/events", params={"start": "08/01/2026"}).status_code == 400
    assert client.get("/api/events", params={"start": "2026-09-01", "end": "2026-08-01"}).status_code == 400


def test_type_filter(monkeypatch):
    calls = []
    monkeypatch.setattr(events, "_get", lambda url, params: calls.append(url) or {"features": []})
    client.get("/api/events", params={"types": "earthquake", "start": "2026-08-01", "end": "2026-08-05"})
    assert calls == [events.USGS_URL]
