"""Synthetic NISAR-like HDF5 files (same group layout as real products) for the demo mode and for tests."""
import uuid

import h5py
import numpy as np

EPSG = 32629  # UTM 29N, near Casablanca
N = 500


def _rng(t=None):
    return np.random.default_rng(7 if t is None else 100 + t)


def _fields(t=None):
    rng = _rng(t)
    yy, xx = np.mgrid[0:N, 0:N].astype(float)
    smooth = lambda k: sum(np.sin(xx / (30 + 11 * i) + i) * np.cos(yy / (40 + 9 * i) - i) for i in range(k)) / k
    water = ((xx - 150) ** 2 + (yy - 330) ** 2) < 70 ** 2
    urban = (xx > 330) & (xx < 420) & (yy > 80) & (yy < 160)
    return rng, xx, yy, smooth, water, urban


def _grid(f, path, dx=20.0, n=N):
    g = f.require_group(path)
    g.create_dataset("xCoordinates", data=625000.0 + dx * (np.arange(n) + 0.5))
    g.create_dataset("yCoordinates", data=3725000.0 - dx * (np.arange(n) + 0.5))
    p = g.create_dataset("projection", data=np.uint32(EPSG))
    p.attrs["epsg_code"] = EPSG
    return g


def _ident(f, prod, direction="Ascending"):
    g = f.require_group("science/LSAR/identification")
    g.create_dataset("productType", data=prod)
    g.create_dataset("trackNumber", data=np.uint32(82))
    g.create_dataset("frameNumber", data=np.uint32(101))
    g.create_dataset("orbitPassDirection", data=direction)
    g.create_dataset("lookDirection", data="Right")
    g.create_dataset("zeroDopplerStartTime", data="2026-10-20T18:05:11")


def _cx(a):
    c = np.zeros(a.shape, dtype=[("r", "f4"), ("i", "f4")])
    c["r"], c["i"] = a.real, a.imag
    return c


def make_demo(level="GCOV", t=None, direction="Ascending"):
    level = "RRSD" if level == "L0B" else level
    f = h5py.File(f"demo-{uuid.uuid4().hex}.h5", "w", driver="core", backing_store=False)
    rng, xx, yy, smooth, water, urban = _fields(t)
    _ident(f, level, direction)
    tt = -1 if t is None else t
    base = f"science/LSAR/{level}"
    speckle = lambda L=4: rng.gamma(L, 1 / L, (N, N))

    if level == "GCOV":
        g = _grid(f, base + "/grids/frequencyA")
        hh = 0.06 * np.exp(0.5 * smooth(3)) * speckle()
        hv = 0.012 * np.exp(0.5 * smooth(3)) * speckle()
        hh[water], hv[water] = 0.003 * speckle()[water], 0.0006 * speckle()[water]
        hh[urban], hv[urban] = 0.5 * speckle()[urban], 0.05 * speckle()[urban]
        if t is not None:
            defor = (xx > 40) & (xx < 140) & (yy > 40) & (yy < 140)
            flood = (xx > 250) & (xx < 380) & (yy > 380) & (yy < 470)
            if tt >= 4:
                hv[defor] *= 10 ** -0.35
            if tt >= 5:
                hh[flood], hv[flood] = 0.003 * speckle()[flood], 0.0006 * speckle()[flood]
        g.create_dataset("HHHH", data=hh.astype("f4"), chunks=(128, 128), compression="gzip")
        g.create_dataset("HVHV", data=hv.astype("f4"), chunks=(128, 128), compression="gzip")
        # quad-pol extras so the decomposition can be tested
        vv = 0.05 * np.exp(0.5 * smooth(3)) * speckle()
        vv[water], vv[urban] = 0.003 * speckle()[water], 0.45 * speckle()[urban]
        hhvv = np.sqrt(hh * vv) * 0.4 * np.exp(1j * rng.normal(0, 0.5, (N, N)))
        hhvv[urban] *= -1  # double-bounce-like
        g.create_dataset("VVVV", data=vv.astype("f4"), chunks=(128, 128), compression="gzip")
        g.create_dataset("HHVV", data=_cx(hhvv))
        mk = np.ones((N, N), "u1")
        mk[:20, :] = 2
        g.create_dataset("mask", data=mk)
        g.create_dataset("numberOfLooks", data=(25 * np.ones((N, N))).astype("f4"))
        g.create_dataset("rtcGammaToSigmaFactor", data=(0.78 + 0.02 * smooth(2)).astype("f4"))
    elif level in ("GUNW", "RUNW"):
        geo = level == "GUNW"
        g = f.require_group(base + ("/grids" if geo else "/swaths") + "/frequencyA/" + ("unwrappedInterferogram/HH" if geo else "interferogram/HH"))
        if geo:
            _grid(f, base + "/grids/frequencyA/unwrappedInterferogram", 80.0 * 0 + 20.0)
        bowl = np.exp(-(((xx - 250) ** 2 + (yy - 250) ** 2) / (2 * 70 ** 2)))
        amp = 0.03 if t is None else 0.01
        d = amp * (0.6 if str(direction).lower().startswith("d") else 1.0) * bowl  # line-of-sight motion (m)
        phase = 4 * np.pi / 0.2384 * d + 0.15 * rng.standard_normal((N, N)) + 0.002 * xx
        coh = np.clip(0.85 - 0.5 * water + 0.05 * rng.standard_normal((N, N)), 0, 1)
        if t is not None and tt >= 4:
            coh[(xx > 380) & (yy < 100)] *= 0.3
        g.create_dataset("unwrappedPhase", data=phase.astype("f4"), chunks=(128, 128), compression="gzip")
        g.create_dataset("coherenceMagnitude", data=coh.astype("f4"))
        g.create_dataset("connectedComponents", data=np.ones((N, N), "u4"))
        g.create_dataset("ionospherePhaseScreen", data=(0.002 * xx + 0.0015 * yy).astype("f4"))
    elif level in ("GOFF", "ROFF"):
        geo = level == "GOFF"
        g = f.require_group(base + ("/grids/frequencyA/pixelOffsets/HH" if geo else "/swaths/frequencyA/pixelOffsets/HH/layer1"))
        if geo:
            _grid(f, base + "/grids/frequencyA/pixelOffsets")
        flow = np.where((xx > 100) & (xx < 300), 2.5 * (1 if t is None else (tt + 1) / 4) * np.exp(-((yy - 250) ** 2) / (2 * 60 ** 2)), 0.0)
        g.create_dataset("alongTrackOffset", data=(0.3 + flow + 0.3 * rng.standard_normal((N, N))).astype("f4"))
        g.create_dataset("slantRangeOffset", data=(-0.2 + 0.4 * flow + 0.3 * rng.standard_normal((N, N))).astype("f4"))
        g.create_dataset("correlationSurfacePeak", data=np.clip(0.7 + 0.1 * rng.standard_normal((N, N)), 0, 1).astype("f4"))
        g.create_dataset("snr", data=(10 + 3 * rng.standard_normal((N, N))).astype("f4"))
    elif level in ("GSLC", "RSLC"):
        geo = level == "GSLC"
        g = _grid(f, base + "/grids/frequencyA") if geo else f.require_group(base + "/swaths/frequencyA")
        amp = np.sqrt(0.06 * np.exp(0.5 * smooth(3)) * speckle(1))
        amp[water] *= 0.2
        ph0 = np.random.default_rng(11).uniform(-np.pi, np.pi, (N, N))
        bowl = np.exp(-(((xx - 250) ** 2 + (yy - 250) ** 2) / (2 * 70 ** 2)))
        defo = 0.0 if t is None else 4 * np.pi / 0.2384 * 0.01 * (tt + 1) * bowl
        g.create_dataset("HH", data=_cx(amp * np.exp(1j * (ph0 + defo + (0 if t is None else 0.2 * rng.standard_normal((N, N)))))))
    elif level == "SME2":
        g = _grid(f, base + "/grids/frequencyA", 200.0, N // 10)  # 50 x 50 cells of 200 m = same 10 km area
        sm = np.clip(0.2 + 0.02 * max(tt, 0) + 0.1 * smooth(3) + 0.02 * rng.standard_normal((N, N)), 0.02, 0.5)
        g.create_dataset("soilMoisture", data=sm[::10, ::10].astype("f4"))
        g.create_dataset("soilMoistureUncertainty", data=(0.03 * np.ones((N // 10, N // 10))).astype("f4"))
        g.create_dataset("vegetationWaterContent", data=np.clip(1.5 + smooth(2), 0, 5)[::10, ::10].astype("f4"))
        g.create_dataset("cropType", data=(1 + (xx > 250).astype("u1") + 2 * (yy > 300).astype("u1"))[::10, ::10].astype("u1"))
    elif level == "RIFG":
        g = f.require_group(base + "/swaths/frequencyA/interferogram/HH")
        ph = 4 * np.pi / 0.2384 * 0.03 * np.exp(-(((xx - 250) ** 2 + (yy - 250) ** 2) / (2 * 70 ** 2)))
        g.create_dataset("wrappedInterferogram", data=_cx(np.exp(1j * (ph + 0.3 * rng.standard_normal((N, N))))))
        g.create_dataset("coherenceMagnitude", data=np.clip(0.8 + 0.1 * rng.standard_normal((N, N)), 0, 1).astype("f4"))
    elif level == "RRSD":
        g = f.require_group(base + "/swaths/frequencyA")
        g.create_dataset("HH", data=_cx(rng.standard_normal((300, 1200)) + 1j * rng.standard_normal((300, 1200))))
    else:
        f.close()
        raise ValueError(level)
    return f
