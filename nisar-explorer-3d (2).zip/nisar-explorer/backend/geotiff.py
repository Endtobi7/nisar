"""Minimal georeferenced GeoTIFF (float32, projected CRS) so results open in QGIS, ArcGIS or rasterio."""
import io

import numpy as np
import tifffile


def write_geotiff(arr, gm):
    a = np.asarray(arr, "float32")
    tags = [
        (33550, "d", 3, (float(gm["dx"]), float(gm["dy"]), 0.0), True),                      # ModelPixelScale
        (33922, "d", 6, (0.0, 0.0, 0.0, float(gm["left"]), float(gm["top"]), 0.0), True),    # ModelTiepoint
        (34735, "H", 16, (1, 1, 0, 3, 1024, 0, 1, 1, 1025, 0, 1, 1, 3072, 0, 1, int(gm["epsg"])), True),  # GeoKeyDirectory
        (42113, "s", 0, "nan", True),                                                        # GDAL_NODATA
    ]
    buf = io.BytesIO()
    tifffile.imwrite(buf, a, photometric="minisblack", compression="deflate", extratags=tags)
    return buf.getvalue()
