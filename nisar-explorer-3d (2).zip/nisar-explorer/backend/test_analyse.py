"""Run every analyser on synthetic NISAR-style files, then read one through RangeFile over HTTP."""
import base64, http.server, io, os, socketserver, tempfile, threading

import h5py
import numpy as np
from PIL import Image

import analyse
from analyse import Ctx
from demo_data import make_demo
from rangefile import RangeFile

for lvl in analyse.KNOWN:
    f = make_demo(lvl)
    if lvl == "RRSD":
        try:
            analyse.run(f, Ctx(), lvl); raise SystemExit("RRSD should have nothing to analyse")
        except analyse.Unsupported as e:
            print("RRSD  ->", str(e)[:70]); f.close(); continue
    out = analyse.run(f, Ctx(want=("all",)), lvl)
    assert "_raw" not in out or isinstance(out["_raw"], dict)
    hist_n = sum(1 for im in out["images"] if im.get("hist"))
    n_geo = sum(i["georeferenced"] for i in out["images"])
    for im in out["images"]:
        img = Image.open(io.BytesIO(base64.b64decode(im["png"].split(",", 1)[1])))
        assert img.mode == "RGBA" and img.width > 10
    print(f"{lvl:5} metrics={len(out['metrics']):2} images={len(out['images'])} georef={n_geo} hist={hist_n} series={len(out.get('series', []))} notes={len(out['notes'])}")
    for n_ in out["notes"]:
        if "could not run" in n_: print("      !!", n_)
    if lvl in ("GCOV", "GUNW", "GOFF"):
        for m in out["metrics"][:4]:
            print("      ", m["label"], "->", m["value"])
        if out["images"] and out["images"][0]["corners"]:
            print("       corners", [[round(c, 4) for c in p] for p in out["images"][0]["corners"]])
    f.close()

# bbox window + decimation
f = make_demo("GCOV")
out = analyse.run(f, Ctx(bbox=(-7.60, 33.60, -7.55, 33.64)), "GCOV")
print("bbox window", out["window"])
try:
    analyse.run(f, Ctx(bbox=(10, 10, 11, 11)), "GCOV")
except ValueError as e:
    print("outside ->", e)
out = analyse.run(f, Ctx(max_px=100, default_px=500), "GCOV"); print("decimated", out["window"])
f.close()

# remote-style read: write a real file, serve it with HTTP Range support, open through RangeFile
d = tempfile.mkdtemp()
src = make_demo("GCOV")
with h5py.File(os.path.join(d, "g.h5"), "w") as dst:
    for k in src:
        src.copy(k, dst)
src.close()

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=d, **k)
    def log_message(self, *a): pass
    def do_GET(self):
        p = os.path.join(d, self.path.lstrip("/")); size = os.path.getsize(p)
        rng = self.headers.get("Range")
        if not rng: return super().do_GET()
        a, b = rng.replace("bytes=", "").split("-"); a, b = int(a), min(int(b), size - 1)
        with open(p, "rb") as fh: fh.seek(a); data = fh.read(b - a + 1)
        self.send_response(206); self.send_header("Content-Range", f"bytes {a}-{b}/{size}")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

srv = socketserver.TCPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
import requests
rf = RangeFile(requests.Session(), f"http://127.0.0.1:{port}/g.h5")
with h5py.File(rf, "r") as hf:
    out = analyse.run(hf, Ctx(), "GCOV")
total = os.path.getsize(os.path.join(d, "g.h5"))
print(f"remote read: {len(out['metrics'])} metrics, {rf.requests_made} range requests, file {total/1e6:.1f} MB, cached {sum(len(v) for v in rf.cache.values())/1e6:.1f} MB")
srv.shutdown()
print("ALL OK")
