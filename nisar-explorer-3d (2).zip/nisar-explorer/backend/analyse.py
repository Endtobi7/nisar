"""Per-product analysis of a (remote) NISAR HDF5 file. Layers are found by name, so small layout
differences between product versions do not break it. Only a small window of each layer is read."""
import math
from dataclasses import dataclass
from typing import Optional

import numpy as np
from pyproj import Transformer

import render

KNOWN = ["GCOV", "GUNW", "GOFF", "GSLC", "SME2", "RSLC", "RIFG", "RUNW", "ROFF", "RRSD"]
LAMBDA = 0.2384  # L-band wavelength in metres
ID_KEYS = ["productType", "trackNumber", "frameNumber", "absoluteOrbitNumber", "orbitPassDirection",
           "lookDirection", "zeroDopplerStartTime", "zeroDopplerEndTime", "processingType", "isUrgentObservation"]


class Unsupported(Exception):
    pass


@dataclass
class Ctx:
    bbox: Optional[tuple] = None  # lon/lat window (w, s, e, n)
    max_px: int = 1200            # never read more than this many pixels per side
    default_px: int = 600         # window size when no area is given (centre of the granule)
    baseline_days: float = 12.0   # time between the two acquisitions (offset/interferogram products)
    want: tuple = ()              # optional extra analyses to run (keys from extras.CATALOG)
    params: dict = None           # thresholds for the extras (deform_cm, coh_min, dry, wet, looks, line, ...)

    def p(self, key, default):
        try:
            return type(default)((self.params or {}).get(key, default))
        except (TypeError, ValueError):
            return default


# ---------- helpers ----------
def build_index(pg):
    idx = {}

    def visit(name, obj):
        if hasattr(obj, "shape") and len(obj.shape) >= 2 and "/metadata/" not in "/" + name:
            idx[pg.name.rstrip("/") + "/" + name] = obj

    pg.visititems(visit)
    return idx


def pick(idx, name, contains=None, prefer=()):
    c = [p for p in idx if p.rsplit("/", 1)[-1] == name and (not contains or contains in p)]
    c.sort(key=lambda p: (tuple(-(t in p) for t in prefer), len(p), p))
    return c[0] if c else None


def sibling(path, name, idx):
    p = path.rsplit("/", 1)[0] + "/" + name
    return p if p in idx else None


def to_cx(a):
    if a.dtype.names and {"r", "i"} <= set(a.dtype.names):
        return (a["r"].astype(np.float32) + 1j * a["i"].astype(np.float32)).astype(np.complex64)
    return a


def fill_of(ds):
    try:
        return float(np.asarray(ds.attrs.get("_FillValue")).ravel()[0])
    except Exception:
        return None


# GCOV mask layer (NISAR L2 GCOV product specification, section 4.3.3): 0 = invalid or partially focused,
# 1 to 5 = valid (the number of the sub-swath the samples came from), 255 = fill (outside the image).
# It is NOT a layover/shadow mask. Covariance terms are masked as they are read, so every analysis uses valid pixels only.
APPLY_MASK = True
COV_DIAGONAL = ("HHHH", "HVHV", "VHVH", "VVVV", "RHRH", "RVRV")


def gcov_valid(f, path, win):
    """boolean array of valid pixels for a GCOV covariance layer, or None if there is no mask layer"""
    if path.rsplit("/", 1)[-1] not in COV_DIAGONAL:
        return None
    mp = path.rsplit("/", 1)[0] + "/mask"
    if mp not in f:
        return None
    y0, y1, x0, x1, step = win
    mk = f[mp][y0:y1:step, x0:x1:step]
    return (mk >= 1) & (mk <= 5)


def read(f, path, win):
    ds = f[path]
    y0, y1, x0, x1, step = win
    a = to_cx(ds[y0:y1:step, x0:x1:step])
    fv = fill_of(ds)
    if fv is not None and np.isrealobj(a) and a.dtype.kind == "f":
        a = np.where(a == fv, np.nan, a)
    if APPLY_MASK:
        ok = gcov_valid(f, path, win)
        if ok is not None and ok.shape == a.shape:
            a = np.where(ok, a, np.nan)
    return a


class Geo:
    def __init__(self, f, ds_path):
        parts = ds_path.strip("/").split("/")[:-1]
        self.x = self.y = self.epsg = None
        for k in range(len(parts), 0, -1):  # nearest parent group first
            g = f["/" + "/".join(parts[:k])]
            if self.x is None and "xCoordinates" in g and "yCoordinates" in g:
                self.x, self.y = g["xCoordinates"][:], g["yCoordinates"][:]
            if self.epsg is None and "projection" in g:
                p = g["projection"]
                try:
                    self.epsg = int(p.attrs.get("epsg_code", p[()]))
                except Exception:
                    pass
        if self.x is None or self.epsg is None:
            raise Unsupported("No map coordinates were found for this layer.")


def geo_window(geo, ctx):
    x, y = geo.x, geo.y
    nx, ny = len(x), len(y)
    if ctx.bbox:
        tr = Transformer.from_crs(4326, geo.epsg, always_xy=True)
        w, s, e, n = ctx.bbox
        xs, ys = tr.transform([w, e, e, w], [s, s, n, n])
        ix = np.where((x >= min(xs)) & (x <= max(xs)))[0]
        iy = np.where((y >= min(ys)) & (y <= max(ys)))[0]
        if not len(ix) or not len(iy):
            raise ValueError("The chosen area is outside this granule.")
        x0, x1, y0, y1 = int(ix.min()), int(ix.max()) + 1, int(iy.min()), int(iy.max()) + 1
    else:
        sz = min(ctx.default_px, nx, ny)
        x0, y0 = (nx - sz) // 2, (ny - sz) // 2
        x1, y1 = x0 + sz, y0 + sz
    step = max(1, math.ceil(max(x1 - x0, y1 - y0) / ctx.max_px))
    return y0, y1, x0, x1, step


def radar_window(shape, ctx):
    ny, nx = shape[:2]
    sy, sx = min(ctx.default_px, ny), min(ctx.default_px, nx)
    y0, x0 = (ny - sy) // 2, (nx - sx) // 2
    return y0, y0 + sy, x0, x0 + sx, max(1, math.ceil(max(sy, sx) / ctx.max_px))


def corners(geo, win):
    y0, y1, x0, x1, _ = win
    x, y = geo.x, geo.y
    dx = abs(x[1] - x[0]) if len(x) > 1 else 0.0
    dy = abs(y[1] - y[0]) if len(y) > 1 else 0.0
    xl, xr = x[x0] - dx / 2, x[x1 - 1] + dx / 2
    yt, yb = y[y0] + dy / 2, y[y1 - 1] - dy / 2
    tr = Transformer.from_crs(geo.epsg, 4326, always_xy=True)
    return [[float(lo), float(la)] for lo, la in (tr.transform(a, b) for a, b in [(xl, yt), (xr, yt), (xr, yb), (xl, yb)])]


def locate(f, path, ctx, idx):
    """-> (window, corners or None, georeferenced?) for the layer at `path`"""
    try:
        geo = Geo(f, path)
        win = geo_window(geo, ctx)
        spacing = abs(float(geo.x[1] - geo.x[0])) * win[4] if len(geo.x) > 1 else None
        y0, y1, x0, x1, step = win
        dx, dy = abs(float(geo.x[1] - geo.x[0])), abs(float(geo.y[1] - geo.y[0]))
        gm = {"epsg": geo.epsg, "left": float(geo.x[x0] - dx / 2), "top": float(geo.y[y0] + dy / 2), "dx": dx * step, "dy": dy * step}
        return win, corners(geo, win), True, spacing, gm
    except Unsupported:
        return radar_window(f[path].shape, ctx), None, False, None, None


def finite(a):
    return a[np.isfinite(a)]


def pct(a, *q):
    v = finite(a)
    return [float(x) for x in np.percentile(v, q)] if v.size else [float("nan")] * len(q)


def nf(x, nd=2):
    return "n/a" if x is None or not np.isfinite(x) else f"{x:.{nd}f}"


def share(mask, valid):
    n = int(np.count_nonzero(valid))
    return 100.0 * np.count_nonzero(mask & valid) / n if n else float("nan")


def noise_hf(x, lag=4):
    """Noise level of a field from differences between pixels `lag` apart. Smooth real motion cancels in the difference,
    so (unlike the spread of the whole field) it is not inflated when a large area moves. The lag skips the correlation
    between neighbouring offset pixels (they come from overlapping windows). White noise sigma gives sigma x sqrt(2)."""
    x = np.asarray(x, float)
    parts = []
    for ax in (0, 1):
        if x.shape[ax] <= lag:
            continue
        d = np.abs(x[lag:, :] - x[:-lag, :]) if ax == 0 else np.abs(x[:, lag:] - x[:, :-lag])
        d = d[np.isfinite(d)]
        if d.size:
            parts.append(1.4826 * float(np.median(d)) / math.sqrt(2.0))
    return float(np.mean(parts)) if parts else float("nan")


def boxcar(a, k=3):
    """k x k mean, same shape as `a` (pixel (r, c) stays pixel (r, c), so map positions are right).
    Missing pixels are skipped, not counted as zero."""
    from scipy import ndimage as ndi
    a = np.asarray(a, float)
    if min(a.shape) < k:
        return a
    ok = np.isfinite(a)
    num = ndi.uniform_filter(np.where(ok, a, 0.0), k, mode="nearest")
    den = ndi.uniform_filter(ok.astype(float), k, mode="nearest")
    return np.where(ok & (den > 0.5), num / np.maximum(den, 1e-12), np.nan)


def M(out, label, value, note=None):
    out["metrics"].append({"label": label, "value": value, "note": note})


def IMG(out, name, png, corners_, geo_, legend, raw=None, gm=None):
    hist = None
    if raw is not None:
        v = finite(np.asarray(raw, float))
        if v.size:
            lo, hi = (legend["min"], legend["max"]) if legend else tuple(np.percentile(v, [1, 99]))
            if hi > lo:
                counts, _ = np.histogram(np.clip(v, lo, hi), bins=40, range=(lo, hi))
                hist = {"min": float(lo), "max": float(hi), "counts": counts.tolist()}
        out.setdefault("_raw", {})[name] = {"a": np.asarray(raw, "f4"), "gm": gm}
    out["images"].append({"name": name, "png": png, "corners": corners_, "georeferenced": bool(geo_), "legend": legend, "hist": hist})


def attach(out, ctx, prod, d):
    import extras
    extras.run(out, ctx, prod, d)


def set_window(out, win, corners_, geo_, spacing):
    y0, y1, x0, x1, step = win
    out["window"] = {"rows": int((y1 - y0 + step - 1) // step), "cols": int((x1 - x0 + step - 1) // step),
                     "pixel_size_m": spacing, "georeferenced": bool(geo_)}


# ---------- analysers ----------
def a_gcov(f, pg, idx, ctx, out):
    pols = {}
    for pol in ("HH", "HV", "VV", "VH"):
        p = pick(idx, pol + pol, prefer=("frequencyA",))
        if p:
            pols[pol] = p
    if not pols:
        raise Unsupported("No diagonal covariance layers (HHHH, HVHV, ...) found.")
    first = next(iter(pols.values()))
    win, cr, geo_, sp, gm = locate(f, first, ctx, idx)
    set_window(out, win, cr, geo_, sp)
    db, lin = {}, {}
    for pol, p in pols.items():
        a = read(f, p, win).astype(np.float64)
        a = np.where(a > 0, a, np.nan)
        lin[pol], db[pol] = a, 10 * np.log10(a)
        lo, med, hi = pct(db[pol], 5, 50, 95)
        M(out, f"{pol} backscatter", f"median {nf(med, 1)} dB (5-95%: {nf(lo, 1)} to {nf(hi, 1)})", "Terrain-corrected gamma-0")
    for co, cross in (("HH", "HV"), ("VV", "VH")):
        if co in db and cross in db:
            d = db[cross] - db[co]
            M(out, f"{cross} minus {co}", f"{nf(pct(d, 50)[0], 1)} dB", "Higher = more volume scattering (vegetation)")
            rvi = 4 * lin[cross] / (lin[co] + lin[cross])
            M(out, "Radar vegetation index (dual-pol)", nf(pct(rvi, 50)[0], 2), "About 0 bare surface, towards 1 dense vegetation")
            break
    ref = "HH" if "HH" in db else "VV" if "VV" in db else next(iter(db))
    valid = np.isfinite(db[ref])
    M(out, "Valid pixels", f"{nf(100 * valid.mean(), 1)} %")
    mk_ok = gcov_valid(f, first, win)
    if mk_ok is not None and APPLY_MASK:
        M(out, "Excluded by the mask layer", f"{nf(100.0 * float((~mk_ok).mean()), 1)} %", "Mask 0 (invalid or partly focused) or 255 (outside the image); already left out of every number below")
    lo, hi = pct(db[ref], 2, 98)
    IMG(out, f"{ref} backscatter (dB)", render.colormap_png(db[ref], lo, hi, "gray"), cr, geo_, {"min": lo, "max": hi, "unit": "dB"}, raw=db[ref], gm=gm)
    if "HH" in db and "HV" in db:
        IMG(out, "False colour (R=HH, G=HV, B=HH-HV)",
            render.rgb_png(db["HH"], db["HV"], db["HH"] - db["HV"], [(-25, 0), (-30, -5), (0, 20)]), cr, geo_, None)
    co = "HH" if "HH" in lin else "VV" if "VV" in lin else None
    if co:   # very dark co-pol pixels: calm open water, but also radar shadow and very smooth surfaces
        sm = boxcar(lin[co], 3)                                  # 3 x 3 mean first: single speckle dips are not water
        smdb = 10 * np.log10(np.where(sm > 0, sm, np.nan))
        okv = np.isfinite(smdb)
        M(out, "Water-like share (below -18 dB)", f"{nf(100.0 * float((smdb[okv] < -18).sum()) / max(int(okv.sum()), 1), 1)} %", f"{co}, 3 x 3 smoothed; also counts radar shadow and smooth surfaces. For a cleaned water map use the automatic water extra")
    attach(out, ctx, "GCOV", dict(f=f, idx=idx, win=win, cr=cr, geo=geo_, gm=gm, sp=sp, db=db, lin=lin, ref=ref))


def a_gslc(f, pg, idx, ctx, out, geocoded_expected=True):
    pol = next((p for p in ("HH", "VV", "HV", "VH") if pick(idx, p, prefer=("frequencyA",))), None)
    if not pol:
        raise Unsupported("No complex polarization layer found.")
    path = pick(idx, pol, prefer=("frequencyA",))
    win, cr, geo_, sp, gm = locate(f, path, ctx, idx)
    set_window(out, win, cr, geo_, sp)
    z = read(f, path, win)
    inten = np.abs(z.astype(np.complex128)) ** 2
    inten = np.where(inten > 0, inten, np.nan)
    ml = boxcar(inten, 3)
    ml = np.where(ml > 0, ml, np.nan)
    d = 10 * np.log10(ml)
    lo, med, hi = pct(d, 5, 50, 95)
    M(out, f"{pol} amplitude (3x3 averaged)", f"median {nf(med, 1)} dB (5-95%: {nf(lo, 1)} to {nf(hi, 1)})")
    M(out, "Valid pixels", f"{nf(100 * np.isfinite(d).mean(), 1)} %")
    a, b = pct(d, 2, 98)
    cr_ = cr if geocoded_expected else None
    IMG(out, f"{pol} amplitude (dB)", render.colormap_png(d, a, b, "gray"), cr_, geo_ and geocoded_expected, {"min": a, "max": b, "unit": "dB"}, raw=d, gm=gm if geocoded_expected else None)
    attach(out, ctx, "GSLC" if geocoded_expected else "RSLC", dict(f=f, idx=idx, win=win, cr=cr_, geo=geo_ and geocoded_expected, gm=gm if geocoded_expected else None, sp=sp, z=z, inten=inten, ml=ml, db=d))
    if not geo_:
        out["notes"].append("Radar-geometry crop from the middle of the frame: shown as a preview only, it cannot be placed on the map.")


def a_rslc(f, pg, idx, ctx, out):
    a_gslc(f, pg, idx, ctx, out, geocoded_expected=False)


def a_sme2(f, pg, idx, ctx, out):
    names = [p for p in idx if "soilmoisture" in p.rsplit("/", 1)[-1].lower() and "uncert" not in p.lower()]
    if not names:
        raise Unsupported("No soil-moisture layer found.")
    names.sort(key=lambda p: (len(p), p))
    win, cr, geo_, sp, gm = locate(f, names[0], ctx, idx)
    set_window(out, win, cr, geo_, sp)
    arrs = {}
    for p in names[:3]:
        a = read(f, p, win).astype(np.float64)
        a = np.where((a >= 0) & np.isfinite(a), a, np.nan)
        arrs[p] = a
        lo, med, hi = pct(a, 10, 50, 90)
        M(out, p.rsplit("/", 1)[-1], f"median {nf(med, 3)} (10-90%: {nf(lo, 3)} to {nf(hi, 3)})", "Volumetric soil moisture (check the units in the product specification)")
    a = arrs[names[0]]
    lo, hi = pct(a, 2, 98)
    IMG(out, names[0].rsplit("/", 1)[-1], render.colormap_png(a, lo, hi, "earth"), cr, geo_, {"min": lo, "max": hi, "unit": ""}, raw=a, gm=gm)
    attach(out, ctx, "SME2", dict(f=f, idx=idx, win=win, cr=cr, geo=geo_, gm=gm, sp=sp, names=names, arrs=arrs))


def a_unw(f, pg, idx, ctx, out):
    path = pick(idx, "unwrappedPhase", contains="unwrapped", prefer=("frequencyA", "HH", "VV")) or pick(idx, "unwrappedPhase")
    if not path:
        raise Unsupported("No unwrappedPhase layer found.")
    win, cr, geo_, sp, gm = locate(f, path, ctx, idx)
    set_window(out, win, cr, geo_, sp)
    ph = read(f, path, win).astype(np.float64)
    ph = np.where(ph == 0, np.nan, ph)
    cc_p = sibling(path, "connectedComponents", idx)
    if cc_p:
        cc = read(f, cc_p, win)
        ph = np.where(cc > 0, ph, np.nan)
    coh_p = sibling(path, "coherenceMagnitude", idx)
    coh = read(f, coh_p, win).astype(np.float64) if coh_p else None
    iono_p = sibling(path, "ionospherePhaseScreen", idx)
    # Unwrapped phase is meaningless where coherence is low (water, dense vegetation, damage): one unwrapping error
    # there would set "largest change" and shift the reference. Reference and statistics use reliable pixels only.
    cm = ctx.p("coh_min", 0.6)
    rel = np.isfinite(ph) & (coh >= cm) if coh is not None else np.isfinite(ph)
    basis = f"pixels with coherence of at least {cm:g}" if coh is not None else "all pixels (no coherence layer)"
    if rel.sum() < 100:
        rel, basis = np.isfinite(ph), "all pixels (too few reliable ones)"
        out["notes"].append("Very few pixels have good coherence, so the numbers include unreliable phase.")
    disp = (ph - np.nanmedian(np.where(rel, ph, np.nan))) * LAMBDA / (4 * np.pi) * 100  # cm, relative to the median of reliable pixels
    dr = np.where(rel, disp, np.nan)
    lo, hi = pct(dr, 2, 98)
    M(out, "Line-of-sight change (relative)", f"{nf(lo, 1)} to {nf(hi, 1)} cm (2-98%)", f"Relative to the median of the {basis}; check the specification for the sign convention")
    M(out, "Spread (std dev)", f"{nf(float(np.nanstd(dr)), 2)} cm", f"Measured on {basis}")
    M(out, "Largest change", f"{nf(float(np.nanmax(np.abs(dr))) if np.isfinite(dr).any() else float('nan'), 1)} cm", f"Measured on {basis}")
    if iono_p:
        io = read(f, iono_p, win).astype(np.float64)
        if io.shape == ph.shape:
            corr = (ph - io)
            corr = (corr - np.nanmedian(corr)) * LAMBDA / (4 * np.pi) * 100
            M(out, "Spread after removing ionosphere", f"{nf(float(np.nanstd(corr)), 2)} cm", "The ionospheric screen is included in the file but not applied by default")
    if coh is not None:
        valid = np.isfinite(coh)
        M(out, "Coherence", f"mean {nf(float(np.nanmean(coh)), 2)}", "1 = stable surface, 0 = completely changed")
        M(out, "Reliable pixels (coherence > 0.6)", f"{nf(share(coh > 0.6, valid), 1)} %")
        M(out, "Decorrelated pixels (coherence < 0.3)", f"{nf(share(coh < 0.3, valid), 1)} %", "Often water, vegetation change, damage or snow")
    lim = max(abs(lo), abs(hi), 1e-6)
    IMG(out, "Line-of-sight change (cm)", render.colormap_png(disp, -lim, lim, "diverging"), cr, geo_, {"min": -lim, "max": lim, "unit": "cm"}, raw=disp, gm=gm)
    if coh is not None:
        IMG(out, "Coherence", render.colormap_png(coh, 0, 1, "gray"), cr, geo_, {"min": 0, "max": 1, "unit": ""}, raw=coh, gm=gm)
    attach(out, ctx, pg.name.rsplit("/", 1)[-1], dict(f=f, idx=idx, path=path, win=win, cr=cr, geo=geo_, gm=gm, sp=sp, disp=disp, ph=ph, coh=coh))
    if not geo_:
        out["notes"].append("Radar-geometry crop from the middle of the frame: shown as a preview only, it cannot be placed on the map.")


def a_off(f, pg, idx, ctx, out):
    at = pick(idx, "alongTrackOffset", prefer=("frequencyA", "layer1", "HH", "VV"))
    sr = pick(idx, "slantRangeOffset", prefer=("frequencyA", "layer1", "HH", "VV"))
    if not (at and sr):
        raise Unsupported("Offset layers (alongTrackOffset, slantRangeOffset) not found.")
    win, cr, geo_, sp, gm = locate(f, at, ctx, idx)
    set_window(out, win, cr, geo_, sp)
    a, r = (read(f, p, win).astype(np.float64) for p in (at, sr))
    a, r = np.where(np.isfinite(a), a, np.nan), np.where(np.isfinite(r), r, np.nan)
    ma, mr = np.nanmedian(a), np.nanmedian(r)
    a0, r0 = a - ma, r - mr  # remove the bulk shift: what remains is relative motion
    mag = np.hypot(a0, r0)
    sig = noise_hf
    M(out, "Bulk offset (removed)", f"along-track {nf(ma, 2)} m, range {nf(mr, 2)} m", "Common shift of the window (orbit/geometry), not ground motion")
    M(out, "Noise level (robust)", f"along-track {nf(sig(a), 2)} m, range {nf(sig(r), 2)} m")
    p50, p95 = pct(mag, 50, 95)
    M(out, "Relative motion (median / 95th percentile)", f"{nf(p50, 2)} m / {nf(p95, 2)} m")
    # Noise of the 2-D offset magnitude is Rayleigh: its 95th percentile is sqrt(2 ln 20) = 2.45 sigma. A 95th percentile
    # of motion at that level is noise, not speed.
    sg = math.sqrt((sig(a) ** 2 + sig(r) ** 2) / 2)
    noise95 = math.sqrt(2 * math.log(20)) * sg
    to_speed = 365.25 / ctx.baseline_days
    if p95 <= 1.2 * noise95:
        M(out, f"Implied speed over {ctx.baseline_days:g} days (95th percentile)", f"not significant (below the noise floor of about {nf(noise95 * to_speed, 0)} m/yr)", "The offsets show no motion clearly above the noise")
    else:
        M(out, f"Implied speed over {ctx.baseline_days:g} days (95th percentile)", f"{nf(p95 * to_speed, 0)} m/yr", f"Noise floor about {nf(noise95 * to_speed, 0)} m/yr")
    lo, hi = pct(mag, 2, 98)
    IMG(out, "Relative motion (m)", render.colormap_png(mag, 0, max(hi, 1e-6), "viridis"), cr, geo_, {"min": 0, "max": hi, "unit": "m"}, raw=mag, gm=gm)
    lim = max(abs(x) for x in pct(r0, 2, 98))
    IMG(out, "Range offset (m)", render.colormap_png(r0, -lim, lim, "diverging"), cr, geo_, {"min": -lim, "max": lim, "unit": "m"}, raw=r0, gm=gm)
    attach(out, ctx, pg.name.rsplit("/", 1)[-1], dict(f=f, idx=idx, path=at, win=win, cr=cr, geo=geo_, gm=gm, sp=sp, a0=a0, r0=r0, mag=mag))
    out["notes"].append("Offsets are noisy: single outliers are normal. Trust areas where motion clearly exceeds the noise level.")
    if not geo_:
        out["notes"].append("Radar-geometry crop from the middle of the frame: shown as a preview only, it cannot be placed on the map.")


def a_rifg(f, pg, idx, ctx, out):
    p = pick(idx, "wrappedInterferogram", prefer=("frequencyA", "HH", "VV"))
    if not p:
        raise Unsupported("No wrappedInterferogram layer found.")
    win = radar_window(f[p].shape, ctx)
    set_window(out, win, None, False, None)
    z = read(f, p, win)
    ph = np.angle(z) if np.iscomplexobj(z) else z.astype(float)
    ph = np.where(np.abs(z) > 0, ph, np.nan) if np.iscomplexobj(z) else ph
    coh_p = sibling(p, "coherenceMagnitude", idx)
    if coh_p:
        coh = read(f, coh_p, win).astype(float)
        valid = np.isfinite(coh)
        M(out, "Coherence", f"mean {nf(float(np.nanmean(coh)), 2)}", "1 = stable surface, 0 = completely changed")
        M(out, "Decorrelated pixels (coherence < 0.3)", f"{nf(share(coh < 0.3, valid), 1)} %")
        IMG(out, "Coherence", render.colormap_png(coh, 0, 1, "gray"), None, False, {"min": 0, "max": 1, "unit": ""})
    IMG(out, "Wrapped phase (-pi to pi)", render.phase_png(ph), None, False, {"min": -math.pi, "max": math.pi, "unit": "rad"})
    attach(out, ctx, "RIFG", dict(f=f, idx=idx, win=win, cr=None, geo=False, gm=None, sp=None, z=z, ph=ph))
    out["notes"].append("Radar-geometry crop from the middle of the frame: shown as a preview only. Smooth colour cycles (fringes) mean ground change between the two dates.")


def a_rrsd(f, pg, idx, ctx, out):
    raise Unsupported("Raw radar data (L0B) holds unfocused pulses: it must be focused with SAR software such as ISCE3 first, so there is nothing to analyse here.")


ANALYSERS = {
    "GCOV": a_gcov, "GSLC": a_gslc, "RSLC": a_rslc, "SME2": a_sme2,
    "GUNW": a_unw, "RUNW": a_unw, "GOFF": a_off, "ROFF": a_off, "RIFG": a_rifg, "RRSD": a_rrsd,
}


def identification(f):
    out = {}
    for band in ("LSAR", "SSAR"):
        key = f"science/{band}/identification"
        if key in f:
            g = f[key]
            for k in ID_KEYS:
                if k in g:
                    v = g[k][()]
                    v = v.decode() if isinstance(v, bytes) else v.item() if hasattr(v, "item") else v
                    out[k] = v
            break
    return out


def run(f, ctx, level=None):
    if "science" not in f:
        raise Unsupported("This does not look like a NISAR product file.")
    sci = f["science"]
    band = "LSAR" if "LSAR" in sci else next(iter(sci))
    level = "RRSD" if level == "L0B" else level
    prods = [k for k in KNOWN if k in sci[band]]
    prod = level if level in prods else (prods[0] if prods else None)
    if not prod:
        raise Unsupported("Unrecognised NISAR product layout.")
    pg = sci[band][prod]
    out = {"product": prod, "identification": identification(f), "metrics": [], "images": [], "notes": [], "window": None}
    ANALYSERS[prod](f, pg, build_index(pg), ctx, out)
    return out
