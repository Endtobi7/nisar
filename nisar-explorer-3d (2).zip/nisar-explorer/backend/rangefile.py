"""File-like object that reads a remote file with HTTP Range requests, so h5py can open an HDF5 file
and read only the chunks it needs instead of downloading the whole granule."""
import io
from collections import OrderedDict
from urllib.parse import urlparse

import requests

BLOCK = 2 * 1024 * 1024
MAX_BLOCKS = 96  # ~190 MB of cache at most


class RangeFile(io.RawIOBase):
    def __init__(self, session, url, block=BLOCK, max_blocks=MAX_BLOCKS):
        super().__init__()
        self.session, self.src = session, url
        self.block, self.max_blocks = block, max_blocks
        self.pos = 0
        self.cache = OrderedDict()
        self.requests_made = 0
        self._resolve()

    # follow the Earthdata login redirects once, then talk to the final (pre-signed) URL directly
    def _resolve(self):
        r = self.session.get(self.src, headers={"Range": "bytes=0-0"}, stream=True, timeout=60)
        try:
            if r.status_code in (401, 403):
                raise PermissionError("Earthdata rejected the request (sign in again, and accept the ASF DAAC EULA).")
            if r.status_code != 206:
                raise IOError(f"Server does not support partial reads (HTTP {r.status_code}).")
            self.size = int(r.headers["Content-Range"].split("/")[-1])
            self.url = r.url
        finally:
            r.close()
        same_host = urlparse(self.url).hostname == urlparse(self.src).hostname
        self.client = self.session if same_host else requests

    def _fetch(self, start, end):
        for attempt in range(2):
            self.requests_made += 1
            r = self.client.get(self.url, headers={"Range": f"bytes={start}-{end}"}, timeout=120)
            if r.status_code in (401, 403) and attempt == 0:
                self._resolve()  # pre-signed URL expired
                continue
            if r.status_code not in (200, 206):
                raise IOError(f"Range read failed (HTTP {r.status_code}).")
            return r.content
        raise IOError("Range read failed.")

    def _block(self, i):
        if i in self.cache:
            self.cache.move_to_end(i)
            return self.cache[i]
        start = i * self.block
        data = self._fetch(start, min(start + self.block, self.size) - 1)
        self.cache[i] = data
        if len(self.cache) > self.max_blocks:
            self.cache.popitem(last=False)
        return data

    # --- file protocol ---
    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.pos

    def seek(self, offset, whence=io.SEEK_SET):
        self.pos = offset if whence == io.SEEK_SET else self.pos + offset if whence == io.SEEK_CUR else self.size + offset
        return self.pos

    def read(self, n=-1):
        if n is None or n < 0:
            n = self.size - self.pos
        n = max(0, min(n, self.size - self.pos))
        out = bytearray()
        while n > 0:
            i, off = divmod(self.pos, self.block)
            chunk = self._block(i)[off:off + n]
            if not chunk:
                break
            out += chunk
            self.pos += len(chunk)
            n -= len(chunk)
        return bytes(out)

    def readinto(self, b):
        data = self.read(len(b))
        b[:len(data)] = data
        return len(data)
