"""Validate NISAR Explorer results against an independent reference and calibrate thresholds.

Why: every threshold in the app (water -15 dB, coherence 0.6, ...) is a rule of thumb. On a real scene you can
measure how good it is, and find the best value, by comparing with a trusted map (for example an optical water mask
from Sentinel-2, JRC Global Surface Water, or a mapped flood extent).

Typical use (export the layers from the app as GeoTIFF first):

    # how good is a binary map (water, flood, deforestation...)?
    python validate.py compare --pred water_map.tif --ref reference_water.tif

    # which dB threshold best separates water from land on THIS scene?
    python validate.py water-threshold --db HH_backscatter_dB.tif --ref reference_water.tif

    # which coherence limit keeps the displacement error small? (needs a GNSS or a stable-area reference)
    python validate.py coherence --coh coherence.tif --disp los_change_cm.tif --stable stable_area_mask.tif

The reference raster is resampled onto the result's grid automatically (nearest neighbour for masks).
Reference values: any non-zero value counts as "positive" (water, flood, ...) unless --ref-positive is given.
"""
import argparse
import math
import sys

import numpy as np


# ---------------------------------------------------------------- core metrics (pure numpy, tested)
def confusion(pred, ref, valid=None):
    """Agreement of a binary map with a binary reference. NaN / invalid pixels are ignored."""
    pred, ref = np.asarray(pred, bool), np.asarray(ref, bool)
    ok = np.ones(pred.shape, bool) if valid is None else np.asarray(valid, bool)
    p, r = pred[ok], ref[ok]
    tp, fp = int((p & r).sum()), int((p & ~r).sum())
    fn, tn = int((~p & r).sum()), int((~p & ~r).sum())
    n = tp + fp + fn + tn
    prec = tp / (tp + fp) if tp + fp else float("nan")
    rec = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else float("nan")
    iou = tp / (tp + fp + fn) if tp + fp + fn else float("nan")
    po = (tp + tn) / n if n else float("nan")
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / (n * n) if n else float("nan")
    kappa = (po - pe) / (1 - pe) if n and pe != 1 else float("nan")
    return dict(tp=tp, fp=fp, fn=fn, tn=tn, n=n, precision=prec, recall=rec, f1=f1, iou=iou,
                overall_accuracy=po, kappa=kappa,
                predicted_share=100.0 * (tp + fp) / n if n else float("nan"),
                reference_share=100.0 * (tp + fn) / n if n else float("nan"))


def auc(score, ref, valid=None):
    """Area under the ROC curve for 'low score = positive' (water is DARK): probability that a random positive
    pixel is darker than a random negative one. 0.5 = no skill, 1 = perfect."""
    s = np.asarray(score, float)
    r = np.asarray(ref, bool)
    ok = np.isfinite(s) if valid is None else (np.asarray(valid, bool) & np.isfinite(s))
    s, r = s[ok], r[ok]
    npos, nneg = int(r.sum()), int((~r).sum())
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(s, kind="mergesort")
    ranks = np.empty(len(s))
    ss = s[order]
    i = 0
    while i < len(ss):                      # average ranks for ties
        j = i
        while j + 1 < len(ss) and ss[j + 1] == ss[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1
        i = j + 1
    rank_pos = ranks[r].sum()
    u = rank_pos - npos * (npos + 1) / 2.0  # = number of (positive, negative) pairs where positive has the LOWER value
    return float(1.0 - u / (npos * nneg))


def sweep_threshold(db, ref, lo=-35.0, hi=-5.0, step=0.5, valid=None):
    """Try every dB threshold: pixels below it are water. Returns (rows, best_by_f1, best_by_youden)."""
    db = np.asarray(db, float)
    ok = np.isfinite(db) if valid is None else (np.asarray(valid, bool) & np.isfinite(db))
    rows = []
    for t in np.arange(lo, hi + 1e-9, step):
        c = confusion(db < t, ref, ok)
        tpr = c["recall"]
        fpr = c["fp"] / (c["fp"] + c["tn"]) if c["fp"] + c["tn"] else float("nan")
        rows.append(dict(threshold=float(t), f1=c["f1"], iou=c["iou"], precision=c["precision"], recall=tpr, fpr=fpr,
                         predicted_share=c["predicted_share"], youden=tpr - fpr))
    good = [r for r in rows if not math.isnan(r["f1"])]
    best_f1 = max(good, key=lambda r: r["f1"]) if good else None
    best_y = max((r for r in rows if not math.isnan(r["youden"])), key=lambda r: r["youden"], default=None)
    return rows, best_f1, best_y


def coherence_sweep(coh, err_cm, valid=None, limits=(0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)):
    """Displacement error (robust std, cm) and share of pixels kept for each coherence limit.
    `err_cm` must be a quantity that should be ZERO (displacement over stable ground)."""
    coh, e = np.asarray(coh, float), np.asarray(err_cm, float)
    ok = np.isfinite(coh) & np.isfinite(e)
    if valid is not None:
        ok &= np.asarray(valid, bool)
    out = []
    for lim in limits:
        k = ok & (coh >= lim)
        if k.sum() < 30:
            out.append(dict(limit=lim, kept=100.0 * k.sum() / max(ok.sum(), 1), error_cm=float("nan"), rmse_cm=float("nan")))
            continue
        x = e[k]
        out.append(dict(limit=lim, kept=100.0 * k.sum() / ok.sum(),
                        error_cm=float(1.4826 * np.median(np.abs(x - np.median(x)))),
                        rmse_cm=float(np.sqrt(np.mean(x ** 2)))))
    return out


# ---------------------------------------------------------------- raster helpers (rasterio)
def read_raster(path):
    import rasterio
    with rasterio.open(path) as ds:
        return ds.read(1).astype(float), ds.transform, ds.crs, ds.nodata


def match_grid(ref_path, like_shape, like_transform, like_crs, categorical=True):
    """read the reference raster resampled onto the grid of the result"""
    import rasterio
    from rasterio.warp import Resampling, reproject
    with rasterio.open(ref_path) as src:
        dst = np.full(like_shape, np.nan, dtype="float64")
        reproject(source=rasterio.band(src, 1), destination=dst, src_transform=src.transform, src_crs=src.crs,
                  src_nodata=src.nodata, dst_transform=like_transform, dst_crs=like_crs, dst_nodata=np.nan,
                  resampling=Resampling.nearest if categorical else Resampling.bilinear)
    return dst


def _fmt(c):
    f = lambda v: "nan" if v is None or (isinstance(v, float) and math.isnan(v)) else f"{v:.3f}"
    return (f"pixels compared {c['n']}\n  result share {c['predicted_share']:.2f} %  |  reference share {c['reference_share']:.2f} %\n"
            f"  precision {f(c['precision'])}  recall {f(c['recall'])}  F1 {f(c['f1'])}  IoU {f(c['iou'])}  kappa {f(c['kappa'])}  overall accuracy {f(c['overall_accuracy'])}\n"
            f"  (false alarms {c['fp']}, misses {c['fn']})")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("compare", help="agreement of a binary result with a reference")
    a.add_argument("--pred", required=True); a.add_argument("--ref", required=True)
    a.add_argument("--ref-positive", type=float, default=None, help="reference value that means positive (default: any non-zero)")
    b = sub.add_parser("water-threshold", help="best dB threshold for water on this scene")
    b.add_argument("--db", required=True); b.add_argument("--ref", required=True)
    b.add_argument("--ref-positive", type=float, default=None)
    c = sub.add_parser("coherence", help="displacement error against the coherence limit over stable ground")
    c.add_argument("--coh", required=True); c.add_argument("--disp", required=True); c.add_argument("--stable", required=True)
    args = ap.parse_args(argv)

    if args.cmd in ("compare", "water-threshold"):
        first = args.pred if args.cmd == "compare" else args.db
        arr, tr, crs, nd = read_raster(first)
        ref = match_grid(args.ref, arr.shape, tr, crs)
        refpos = (ref != 0) if args.ref_positive is None else (ref == args.ref_positive)
        valid = np.isfinite(arr) & np.isfinite(ref)
        if args.cmd == "compare":
            print(_fmt(confusion(arr != 0, refpos, valid)))
        else:
            rows, bf, by = sweep_threshold(arr, refpos, valid=valid)
            print(f"AUC (dark = water): {auc(arr, refpos, valid):.3f}   (0.5 = no skill, 1 = perfect)")
            print(f"best F1     : {bf['threshold']:.1f} dB  (F1 {bf['f1']:.3f}, IoU {bf['iou']:.3f}, precision {bf['precision']:.3f}, recall {bf['recall']:.3f})")
            print(f"best Youden : {by['threshold']:.1f} dB")
            print("app default is -15 dB (co-pol). A very different best value means the rule of thumb does not fit this scene.")
    else:
        coh, tr, crs, _ = read_raster(args.coh)
        disp = match_grid(args.disp, coh.shape, tr, crs, categorical=False)
        st = match_grid(args.stable, coh.shape, tr, crs)
        print("limit  kept %   robust error (cm)   RMSE (cm)")
        for r in coherence_sweep(coh, disp, st != 0):
            print(f"{r['limit']:.1f}   {r['kept']:6.1f}   {r['error_cm']:10.3f}   {r['rmse_cm']:10.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
