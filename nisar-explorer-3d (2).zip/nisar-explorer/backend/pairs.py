"""Analyses that combine TWO NISAR files (same track/frame/orbit direction unless stated)."""
import math

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

import analyse as A
import extras as X
import render
from analyse import Ctx, Unsupported

M, IMG, nf, pct = A.M, A.IMG, A.nf, A.pct


# ---------- plumbing ----------
class Src:
    def __init__(self, f, prod):
        sci = f["science"]
        band = "LSAR" if "LSAR" in sci else next(iter(sci))
        if prod not in sci[band]:
            raise Unsupported(f"This file is not a {prod} product.")
        self.f, self.prod, self.pg = f, prod, sci[band][prod]
        self.idx = A.build_index(self.pg)
        self.ident = A.identification(f)

    def path(self, name, contains=None, prefer=("frequencyA",)):
        p = A.pick(self.idx, name, contains=contains, prefer=prefer)
        if not p:
            raise Unsupported(f"{self.prod}: layer {name} not found.")
        return p

    def locate(self, path, ctx):
        return A.locate(self.f, path, ctx, self.idx)

    def read(self, path, win):
        return A.read(self.f, path, win)


def fit_to(a, shape):
    """resample a (rows, cols) array onto `shape`, NaN-aware"""
    a = np.asarray(a, float)
    if a.shape == shape:
        return a
    m = np.isfinite(a).astype("f4")
    filled = np.where(np.isfinite(a), a, 0).astype("f4")
    w, h = shape[1], shape[0]
    flt = Image.BOX if (a.shape[0] > h and a.shape[1] > w) else Image.BILINEAR
    num = np.asarray(Image.fromarray(filled, "F").resize((w, h), flt), float)
    den = np.asarray(Image.fromarray(m, "F").resize((w, h), flt), float)
    return np.where(den > 0.5, num / np.maximum(den, 1e-6), np.nan)


def bbox_of(corners):
    lon = [p[0] for p in corners]
    lat = [p[1] for p in corners]
    return (min(lon), min(lat), max(lon), max(lat))


def base_window(sa, name_a, ctx):
    path = sa.path(name_a)
    win, cr, geo_, sp, gm = sa.locate(path, ctx)
    if not geo_:
        raise Unsupported("Two-file analyses need geocoded (map-ready) products.")
    return path, win, cr, gm, sp


def check_cover(cr_base, cr_other, need=0.85):
    b, o = bbox_of(cr_base), bbox_of(cr_other)
    w = max(0.0, min(b[2], o[2]) - max(b[0], o[0]))
    h = max(0.0, min(b[3], o[3]) - max(b[1], o[1]))
    if w * h < need * (b[2] - b[0]) * (b[3] - b[1]):
        raise Unsupported("The two files do not cover the same area: pick files of the same track and frame, or draw a smaller area.")


def other_window(sb, name_b, ctx, cr_base):
    path = sb.path(name_b)
    c2 = Ctx(bbox=bbox_of(cr_base), max_px=ctx.max_px, default_px=ctx.default_px, baseline_days=ctx.baseline_days, params=ctx.params)
    win, cr, geo_, sp, gm = sb.locate(path, c2)
    check_cover(cr_base, cr)
    return path, win


def multilook(a, k=5):
    a = np.asarray(a, float)
    ok = np.isfinite(a)
    num = ndi.uniform_filter(np.where(ok, a, 0), k)
    den = ndi.uniform_filter(ok.astype(float), k)
    return np.where(ok & (den > 0.3), num / np.maximum(den, 1e-9), np.nan)


def db_of(p):
    return 10 * np.log10(np.where(p > 0, p, np.nan))


def pol_of(sa, sb, order=("HH", "VV", "HV", "VH")):
    for p in order:
        try:
            sa.path(p + p), sb.path(p + p)
            return p
        except Unsupported:
            continue
    raise Unsupported("The two files have no polarization in common.")


def d_of(gm):
    return {"gm": gm}


def gm_area(n, gm):
    return f"{n * gm['dx'] * gm['dy'] / 1e6:.2f} km2"


def finish(out, win, cr, gm, sp):
    A.set_window(out, win, cr, True, sp)


def gcov_pair(sa, sb, ctx, pol=None):
    pol = pol or pol_of(sa, sb)
    pa, win, cr, gm, sp = base_window(sa, pol + pol, ctx)
    a = sa.read(pa, win).astype(float)
    pb, winb = other_window(sb, pol + pol, ctx, cr)
    b = fit_to(sb.read(pb, winb).astype(float), a.shape)
    return pol, a, b, win, cr, gm, sp


# ---------- change maps ----------
def _change(out, ctx, ia, ib, win, cr, gm, sp, label, k_sigma=None):
    A.set_window(out, win, cr, True, sp)
    L = ctx.p("looks", 25.0)
    k = ctx.p("k_sigma", 3.0)
    fa = ctx.p("false_alarm", 0.0)                  # optional: choose the false-alarm rate instead of k sigma
    if 0.0 < fa < 1.0:
        from scipy.stats import norm
        k = float(norm.isf(fa / 2.0))               # two-sided
    da, db_ = db_of(multilook(ia)), db_of(multilook(ib))
    ch = db_ - da
    v = np.isfinite(ch)
    # Noise of the dB ratio of two independent images. Lower bound: speckle after the 5 x 5 multilook with fully
    # independent pixels (L x 25 looks). Upper bound: no multilook gain (L looks). Neighbouring GCOV pixels are
    # correlated, so the real value is in between: take the robust spread of the data (MAD, not hurt by real change
    # unless it covers half the scene) and keep it inside those bounds.
    s_lo, s_hi = 4.343 * math.sqrt(2.0 / (L * 25.0)), 4.343 * math.sqrt(2.0 / L)
    mad = 1.4826 * float(np.nanmedian(np.abs(ch[v] - np.nanmedian(ch[v])))) if v.any() else s_hi
    sigma = min(max(mad, s_lo), s_hi)
    T = k * sigma
    up, down = v & (ch > T), v & (ch < -T)
    M(out, "Change threshold", f"{nf(T, 1)} dB", f"{k:.3g} x the noise of the log-ratio ({nf(sigma, 2)} dB, measured on this scene and kept between {nf(s_lo, 2)} and {nf(s_hi, 2)} dB)")
    M(out, "Median change (after minus before)", f"{nf(float(np.nanmedian(ch)), 2)} dB")
    M(out, "Brighter pixels", f"{nf(A.share(up, v), 1)} % - {gm_area(int(up.sum()), gm)}")
    M(out, "Darker pixels", f"{nf(A.share(down, v), 1)} % - {gm_area(int(down.sum()), gm)}")
    lim = max(T * 2, pct(np.abs(ch), 98)[0] or 1e-6)
    IMG(out, f"{label}: change (dB)", render.colormap_png(ch, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "dB"}, raw=ch, gm=gm)
    IMG(out, "Significant change (blue = darker, red = brighter)", render.class_png(np.where(up, 2, np.where(down, 1, 0)), {1: (33, 102, 172, 220), 2: (214, 39, 40, 220)}), cr, True, None, gm=gm)
    out["notes"].append("Wet soil, wind on water and freeze/thaw also change backscatter. Compare the same season where possible.")


def _file_looks(src, win):
    """median numberOfLooks of the window from the product itself (None if the layer is missing)"""
    try:
        path = src.path("HHHH", prefer=("frequencyA",)) if _has(src, "HHHH") else src.path("VVVV", prefer=("frequencyA",))
        lp = path.rsplit("/", 1)[0] + "/numberOfLooks"
        if lp not in src.f:
            return None
        y0, y1, x0, x1, step = win
        v = np.asarray(src.f[lp][y0:y1:step, x0:x1:step], float)
        v = v[np.isfinite(v) & (v > 0)]
        return float(np.median(v)) if v.size else None
    except Exception:
        return None


def gcov_change(sa, sb, ctx, out):
    pol, a, b, win, cr, gm, sp = gcov_pair(sa, sb, ctx)
    params = dict(ctx.params or {})
    if "looks" not in params:                       # use the real number of looks of the files, not a guess
        L = _file_looks(sa, win)
        if L:
            params["looks"] = L
    ctx = Ctx(**{**ctx.__dict__, "params": params})
    _change(out, ctx, a, b, win, cr, gm, sp, f"{pol} backscatter")




def gslc_change(sa, sb, ctx, out):
    name = "HH" if _has(sa, "HH") and _has(sb, "HH") else "VV"
    pa, win, cr, gm, sp = base_window(sa, name, ctx)
    z1 = sa.read(pa, win).astype(np.complex128)
    pb, winb = other_window(sb, name, ctx, cr)
    z2 = sb.read(pb, winb).astype(np.complex128)
    if z2.shape != z1.shape:
        raise Unsupported("The two GSLC files are not on the same grid.")
    i1, i2 = np.abs(z1) ** 2, np.abs(z2) ** 2
    i1, i2 = np.where(i1 > 0, i1, np.nan), np.where(i2 > 0, i2, np.nan)
    c2 = Ctx(**{**ctx.__dict__, "params": {**(ctx.params or {}), "looks": 1.0}})   # single-look pixels
    _change(out, c2, i1, i2, win, cr, gm, sp, f"{name} amplitude")


def _has(s, name):
    try:
        s.path(name)
        return True
    except Unsupported:
        return False


def gcov_flood(sa, sb, ctx, out):
    pol, a, b, win, cr, gm, sp = gcov_pair(sa, sb, ctx, None)
    A.set_window(out, win, cr, True, sp)
    da, db_ = db_of(multilook(a)), db_of(multilook(b))     # smoothed only to measure the CHANGE
    if A.finite(da).size < 200 or A.finite(db_).size < 200:
        raise Unsupported("Too few valid pixels.")
    ch = db_ - da
    core, grow = X.water_limits(ctx, pol)
    pa, pb = db_of(a), db_of(b)                              # water is found on single pixels, so thin rivers survive
    npx = int(ctx.p("water_min_px", X.WATER_MIN_PX))
    wa, wb = X.water_regions(pa, core, grow, npx), X.water_regions(pb, core, grow, npx)
    steep, steep_txt = X.terrain_steep(ctx, gm, da.shape)
    if steep is not None:
        wa, wb = wa & ~steep, wb & ~steep
    new = wb & ~wa & (ch < -3)
    perm = wa & wb
    veg = np.isfinite(ch) & (ch > 3) & ~wa
    v = np.isfinite(ch)
    M(out, "Water threshold", f"seed below {nf(core, 0)} dB, growth below {nf(grow, 0)} dB ({pol})", "Fixed physical limits on each date (change with water_core_db / water_grow_db); same rule as the water map")
    M(out, "Permanent water", f"{nf(A.share(perm, v), 1)} % - {gm_area(int(perm.sum()), gm)}")
    M(out, "New open water (flooded)", f"{nf(A.share(new, v), 1)} % - {gm_area(int(new.sum()), gm)}", "Dark after, not dark before, at least 3 dB darker")
    M(out, "Possible flooded vegetation", f"{nf(A.share(veg, v), 1)} % - {gm_area(int(veg.sum()), gm)}", "At least 3 dB brighter (double-bounce): also caused by soil moisture or growth, so only a hint")
    IMG(out, "Flood map (blue = permanent water, red = new water, orange = possible flooded vegetation)",
        render.class_png(np.where(new, 2, np.where(perm, 1, np.where(veg, 3, 0))), {1: (31, 119, 180, 200), 2: (214, 39, 40, 230), 3: (255, 127, 14, 200)}), cr, True, None, raw=new.astype(float), gm=gm)
    out["notes"].append("Excluded steep terrain (" + steep_txt + ")." if steep is not None else "Radar shadow, layover and steep slopes can look like water. The mask layer does not mark them: give a DEM (parameter dem) to exclude steep slopes, and check an optical image.")


def gcov_deforest(sa, sb, ctx, out):
    cross = next((p for p in ("HV", "VH") if _has(sa, p + p) and _has(sb, p + p)), None)
    if not cross:
        raise Unsupported("Needs HV (or VH) in both files.")
    _, hv_a, hv_b, win, cr, gm, sp = gcov_pair(sa, sb, ctx, cross)
    co = next((p for p in ("HH", "VV") if _has(sa, p + p) and _has(sb, p + p)), None)
    A.set_window(out, win, cr, True, sp)
    da, db_ = db_of(multilook(hv_a)), db_of(multilook(hv_b))
    d_hv = db_ - da
    thr = ctx.p("hv_drop", 2.0)
    loss = np.isfinite(d_hv) & (d_hv < -thr)
    if co:
        pa = sa.path(co + co)
        c_a = db_of(multilook(sa.read(pa, win).astype(float)))
        pb2, w2 = other_window(sb, co + co, ctx, cr)
        c_b = db_of(multilook(fit_to(sb.read(pb2, w2).astype(float), hv_a.shape)))
        loss &= np.isfinite(c_a) & np.isfinite(c_b) & ((db_ - c_b) < (da - c_a))
    min_px = max(4, int(round(5000.0 / (gm["dx"] * gm["dy"]))))
    lab, n = ndi.label(loss)
    if n:
        sizes = ndi.sum(loss, lab, range(1, n + 1))
        loss = np.isin(lab, 1 + np.where(sizes >= min_px)[0])
    v = np.isfinite(d_hv)
    M(out, f"Vegetation loss ({cross} drop of more than {thr:g} dB)", f"{nf(A.share(loss, v), 1)} % - {gm_area(int(loss.sum()), gm)}", f"Patches of at least {min_px} pixels (about half a hectare); {cross} minus co-pol must also fall" if co else None)
    M(out, f"Median {cross} change", f"{nf(float(np.nanmedian(d_hv)), 2)} dB (inside the loss area: {nf(float(np.nanmedian(d_hv[loss])) if loss.any() else float('nan'), 2)} dB)")
    lim = max(thr * 2, pct(np.abs(d_hv), 98)[0] or 1e-6)
    IMG(out, f"{cross} change (dB)", render.colormap_png(d_hv, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "dB"}, raw=d_hv, gm=gm)
    IMG(out, "Vegetation loss (red)", render.class_png(loss.astype(int), {1: (214, 39, 40, 230)}), cr, True, None, raw=loss.astype(float), gm=gm)
    out["notes"].append("Fire, clearing, harvest, flooding and frozen ground all lower HV. The limit is an example: tune it and validate with optical data.")


def coherence_change(sa, sb, ctx, out):
    pa, win, cr, gm, sp = base_window(sa, "coherenceMagnitude", ctx)
    pb, winb = other_window(sb, "coherenceMagnitude", ctx, cr)
    ca = sa.read(pa, win).astype(float)
    cb = fit_to(sb.read(pb, winb).astype(float), ca.shape)
    A.set_window(out, win, cr, True, sp)
    drop = ctx.p("drop", 0.3)
    dg = cb - ca
    v = np.isfinite(dg)
    hit = v & (dg < -drop) & (ca >= 0.4)
    M(out, "Mean coherence", f"reference pair {nf(float(np.nanmean(ca)), 2)}, event pair {nf(float(np.nanmean(cb)), 2)}")
    M(out, f"Pixels that lost more than {drop:g} coherence", f"{nf(A.share(hit, v), 1)} % - {gm_area(int(hit.sum()), gm)}", "Only where the reference pair was coherent (0.4 or more)")
    IMG(out, "Coherence change (event minus reference)", render.colormap_png(dg, -1, 1, "diverging"), cr, True, {"min": -1, "max": 1, "unit": ""}, raw=dg, gm=gm)
    IMG(out, "Strong coherence loss (red)", render.class_png(hit.astype(int), {1: (214, 39, 40, 230)}), cr, True, None, raw=hit.astype(float), gm=gm)
    out["notes"].append("A = reference pair (no event), B = pair spanning the event. Damage is one possible cause; vegetation change, flooding and snow also lower coherence.")


def gslc_ifg(sa, sb, ctx, out):
    name = "HH" if _has(sa, "HH") and _has(sb, "HH") else "VV"
    pa, win, cr, gm, sp = base_window(sa, name, ctx)
    z1 = sa.read(pa, win).astype(np.complex128)
    pb, winb = other_window(sb, name, ctx, cr)
    z2 = sb.read(pb, winb).astype(np.complex128)
    if z2.shape != z1.shape:
        raise Unsupported("The two GSLC files are not on the same grid.")
    A.set_window(out, win, cr, True, sp)
    k = 5
    ifg = z1 * np.conj(z2)
    mean = ndi.uniform_filter(ifg.real, k) + 1j * ndi.uniform_filter(ifg.imag, k)
    p1, p2 = ndi.uniform_filter(np.abs(z1) ** 2, k), ndi.uniform_filter(np.abs(z2) ** 2, k)
    coh = np.abs(mean) / np.sqrt(np.maximum(p1 * p2, 1e-30))
    ok = (np.abs(z1) > 0) & (np.abs(z2) > 0)
    coh, ph = np.where(ok, coh, np.nan), np.where(ok, np.angle(mean), np.nan)
    v = np.isfinite(coh)
    M(out, "Coherence (5x5 pixels)", f"mean {nf(float(np.nanmean(coh)), 2)}; above 0.6: {nf(A.share(coh > 0.6, v), 1)} %")
    M(out, "One phase cycle", f"{nf(A.LAMBDA / 2 * 100, 1)} cm of line-of-sight change")
    IMG(out, "Wrapped interferometric phase", render.phase_png(ph), cr, True, {"min": -math.pi, "max": math.pi, "unit": "rad"}, gm=gm)
    IMG(out, "Coherence", render.colormap_png(coh, 0, 1, "gray"), cr, True, {"min": 0, "max": 1, "unit": ""}, raw=coh, gm=gm)
    out["notes"].append("Simplified interferogram: topographic and geometric phase are not removed and the phase is not unwrapped. For quantitative motion use the GUNW product.")


# ---------- different products ----------
def _unw(s, ctx, win=None, bbox=None):
    path = A.pick(s.idx, "unwrappedPhase", contains="unwrapped", prefer=("frequencyA", "HH", "VV")) or s.path("unwrappedPhase")
    c2 = ctx if bbox is None else Ctx(bbox=bbox, max_px=ctx.max_px, default_px=ctx.default_px, params=ctx.params)
    w, cr, geo_, sp, gm = s.locate(path, c2)
    ph = s.read(path, w).astype(float)
    ph = np.where(ph == 0, np.nan, ph)
    cc = A.sibling(path, "connectedComponents", s.idx)
    if cc:
        ph = np.where(s.read(cc, w) > 0, ph, np.nan)
    coh_p = A.sibling(path, "coherenceMagnitude", s.idx)
    coh = s.read(coh_p, w).astype(float) if coh_p else np.full(ph.shape, np.nan)
    disp = (ph - np.nanmedian(ph)) * A.LAMBDA / (4 * math.pi) * 100
    return disp, coh, w, cr, gm, sp, geo_


def gcov_gunw(sa, sb, ctx, out):  # A = GCOV, B = GUNW
    disp, coh, win, cr, gm, sp, geo_ = _unw(sb, ctx)
    if not geo_:
        raise Unsupported("Needs a geocoded GUNW file.")
    pol = "HH" if _has(sa, "HHHH") else "VV"
    pa = sa.path(pol + pol)
    c2 = Ctx(bbox=bbox_of(cr), max_px=ctx.max_px * 4, default_px=ctx.default_px * 4)
    wa, cra, _, _, _ = sa.locate(pa, c2)
    check_cover(cr, cra)
    g = X._smooth_db(fit_to(sa.read(pa, wa).astype(float), disp.shape))  # 3 x 3 mean first: single speckle dips are not water
    A.set_window(out, win, cr, True, sp)
    water = np.isfinite(g) & (g < -18)
    keep = np.isfinite(disp) & ~water & ((coh >= 0.6) | ~np.isfinite(coh))
    masked = np.where(keep, disp, np.nan)
    v = np.isfinite(disp)
    M(out, "Pixels kept", f"{nf(100 * keep.sum() / max(1, v.sum()), 1)} %", "Not water-like (GCOV below -18 dB) and coherence of at least 0.6")
    M(out, "Water-like pixels removed", f"{nf(A.share(water, v), 1)} %")
    M(out, "Spread of the change, before and after masking", f"{nf(float(np.nanstd(disp)), 2)} cm to {nf(float(np.nanstd(masked)), 2)} cm")
    lim = max(abs(x) for x in pct(masked, 2, 98)) or 1e-6
    IMG(out, "Line-of-sight change, reliable surfaces only (cm)", render.colormap_png(masked, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "cm"}, raw=masked, gm=gm)
    IMG(out, "Removed: water-like (blue)", render.class_png(water.astype(int), {1: (31, 119, 180, 200)}), cr, True, None, gm=gm)
    out["notes"].append("A = GCOV, B = GUNW over the same area. The GCOV image is averaged down to the GUNW grid.")


def gcov_sme2(sa, sb, ctx, out):  # A = GCOV, B = SME2
    names = [p for p in sb.idx if "soilmoisture" in p.rsplit("/", 1)[-1].lower() and "uncert" not in p.lower()]
    if not names:
        raise Unsupported("SME2: no soil-moisture layer found.")
    names.sort(key=lambda p: (len(p), p))
    win, cr, geo_, sp, gm = sb.locate(names[0], ctx)
    if not geo_:
        raise Unsupported("Needs a geocoded SME2 file.")
    sm = sb.read(names[0], win).astype(float)
    sm = np.where((sm >= 0) & np.isfinite(sm), sm, np.nan)
    pol = "HH" if _has(sa, "HHHH") else "VV"
    pa = sa.path(pol + pol)
    wa, cra, _, _, _ = sa.locate(pa, Ctx(bbox=bbox_of(cr), max_px=ctx.max_px * 10, default_px=ctx.default_px * 10))
    check_cover(cr, cra)
    g = db_of(fit_to(sa.read(pa, wa).astype(float), sm.shape))
    A.set_window(out, win, cr, True, sp)
    ok = np.isfinite(sm) & np.isfinite(g)
    if ok.sum() < 20:
        raise Unsupported("Too few common valid cells.")
    x, y = sm[ok], g[ok]
    r = float(np.corrcoef(x, y)[0, 1])
    slope, icpt = np.polyfit(x, y, 1)
    M(out, "Correlation (backscatter in dB vs soil moisture)", nf(r, 2), f"{int(ok.sum())} cells; 1 = backscatter follows soil moisture perfectly")
    M(out, "Straight-line fit", f"{nf(slope / 10, 2)} dB per 0.1 of soil moisture", f"intercept {nf(icpt, 1)} dB (assuming soil moisture in m3/m3)")
    rng = np.random.default_rng(0)
    pick_ = rng.choice(len(x), min(500, len(x)), replace=False)
    out.setdefault("series", []).append({"name": "Backscatter vs soil moisture", "kind": "scatter", "x": x[pick_].tolist(), "y": y[pick_].tolist(), "xlabel": "soil moisture", "ylabel": f"{pol} backscatter (dB)"})
    IMG(out, f"{pol} backscatter on the soil-moisture grid (dB)", render.colormap_png(g, *pct(g, 2, 98), "gray"), cr, True, {"min": pct(g, 2)[0], "max": pct(g, 98)[0], "unit": "dB"}, raw=g, gm=gm)
    out["notes"].append("A = GCOV, B = SME2. The GCOV image is averaged into the 200 m soil-moisture cells. Vegetation and roughness also change backscatter, so a correlation is not a calibration.")


def goff_gunw(sa, sb, ctx, out):  # A = GOFF, B = GUNW
    disp, coh, win, cr, gm, sp, geo_ = _unw(sb, ctx)
    if not geo_:
        raise Unsupported("Needs a geocoded GUNW file.")
    pr = sa.path("slantRangeOffset", prefer=("frequencyA", "layer1", "HH"))
    wa, cra, _, _, _ = sa.locate(pr, Ctx(bbox=bbox_of(cr), max_px=ctx.max_px, default_px=ctx.default_px))
    check_cover(cr, cra)
    r = fit_to(sa.read(pr, wa).astype(float), disp.shape)
    r_cm = (r - np.nanmedian(r)) * 100
    A.set_window(out, win, cr, True, sp)
    cmin = ctx.p("coh_min", 0.6)
    good = np.isfinite(disp) & np.isfinite(r_cm) & (coh >= cmin)
    if good.sum() < 20:
        raise Unsupported("Too few pixels where both products are valid.")
    rho = float(np.corrcoef(r_cm[good], disp[good])[0, 1])
    flipped = rho < -0.3                       # the two products use opposite signs: flip the offsets, or merged patches are wrong
    if flipped:
        r_cm = -r_cm
        out["notes"].append(f"The offsets and the phase have opposite signs (correlation {nf(rho, 2)}). The offsets were flipped before comparing and merging.")
    diff = r_cm - disp
    M(out, "Agreement where both are valid (coherence 0.6 or more)", f"bias {nf(float(np.nanmedian(diff[good])), 2)} cm, rms difference {nf(float(np.sqrt(np.nanmean(diff[good] ** 2))), 2)} cm", f"{int(good.sum())} pixels; the sign convention of the two products may differ")
    M(out, "Correlation", nf(float(np.corrcoef(r_cm[good], disp[good])[0, 1]), 2))
    merged = np.where(np.isfinite(disp) & (coh >= cmin), disp, r_cm)
    M(out, "Pixels filled from offsets", f"{nf(100 * float(np.sum(np.isfinite(r_cm) & ~(np.isfinite(disp) & (coh >= cmin)))) / merged.size, 1)} %", "Where phase is unreliable")
    lim = max(abs(x) for x in pct(merged, 2, 98)) or 1e-6
    IMG(out, "Merged line-of-sight change (phase, else offsets) (cm)", render.colormap_png(merged, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "cm"}, raw=merged, gm=gm)
    IMG(out, "Offsets minus phase (cm)", render.colormap_png(np.where(good, diff, np.nan), -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "cm"}, gm=gm)
    out["notes"].append("A = GOFF, B = GUNW for the same pair. Offsets are much noisier than phase, so the merged map is only a guide in fast-moving areas.")


def vertical_ew(sa, sb, ctx, out):  # A = GUNW ascending, B = GUNW descending
    dA, cA, win, cr, gm, sp, geo_ = _unw(sa, ctx)
    if not geo_:
        raise Unsupported("Needs geocoded GUNW files.")
    dB, cB, winB, crB, gmB, spB, _ = _unw(sb, ctx, bbox=bbox_of(cr))
    dB = fit_to(dB, dA.shape)
    cB = fit_to(cB, dA.shape)
    A.set_window(out, win, cr, True, sp)
    lat = float(np.mean([p[1] for p in cr]))
    inc = math.radians(ctx.p("incidence", 39.0))
    psi_asc = math.degrees(math.asin(max(-1, min(1, math.cos(math.radians(98.4)) / math.cos(math.radians(lat))))))
    heads = {"asc": psi_asc, "desc": 180 - psi_asc}

    def vec(side, ident):
        looks_left = str(ident.get("lookDirection", "Right")).lower().startswith("l")
        az = math.radians(heads[side] + (90 if looks_left else -90))  # ground-to-satellite azimuth
        return math.sin(inc) * math.sin(az), math.cos(inc)  # east, up (north ignored)

    eA, uA = vec("asc", sa.ident)
    eB, uB = vec("desc", sb.ident)
    Mx = np.array([[eA, uA], [eB, uB]])
    det = float(np.linalg.det(Mx))
    if abs(det) < 0.05:
        raise Unsupported("The two viewing geometries are too similar to separate east-west and vertical motion.")
    inv = np.linalg.inv(Mx)
    ok = np.isfinite(dA) & np.isfinite(dB)
    east = np.where(ok, inv[0, 0] * dA + inv[0, 1] * dB, np.nan)
    up = np.where(ok, inv[1, 0] * dA + inv[1, 1] * dB, np.nan)
    M(out, "Vertical change (positive = up)", f"{nf(pct(up, 2)[0], 1)} to {nf(pct(up, 98)[0], 1)} cm (2-98%)")
    M(out, "East-west change (positive = east)", f"{nf(pct(east, 2)[0], 1)} to {nf(pct(east, 98)[0], 1)} cm (2-98%)")
    M(out, "Geometry used", f"incidence {math.degrees(inc):.0f} deg, ascending heading {heads['asc']:.1f}, descending {heads['desc']:.1f}, determinant {det:.2f}", "Nominal values, not read per pixel")
    for name, arr in (("Vertical change (cm)", up), ("East-west change (cm)", east)):
        lim = max(abs(x) for x in pct(arr, 2, 98)) or 1e-6
        IMG(out, name, render.colormap_png(arr, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "cm"}, raw=arr, gm=gm)
    out["notes"].append("A = ascending GUNW, B = descending GUNW of the same period. Assumes a positive line-of-sight change means towards the satellite and ignores the north component; flip the signs if the product uses the opposite convention. Each result is relative to its own window.")


def gcov_ascdesc(sa, sb, ctx, out):  # A = ascending, B = descending
    pol, a, b, win, cr, gm, sp = gcov_pair(sa, sb, ctx)
    A.set_window(out, win, cr, True, sp)
    da, db_ = db_of(a), db_of(b)
    diff = da - db_
    v = np.isfinite(diff)
    comb = db_of(np.where(np.isfinite(a) & np.isfinite(b), (a + b) / 2, np.where(np.isfinite(a), a, b)))
    M(out, "Difference ascending minus descending", f"median {nf(float(np.nanmedian(diff)), 2)} dB, mean absolute {nf(float(np.nanmean(np.abs(diff))), 2)} dB")
    M(out, "Pixels differing by more than 3 dB", f"{nf(A.share(np.abs(diff) > 3, v), 1)} %", "Slope direction, shadow or layover differences")
    M(out, "Valid pixels", f"ascending {nf(100 * np.isfinite(a).mean(), 1)} %, descending {nf(100 * np.isfinite(b).mean(), 1)} %, combined {nf(100 * np.isfinite(comb).mean(), 1)} %")
    lim = max(3.0, pct(np.abs(diff), 98)[0] or 1)
    IMG(out, f"{pol}: ascending minus descending (dB)", render.colormap_png(diff, -lim, lim, "diverging"), cr, True, {"min": -lim, "max": lim, "unit": "dB"}, raw=diff, gm=gm)
    lo, hi = pct(comb, 2, 98)
    IMG(out, f"{pol}: combined, gaps filled (dB)", render.colormap_png(comb, lo, hi, "gray"), cr, True, {"min": lo, "max": hi, "unit": "dB"}, raw=comb, gm=gm)
    out["notes"].append("A = ascending GCOV, B = descending GCOV. The combined image averages the two in linear power and fills pixels missing in one.")


MODES = {
    "gcov_change": ("GCOV before and after change map", ("GCOV",), ("GCOV",), "A = before, B = after", gcov_change),
    "flood": ("Flood extent and flooded area", ("GCOV",), ("GCOV",), "A = before, B = after", gcov_flood),
    "deforest": ("Deforestation and burn-scar area", ("GCOV",), ("GCOV",), "A = before, B = after (needs HV)", gcov_deforest),
    "coherence_change": ("Coherence change (damage mapping)", ("GUNW",), ("GUNW",), "A = reference pair, B = pair spanning the event", coherence_change),
    "gslc_ifg": ("Own interferogram from two GSLC", ("GSLC",), ("GSLC",), "A = first date, B = second date", gslc_ifg),
    "gslc_change": ("GSLC amplitude change detection", ("GSLC",), ("GSLC",), "A = before, B = after", gslc_change),
    "gcov_gunw": ("GCOV plus GUNW: reliable motion", ("GCOV",), ("GUNW",), "A = GCOV, B = GUNW", gcov_gunw),
    "gcov_sme2": ("GCOV plus SME2: radar vs soil moisture", ("GCOV",), ("SME2",), "A = GCOV, B = SME2", gcov_sme2),
    "goff_gunw": ("GOFF plus GUNW: fast and slow motion", ("GOFF",), ("GUNW",), "A = GOFF, B = GUNW", goff_gunw),
    "vertical_ew": ("Vertical and east-west motion", ("GUNW",), ("GUNW",), "A = ascending, B = descending", vertical_ew),
    "gcov_ascdesc": ("Ascending plus descending GCOV", ("GCOV",), ("GCOV",), "A = ascending, B = descending", gcov_ascdesc),
}
CATALOG = [{"key": k, "title": t, "a": list(a), "b": list(b), "hint": h} for k, (t, a, b, h, _) in MODES.items()]


def run(fa, fb, ctx, mode):
    if mode not in MODES:
        raise Unsupported("Unknown two-file analysis.")
    title, pa, pb, hint, fn = MODES[mode]
    sa, sb = Src(fa, pa[0]), Src(fb, pb[0])
    out = {"product": title, "identification": sa.ident, "metrics": [], "images": [], "notes": [], "window": None, "mode": mode}
    fn(sa, sb, ctx, out)
    return out
