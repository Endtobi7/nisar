"""Disaster events (earthquakes and floods) from public feeds, normalised to one shape.

Sources (no API key needed):
  USGS earthquake catalogue (FDSN), GDACS flood events, NASA EONET flood events.
Each feed is read defensively: if one fails or changes shape, the others still answer and the
failure is reported in `warnings`. Results are cached for 10 minutes.
"""
import math
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

import requests
from fastapi import APIRouter, HTTPException

router = APIRouter()

USGS_URL = os.environ.get("EVENTS_USGS_URL", "https://earthquake.usgs.gov/fdsnws/event/1/query")
GDACS_URL = os.environ.get("EVENTS_GDACS_URL", "https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH")
EONET_URL = os.environ.get("EVENTS_EONET_URL", "https://eonet.gsfc.nasa.gov/api/v3/events")
UA = {"User-Agent": "NISAR-Explorer/1.0 (events)"}
TTL = 600
_cache: dict = {}


def _get(url, params):
    key = (url, tuple(sorted(params.items())))
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < TTL:
        return hit[1]
    r = requests.get(url, params=params, headers=UA, timeout=20)
    r.raise_for_status()
    data = r.json()
    _cache[key] = (time.time(), data)
    return data


def _iso(ms: float) -> str:
    return datetime.fromtimestamp(ms / 1000, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _norm_time(s: Optional[str]) -> Optional[str]:
    """Accept '2026-08-01T00:00:00', '2026-08-01T00:00:00Z' or '2026-08-01' and return UTC ISO or None."""
    if not s or not isinstance(s, str):
        return None
    t = s.strip().replace("Z", "")
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(t, fmt).strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            continue
    return None


def _clamp_bbox(w, s, e, n):
    return [max(-180.0, w), max(-90.0, s), min(180.0, e), min(90.0, n)]


def quake_bbox(lon: float, lat: float, mag: float):
    """Area to look at for an earthquake: grows with magnitude (shaking and surface change reach further)."""
    half = min(1.6, max(0.35, 0.3 + 0.25 * max(0.0, mag - 5.0)))
    lon_half = half / max(0.2, math.cos(math.radians(lat)))
    return _clamp_bbox(lon - lon_half, lat - half, lon + lon_half, lat + half)


def _pt_bbox(lon, lat, half):
    lon_half = half / max(0.2, math.cos(math.radians(lat)))
    return _clamp_bbox(lon - lon_half, lat - half, lon + lon_half, lat + half)


def _coords_bbox(coords):
    """bbox of any GeoJSON coordinates nesting."""
    pts = []

    def walk(c):
        if c and isinstance(c[0], (int, float)):
            pts.append(c)
        else:
            for x in c or []:
                walk(x)

    walk(coords)
    pts = [p for p in pts if len(p) >= 2]
    if not pts:
        return None
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return [min(xs), min(ys), max(xs), max(ys)]


def _flood_bbox(feature_bbox, geometry):
    bb = None
    if isinstance(feature_bbox, (list, tuple)) and len(feature_bbox) == 4 and all(isinstance(v, (int, float)) for v in feature_bbox):
        bb = list(feature_bbox)
    elif geometry and geometry.get("coordinates") is not None:
        bb = _coords_bbox(geometry["coordinates"])
    if not bb:
        return None
    w, s, e, n = bb
    cx, cy = (w + e) / 2, (s + n) / 2
    if (e - w) < 0.4 or (n - s) < 0.4:  # a point or a tiny box: look at a useful area around it
        return _pt_bbox(cx, cy, 0.6)
    return _clamp_bbox(w, s, e, n)


def parse_usgs(data) -> list:
    out = []
    for f in (data or {}).get("features", []):
        try:
            p, g = f["properties"], f["geometry"]["coordinates"]
            mag = p.get("mag")
            if mag is None or p.get("time") is None:
                continue
            lon, lat = float(g[0]), float(g[1])
            out.append({
                "id": f"usgs:{f.get('id') or p.get('code')}",
                "type": "earthquake", "source": "USGS",
                "title": p.get("title") or f"M {mag} earthquake",
                "place": p.get("place") or "",
                "time": _iso(p["time"]), "end": None,
                "lat": lat, "lon": lon, "bbox": quake_bbox(lon, lat, float(mag)),
                "magnitude": float(mag),
                "severity": p.get("alert") or None,
                "depth_km": float(g[2]) if len(g) > 2 and g[2] is not None else None,
                "url": p.get("url"),
            })
        except (KeyError, TypeError, ValueError, IndexError):
            continue
    return out


def parse_gdacs(data) -> list:
    out, seen = [], set()
    for f in (data or {}).get("features", []):
        try:
            p = f.get("properties", {})
            if str(p.get("eventtype", "FL")).upper() != "FL":
                continue
            eid = str(p.get("eventid") or p.get("name") or "")
            if not eid or eid in seen:
                continue
            geom = f.get("geometry") or {}
            bb = _flood_bbox(f.get("bbox"), geom)
            if not bb:
                continue
            t = _norm_time(p.get("fromdate"))
            if not t:
                continue
            seen.add(eid)
            sev = (p.get("severitydata") or {}).get("severitytext")
            urls = p.get("url") or {}
            out.append({
                "id": f"gdacs:FL{eid}",
                "type": "flood", "source": "GDACS",
                "title": p.get("name") or p.get("eventname") or p.get("description") or "Flood",
                "place": p.get("country") or "",
                "time": t, "end": _norm_time(p.get("todate")),
                "lat": (bb[1] + bb[3]) / 2, "lon": (bb[0] + bb[2]) / 2, "bbox": bb,
                "magnitude": None,
                "severity": (p.get("alertlevel") or "").lower() or None,
                "detail": sev,
                "url": urls.get("report") or urls.get("details") if isinstance(urls, dict) else None,
            })
        except (KeyError, TypeError, ValueError):
            continue
    return out


def parse_eonet(data) -> list:
    out = []
    for ev in (data or {}).get("events", []):
        try:
            if not any(c.get("id") == "floods" for c in ev.get("categories", [])):
                continue
            geos = [g for g in ev.get("geometry", []) if g.get("coordinates") is not None and g.get("date")]
            if not geos:
                continue
            geos.sort(key=lambda g: g["date"])
            first, last = geos[0], geos[-1]
            bb = _flood_bbox(None, {"coordinates": [g["coordinates"] for g in geos]} if first.get("type") == "Point" else first)
            if not bb:
                continue
            t = _norm_time(first["date"])
            if not t:
                continue
            e = _norm_time(last["date"])
            out.append({
                "id": f"eonet:{ev.get('id')}",
                "type": "flood", "source": "NASA EONET",
                "title": ev.get("title") or "Flood",
                "place": "",
                "time": t, "end": e if e != t else None,
                "lat": (bb[1] + bb[3]) / 2, "lon": (bb[0] + bb[2]) / 2, "bbox": bb,
                "magnitude": None, "severity": None,
                "url": ev.get("link"),
            })
        except (KeyError, TypeError, ValueError, AttributeError):
            continue
    return out


def dedupe(events: list) -> list:
    """Same flood reported by two feeds: keep one (GDACS first)."""
    prio = {"GDACS": 0, "USGS": 0, "NASA EONET": 1}
    kept = []
    for e in sorted(events, key=lambda x: (prio.get(x["source"], 9), x["time"])):
        if e["type"] == "flood":
            te = datetime.strptime(e["time"], "%Y-%m-%dT%H:%M:%SZ")
            dup = any(
                k["type"] == "flood" and abs(k["lat"] - e["lat"]) < 1.5 and abs(k["lon"] - e["lon"]) < 1.5
                and abs((datetime.strptime(k["time"], "%Y-%m-%dT%H:%M:%SZ") - te).days) <= 5
                for k in kept
            )
            if dup:
                continue
        kept.append(e)
    return kept


def _day(s: str) -> str:
    try:
        return datetime.strptime(s, "%Y-%m-%d").strftime("%Y-%m-%d")
    except (TypeError, ValueError):
        raise HTTPException(400, "Dates must look like YYYY-MM-DD.")


@router.get("/api/events")
def events(types: str = "flood,earthquake", start: Optional[str] = None, end: Optional[str] = None, minmag: float = 5.0, limit: int = 200):
    want = {t.strip() for t in types.split(",") if t.strip()}
    today = datetime.now(timezone.utc)
    end_d = _day(end) if end else today.strftime("%Y-%m-%d")
    start_d = _day(start) if start else (today - timedelta(days=120)).strftime("%Y-%m-%d")
    if start_d > end_d:
        raise HTTPException(400, "The start date is after the end date.")
    end_next = (datetime.strptime(end_d, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
    found, warnings, sources = [], [], []

    if "earthquake" in want:
        try:
            data = _get(USGS_URL, {"format": "geojson", "starttime": start_d, "endtime": end_next, "minmagnitude": minmag, "orderby": "time", "limit": 500})
            found += parse_usgs(data)
            sources.append("USGS")
        except Exception as exc:  # network error, bad JSON...
            warnings.append(f"Earthquake feed (USGS) is unavailable: {type(exc).__name__}")
    if "flood" in want:
        for name, url, params, parser in (
            ("GDACS", GDACS_URL, {"eventlist": "FL", "fromdate": start_d, "todate": end_d, "alertlevel": "green;orange;red"}, parse_gdacs),
            ("NASA EONET", EONET_URL, {"category": "floods", "start": start_d, "end": end_d, "status": "all", "limit": 200}, parse_eonet),
        ):
            try:
                found += parser(_get(url, params))
                sources.append(name)
            except Exception as exc:
                warnings.append(f"Flood feed ({name}) is unavailable: {type(exc).__name__}")

    found = dedupe(found)
    found = [e for e in found if start_d <= e["time"][:10] <= end_d]
    found.sort(key=lambda e: e["time"], reverse=True)
    return {"events": found[: max(1, min(limit, 500))], "warnings": warnings, "sources": sources, "start": start_d, "end": end_d}
