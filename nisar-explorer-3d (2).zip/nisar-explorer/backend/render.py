"""Turn arrays into small PNG data-URLs (no matplotlib needed)."""
import base64
import io

import numpy as np
from PIL import Image


def _lut(stops, n=256):
    pos = np.array([s[0] for s in stops], float)
    cols = np.array([s[1:] for s in stops], float)
    x = np.linspace(0, 1, n)
    return np.stack([np.interp(x, pos, cols[:, i]) for i in range(3)], 1).astype(np.uint8)


CMAPS = {
    "gray": _lut([(0, 0, 0, 0), (1, 255, 255, 255)]),
    "viridis": _lut([(0, 68, 1, 84), (0.25, 59, 82, 139), (0.5, 33, 145, 140), (0.75, 94, 201, 98), (1, 253, 231, 37)]),
    "diverging": _lut([(0, 33, 102, 172), (0.5, 247, 247, 247), (1, 178, 24, 43)]),
    "earth": _lut([(0, 140, 81, 10), (0.5, 245, 245, 220), (1, 0, 90, 120)]),
}


def _encode(rgba, max_side=1100):
    img = Image.fromarray(rgba, "RGBA")
    if max(img.size) > max_side:
        k = max_side / max(img.size)
        img = img.resize((max(1, int(img.width * k)), max(1, int(img.height * k))), Image.BILINEAR)
    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def _norm(a, vmin, vmax):
    a = np.asarray(a, float)
    bad = ~np.isfinite(a)
    t = np.clip((a - vmin) / (vmax - vmin + 1e-12), 0, 1)
    t[bad] = 0
    return t, bad


def colormap_png(a, vmin, vmax, cmap="gray"):
    t, bad = _norm(a, vmin, vmax)
    rgb = CMAPS[cmap][(t * 255).astype(np.uint8)]
    alpha = np.where(bad, 0, 255).astype(np.uint8)
    return _encode(np.dstack([rgb, alpha]))


def rgb_png(r, g, b, ranges):
    chans, bad = [], np.zeros(np.shape(r), bool)
    for a, (lo, hi) in zip((r, g, b), ranges):
        t, m = _norm(a, lo, hi)
        chans.append((t * 255).astype(np.uint8))
        bad |= m
    alpha = np.where(bad, 0, 255).astype(np.uint8)
    return _encode(np.dstack(chans + [alpha]))


def phase_png(phase):
    """cyclic colour wheel for wrapped phase (-pi..pi)"""
    p = np.asarray(phase, float)
    bad = ~np.isfinite(p)
    h = ((np.where(bad, 0, p) + np.pi) / (2 * np.pi)) % 1.0
    i = (h * 6).astype(int) % 6
    f = h * 6 - np.floor(h * 6)
    q, t = 1 - f, f
    r = np.choose(i, [np.ones_like(h), q, np.zeros_like(h), np.zeros_like(h), t, np.ones_like(h)])
    g = np.choose(i, [t, np.ones_like(h), np.ones_like(h), q, np.zeros_like(h), np.zeros_like(h)])
    b = np.choose(i, [np.zeros_like(h), np.zeros_like(h), t, np.ones_like(h), np.ones_like(h), q])
    rgb = (np.dstack([r, g, b]) * 255).astype(np.uint8)
    alpha = np.where(bad, 0, 255).astype(np.uint8)
    return _encode(np.dstack([rgb, alpha]))


def colormap_rgba(a, vmin, vmax, cmap="gray"):
    t, bad = _norm(a, vmin, vmax)
    rgb = CMAPS[cmap][(t * 255).astype(np.uint8)]
    return np.dstack([rgb, np.where(bad, 0, 255).astype(np.uint8)])


def encode_rgba(rgba):
    return _encode(np.ascontiguousarray(rgba.astype(np.uint8)))


def class_png(codes, palette):
    """codes: int array, 0 = transparent; palette: {code: (r, g, b[, a])}"""
    c = np.asarray(codes)
    out = np.zeros(c.shape + (4,), np.uint8)
    for k, col in palette.items():
        m = c == k
        out[m, :3] = col[:3]
        out[m, 3] = col[3] if len(col) > 3 else 230
    return _encode(out)
