"""Tests for the assistant endpoint. The Anthropic call is faked: no network, no key needed."""
import pytest
from fastapi.testclient import TestClient

import nisa
from main import app

client = TestClient(app)


class FakeResp:
    def __init__(self, status=200, body=None):
        self.status_code = status
        self._body = body if body is not None else {"content": [{"type": "text", "text": "Coherence is stability."}]}

    def json(self):
        return self._body


@pytest.fixture(autouse=True)
def _reset():
    nisa._hits.clear()


def ask(**kw):
    body = {"messages": [{"role": "user", "content": "what is coherence?"}], "context": "tab: details"}
    body.update(kw)
    return client.post("/api/nisa", json=body)


def test_status_without_key(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert client.get("/api/nisa/status").json()["enabled"] is False
    assert ask().status_code == 503


def test_status_with_key(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    assert client.get("/api/nisa/status").json()["enabled"] is True


def test_reply_and_request_shape(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "secret")
    seen = {}

    def fake_post(url, headers, json, timeout):
        seen.update(url=url, headers=headers, json=json)
        return FakeResp()

    monkeypatch.setattr(nisa.requests, "post", fake_post)
    r = ask()
    assert r.status_code == 200 and r.json()["reply"] == "Coherence is stability."
    assert seen["url"] == nisa.API_URL and seen["headers"]["x-api-key"] == "secret"
    assert seen["json"]["model"] == nisa.MODEL and "CONTEXT:\ntab: details" in seen["json"]["system"]
    assert "secret" not in r.text


def test_upstream_error_is_hidden(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "secret")
    monkeypatch.setattr(nisa.requests, "post", lambda *a, **k: FakeResp(401, {"error": "bad key secret"}))
    r = ask()
    assert r.status_code == 502 and "secret" not in r.text


def test_network_error(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")

    def boom(*a, **k):
        raise nisa.requests.ConnectionError("down")

    monkeypatch.setattr(nisa.requests, "post", boom)
    assert ask().status_code == 502


def test_validation(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    monkeypatch.setattr(nisa.requests, "post", lambda *a, **k: FakeResp())
    assert ask(messages=[{"role": "assistant", "content": "hi"}]).status_code == 400
    assert ask(messages=[{"role": "user", "content": "x" * 1300}]).status_code == 422
    assert ask(context="x" * 12001).status_code == 422
    assert ask(messages=[]).status_code == 422


def test_rate_limit(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    monkeypatch.setattr(nisa.requests, "post", lambda *a, **k: FakeResp())
    monkeypatch.setattr(nisa, "MAX_PER_MINUTE", 3)
    codes = [ask().status_code for _ in range(5)]
    assert codes == [200, 200, 200, 429, 429]
