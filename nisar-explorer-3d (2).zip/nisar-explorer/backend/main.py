"""NISAR Explorer API: thin, cached wrapper around asf_search (NISAR dataset only)."""
import io
import ipaddress
import json
from collections import OrderedDict
import secrets
import socket
import time

import requests
from functools import lru_cache
from typing import Optional
from urllib.parse import urlparse

import asf_search as asf
import h5py
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel
from starlette.background import BackgroundTask

import analyse as nisar_analyse
import extras as nisar_extras
import pairs as nisar_pairs
import series as nisar_series
from geotiff import write_geotiff
from demo_data import make_demo
from rangefile import RangeFile

from nisa import router as nisa_router
from events import router as events_router

app = FastAPI(title="NISAR Explorer API")
app.include_router(nisa_router)
app.include_router(events_router)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET", "POST"], allow_headers=["*"])

PRODUCT_TYPES = ["GCOV", "GUNW", "GOFF", "GSLC", "SME2", "RSLC", "RIFG", "RUNW", "ROFF", "RRSD"]


def bbox_to_wkt(w: float, s: float, e: float, n: float) -> str:
    return f"POLYGON(({w} {s},{e} {s},{e} {n},{w} {n},{w} {s}))"


@lru_cache(maxsize=256)
def _search(wkt, start, end, levels, direction, pols, maturity, limit):
    kw = dict(dataset=asf.DATASET.NISAR, maxResults=limit)
    if wkt:
        kw["intersectsWith"] = wkt
    if start:
        kw["start"] = start
    if end:
        kw["end"] = end
    if levels:
        kw["processingLevel"] = list(levels)
    if direction:
        kw["flightDirection"] = direction
    if pols:
        kw["polarization"] = list(pols)
    if maturity:
        kw["dataMaturity"] = list(maturity)
    results = asf.geo_search(**kw)
    return results.geojson()


def _csv(v: Optional[str]):
    return tuple(x.strip() for x in v.split(",") if x.strip()) if v else ()


@app.get("/api/health")
def health():
    return {"ok": True, "product_types": PRODUCT_TYPES, "routes": sorted(r.path for r in app.routes if r.path.startswith("/api"))}


@app.get("/api/search")
def search(
    bbox: Optional[str] = Query(None, description="west,south,east,north"),
    start: Optional[str] = None,
    end: Optional[str] = None,
    level: Optional[str] = Query(None, description="comma list: GCOV,GUNW,..."),
    direction: Optional[str] = Query(None, description="ASCENDING | DESCENDING"),
    pol: Optional[str] = Query(None, description="comma list: HH,HV,VV,VH"),
    maturity: Optional[str] = Query(None, description="comma list: BETA,PROVISIONAL,VALIDATED"),
    limit: int = Query(250, ge=1, le=2000),
):
    wkt = None
    if bbox:
        try:
            w, s, e, n = (float(x) for x in bbox.split(","))
        except ValueError:
            raise HTTPException(400, "bbox must be west,south,east,north")
        wkt = bbox_to_wkt(w, s, e, n)
    try:
        return _search(wkt, start, end, _csv(level), direction, _csv(pol), _csv(maturity), limit)
    except Exception as exc:  # upstream/network errors
        raise HTTPException(502, f"ASF search failed: {exc}")


# ---------------------------------------------------------------------------
# NASA Earthdata Login (EDL): needed to DOWNLOAD NISAR files (search is public).
# Sessions live in server memory only; nothing is written to disk.
# ---------------------------------------------------------------------------
SESSIONS: dict = {}  # sid -> {"session": ASFSession, "user": str, "t": float}
SESSION_TTL = 8 * 3600
ALLOWED_HOSTS = ("asf.alaska.edu", "earthdatacloud.nasa.gov", "earthdata.nasa.gov")


class LoginIn(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None  # EDL user token from https://urs.earthdata.nasa.gov/profile


def _prune():
    now = time.time()
    for sid in [k for k, v in SESSIONS.items() if now - v["t"] > SESSION_TTL]:
        SESSIONS.pop(sid, None)


def _get(sid: str):
    _prune()
    s = SESSIONS.get(sid)
    if not s:
        raise HTTPException(401, "Not signed in to Earthdata (session expired). Sign in again.")
    s["t"] = time.time()
    return s


def _host_ok(url: str) -> bool:
    u = urlparse(url)
    h = u.hostname or ""
    return u.scheme == "https" and any(h == d or h.endswith("." + d) for d in ALLOWED_HOSTS)


@app.post("/api/login")
def login(body: LoginIn):
    session = asf.ASFSession()
    try:
        if body.token and body.token.strip():
            session.auth_with_token(body.token.strip())
            user = "token user"
        elif body.username and body.password:
            session.auth_with_creds(body.username.strip(), body.password)
            user = body.username.strip()
        else:
            raise HTTPException(400, "Provide an Earthdata username and password, or a token.")
    except HTTPException:
        raise
    except asf.ASFAuthenticationError:
        raise HTTPException(401, "Earthdata login failed. Check your credentials or token.")
    except Exception as exc:
        raise HTTPException(502, f"Could not reach Earthdata Login: {exc}")
    sid = secrets.token_urlsafe(24)
    SESSIONS[sid] = {"session": session, "user": user, "t": time.time()}
    return {"sid": sid, "user": user}


@app.get("/api/me")
def me(sid: str):
    return {"user": _get(sid)["user"]}


@app.post("/api/logout")
def logout(sid: str):
    SESSIONS.pop(sid, None)
    return {"ok": True}


@app.get("/api/download")
def download(sid: str, url: str):
    """Stream a NISAR file through the signed-in Earthdata session."""
    if not _host_ok(url):
        raise HTTPException(400, "Only ASF / Earthdata download URLs are allowed.")
    session = _get(sid)["session"]
    try:
        r = session.get(url, stream=True, timeout=60)
    except Exception as exc:
        raise HTTPException(502, f"Download failed: {exc}")
    if r.status_code in (401, 403):
        r.close()
        raise HTTPException(401, "Earthdata rejected the request. Sign in again, and make sure your account has accepted the ASF DAAC EULA at urs.earthdata.nasa.gov.")
    if not r.ok:
        r.close()
        raise HTTPException(502, f"Download server returned {r.status_code}.")
    name = urlparse(url).path.rsplit("/", 1)[-1] or "nisar-granule.h5"
    headers = {"Content-Disposition": f'attachment; filename="{name}"'}
    if r.headers.get("Content-Length"):
        headers["Content-Length"] = r.headers["Content-Length"]
    return StreamingResponse(
        r.iter_content(1 << 20),
        media_type="application/octet-stream",
        headers=headers,
        background=BackgroundTask(r.close),
    )


# ---------------------------------------------------------------------------
# Orbit (TLE from CelesTrak, cached) and browse-image proxy (avoids CORS)
# ---------------------------------------------------------------------------
NISAR_NORAD = 65053
_TLE = {"t": 0.0, "text": ""}
TLE_TTL = 2 * 3600  # CelesTrak asks clients not to poll more than every ~2 h


@app.get("/api/tle")
def tle():
    now = time.time()
    if not _TLE["text"] or now - _TLE["t"] > TLE_TTL:
        try:
            r = requests.get(
                "https://celestrak.org/NORAD/elements/gp.php",
                params={"CATNR": NISAR_NORAD, "FORMAT": "TLE"},
                timeout=20,
            )
            r.raise_for_status()
            if "\n2 " not in r.text.replace("\r", ""):
                raise ValueError("unexpected CelesTrak response")
            _TLE.update(t=now, text=r.text)
        except Exception as exc:
            if not _TLE["text"]:
                raise HTTPException(502, f"Could not fetch NISAR TLE: {exc}")
    return Response(_TLE["text"], media_type="text/plain")


def _public_https(url: str) -> bool:
    """https only, and never a private/loopback address (keeps the proxy from reaching your own network)."""
    u = urlparse(url)
    if u.scheme != "https" or not u.hostname:
        return False
    try:
        infos = socket.getaddrinfo(u.hostname, 443)
    except OSError:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return False
    return True


def _sniff_image(b: bytes):
    """ASF serves some browse PNGs as binary/octet-stream, so identify them by their first bytes."""
    if b.startswith(b"\x89PNG"):
        return "image/png"
    if b.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if b[:3] == b"GIF":
        return "image/gif"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return "image/webp"
    return None


@app.get("/api/browse")
def browse(url: str, sid: Optional[str] = None):
    """Fetch a granule browse image server-side (browse images are public; this only avoids browser CORS limits)."""
    if not _public_https(url):
        raise HTTPException(400, "Browse URL must be a public https address.")
    use_session = sid in SESSIONS and _host_ok(url)
    sess = SESSIONS[sid]["session"] if use_session else requests
    try:
        r = sess.get(url, timeout=30)
    except Exception as exc:
        raise HTTPException(502, f"Browse fetch failed: {exc}")
    ctype = r.headers.get("Content-Type", "")
    kind = ctype if ctype.startswith("image/") else _sniff_image(r.content)
    if r.ok and kind and _public_https(r.url):
        return Response(r.content, media_type=kind, headers={"Cache-Control": "public, max-age=3600"})
    if r.status_code in (401, 403) or "urs.earthdata.nasa.gov" in (urlparse(r.url).hostname or ""):
        raise HTTPException(401, "This browse image needs an Earthdata login. Sign in, then try again.")
    raise HTTPException(502, f"The image server answered HTTP {r.status_code} ({ctype or 'no content type'}).")


@app.get("/api/text")
def text(url: str):
    """Fetch a small KML/XML sidecar file (the exact map position of a browse image) without CORS trouble."""
    if not _public_https(url) or not urlparse(url).path.lower().endswith((".kml", ".xml")):
        raise HTTPException(400, "Only public https .kml or .xml files are allowed.")
    try:
        r = requests.get(url, timeout=30)
    except Exception as exc:
        raise HTTPException(502, f"Fetch failed: {exc}")
    if not r.ok or not _public_https(r.url):
        raise HTTPException(502, f"The server answered HTTP {r.status_code}.")
    if len(r.content) > 1_000_000:
        raise HTTPException(413, "File too large.")
    return Response(r.content, media_type="application/xml", headers={"Cache-Control": "public, max-age=3600"})


# ---------------------------------------------------------------------------
# Analysis: stream small windows of NISAR HDF5 files and analyse them
#   /api/analyse  one file (+ optional extra analyses)
#   /api/compare  two files
#   /api/series   many files
#   /api/pixel    value of every layer at one point
#   /api/export   GeoTIFF or CSV of a result image
# ---------------------------------------------------------------------------
_CACHE = OrderedDict()
_RAW = OrderedDict()


def _parse_bbox(bbox: Optional[str]):
    if not bbox:
        return None
    try:
        w, s, e, n = (float(x) for x in bbox.split(","))
    except ValueError:
        raise HTTPException(400, "bbox must be west,south,east,north")
    if not (w < e and s < n):
        raise HTTPException(400, "bbox is empty")
    return (w, s, e, n)


def _params(params: Optional[str]):
    if not params:
        return {}
    try:
        d = json.loads(params)
        return {str(k): v for k, v in d.items() if isinstance(v, (int, float, str))} if isinstance(d, dict) else {}
    except ValueError:
        raise HTTPException(400, "params must be JSON")


def _open(url: Optional[str], sid: Optional[str]):
    """h5py file for a real granule URL (streamed with range requests) or a demo granule (demo:LEVEL:T:DIRECTION)."""
    if url and url.startswith("demo:"):
        try:
            _, lvl, k, d = url.split(":")
            return make_demo(lvl, t=int(k), direction=d)
        except Exception:
            raise HTTPException(400, "Bad demo granule.")
    if not url or not _host_ok(url) or not urlparse(url).path.lower().endswith(".h5"):
        raise HTTPException(400, "Give the https URL of a NISAR .h5 file.")
    session = _get(sid)["session"]  # 401 if not signed in
    return h5py.File(RangeFile(session, url), "r")


def _close(f):
    try:
        f.close()
    except Exception:
        pass


def _guard(fn):
    """run an analysis and turn expected failures into clear HTTP errors"""
    try:
        return fn()
    except HTTPException:
        raise
    except (nisar_analyse.Unsupported, ValueError) as exc:
        raise HTTPException(422, str(exc))
    except PermissionError as exc:
        raise HTTPException(401, str(exc))
    except Exception as exc:
        raise HTTPException(502, f"Could not read the file: {exc}")


def _store(key, result):
    raw = result.pop("_raw", {})
    result["rid"] = secrets.token_urlsafe(8)
    _RAW[result["rid"]] = raw
    _CACHE[key] = result
    while len(_RAW) > 12:
        _RAW.popitem(last=False)
    while len(_CACHE) > 12:
        _CACHE.popitem(last=False)
    return result


def _cached(key):
    if key in _CACHE and _CACHE[key]["rid"] in _RAW:
        _CACHE.move_to_end(key)
        return _CACHE[key]
    return None


def _ctx(bbox, baseline_days, max_px, want, params):
    return nisar_analyse.Ctx(bbox=_parse_bbox(bbox), max_px=max_px, baseline_days=baseline_days,
                             want=tuple(x for x in (want or "").split(",") if x), params=_params(params))


@app.get("/api/catalog")
def catalog():
    return {"extras": nisar_extras.CATALOG, "pairs": nisar_pairs.CATALOG, "series": nisar_series.CATALOG}


@app.get("/api/analyse")
def analyse_granule(
    url: Optional[str] = None, sid: Optional[str] = None, bbox: Optional[str] = None, level: Optional[str] = None,
    baseline_days: float = Query(12.0, gt=0, le=3650), max_px: int = Query(1200, ge=100, le=3000),
    want: str = "", params: str = "", demo: bool = False,
):
    url = url or ("demo:%s:0:Ascending" % (level or "GCOV") if demo else None)
    key = ("one", url, bbox, level, baseline_days, max_px, want, params)
    hit = _cached(key)
    if hit:
        return hit
    ctx = _ctx(bbox, baseline_days, max_px, want, params)

    def go():
        f = _open(url, sid)
        try:
            return nisar_analyse.run(f, ctx, level)
        finally:
            _close(f)

    result = _guard(go)
    result["demo"] = bool(url and url.startswith("demo:"))
    return _store(key, result)


@app.get("/api/compare")
def compare_granules(
    url_a: str, url_b: str, mode: str, sid: Optional[str] = None, bbox: Optional[str] = None,
    baseline_days: float = Query(12.0, gt=0, le=3650), max_px: int = Query(800, ge=100, le=2000), params: str = "",
):
    key = ("pair", url_a, url_b, mode, bbox, baseline_days, max_px, params)
    hit = _cached(key)
    if hit:
        return hit
    ctx = _ctx(bbox, baseline_days, max_px, "", params)

    def go():
        fa = _open(url_a, sid)
        try:
            fb = _open(url_b, sid)
            try:
                return nisar_pairs.run(fa, fb, ctx, mode)
            finally:
                _close(fb)
        finally:
            _close(fa)

    result = _guard(go)
    result["demo"] = url_a.startswith("demo:")
    return _store(key, result)


@app.get("/api/series")
def series_granules(
    urls: str, times: str, mode: str, sid: Optional[str] = None, bbox: Optional[str] = None,
    baseline_days: float = Query(12.0, gt=0, le=3650), max_px: int = Query(400, ge=100, le=1200), params: str = "",
):
    ul, tl = [u for u in urls.split(",") if u], [t for t in times.split(",") if t]
    if len(ul) != len(tl):
        raise HTTPException(400, "urls and times must have the same length")
    key = ("series", urls, times, mode, bbox, baseline_days, max_px, params)
    hit = _cached(key)
    if hit:
        return hit
    ctx = _ctx(bbox, baseline_days, max_px, "", params)
    ctx.default_px = 300

    def go():
        return nisar_series.run([lambda u=u: _open(u, sid) for u in ul], tl, ctx, mode)

    result = _guard(go)
    result["demo"] = bool(ul and ul[0].startswith("demo:"))
    return _store(key, result)


@app.get("/api/pixel")
def pixel(url: str, lon: float, lat: float, sid: Optional[str] = None, level: Optional[str] = None):
    """Value of every layer of the product at one longitude/latitude (tiny remote reads)."""
    def go():
        f = _open(url, sid)
        try:
            sci = f["science"]
            band = "LSAR" if "LSAR" in sci else next(iter(sci))
            prods = [k for k in nisar_analyse.KNOWN if k in sci[band]]
            prod = level if level in prods else (prods[0] if prods else None)
            if not prod:
                raise nisar_analyse.Unsupported("Unrecognised NISAR product layout.")
            idx = nisar_analyse.build_index(sci[band][prod])
            geos, rows = {}, []
            for path, ds in idx.items():
                if len(ds.shape) != 2:
                    continue
                grp = path.rsplit("/", 1)[0]
                if grp not in geos:
                    try:
                        geos[grp] = nisar_analyse.Geo(f, path)
                    except nisar_analyse.Unsupported:
                        geos[grp] = None
                g = geos[grp]
                if g is None:
                    continue
                from pyproj import Transformer
                x, y = Transformer.from_crs(4326, g.epsg, always_xy=True).transform(lon, lat)
                dx, dy = abs(g.x[1] - g.x[0]), abs(g.y[1] - g.y[0])
                if not (g.x.min() - dx <= x <= g.x.max() + dx and g.y.min() - dy <= y <= g.y.max() + dy):
                    raise nisar_analyse.Unsupported("That point is outside this granule.")
                c, r = int(abs(g.x - x).argmin()), int(abs(g.y - y).argmin())
                v = nisar_analyse.to_cx(ds[r:r + 1, c:c + 1])[0, 0]
                name = path.rsplit("/", 1)[-1]
                if np_iscomplex(v):
                    rows.append({"layer": name + " (amplitude)", "value": float(abs(v))})
                    rows.append({"layer": name + " (phase, rad)", "value": float(__import__("cmath").phase(v))})
                else:
                    val = float(v)
                    rows.append({"layer": name, "value": val if val == val else None, "db": (10 * __import__("math").log10(val) if name in ("HHHH", "HVHV", "VVVV", "VHVH") and val > 0 else None)})
            return {"product": prod, "lon": lon, "lat": lat, "layers": rows[:40]}
        finally:
            _close(f)

    return _guard(go)


def np_iscomplex(v):
    return isinstance(v, complex) or getattr(v, "dtype", None) is not None and v.dtype.kind == "c"


@app.get("/api/export")
def export_image(rid: str, image: str, fmt: str = "geotiff"):
    raw = _RAW.get(rid, {}).get(image)
    if raw is None:
        raise HTTPException(404, "That result is no longer available (the backend keeps the last few). Run the analysis again.")
    a, gm = raw["a"], raw["gm"]
    safe = "".join(c if c.isalnum() else "_" for c in image)[:60]
    if fmt == "geotiff":
        if not gm:
            raise HTTPException(422, "This image is in radar geometry and has no map coordinates.")
        return Response(write_geotiff(a, gm), media_type="image/tiff", headers={"Content-Disposition": f'attachment; filename="{safe}.tif"'})
    if fmt == "csv":
        import numpy as np
        h, w = a.shape
        step = max(1, int(np.ceil(np.sqrt(h * w / 200000))))
        rr, cc = np.mgrid[0:h:step, 0:w:step]
        vals = a[::step, ::step]
        ok = np.isfinite(vals)
        buf = io.StringIO()
        if gm:
            from pyproj import Transformer
            x = gm["left"] + (cc[ok] + 0.5) * gm["dx"]
            y = gm["top"] - (rr[ok] + 0.5) * gm["dy"]
            lon, lat = Transformer.from_crs(gm["epsg"], 4326, always_xy=True).transform(x, y)
            buf.write("longitude,latitude,value\n")
            buf.writelines(f"{lo:.6f},{la:.6f},{v:.6g}\n" for lo, la, v in zip(lon, lat, vals[ok]))
        else:
            buf.write("row,column,value\n")
            buf.writelines(f"{r},{c},{v:.6g}\n" for r, c, v in zip(rr[ok], cc[ok], vals[ok]))
        return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{safe}.csv"'})
    raise HTTPException(400, "fmt must be geotiff or csv")
