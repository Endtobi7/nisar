"""End-to-end test of every endpoint using demo granules (demo:LEVEL:T:DIRECTION)."""
import io, csv
from fastapi.testclient import TestClient
import numpy as np, rasterio, tempfile, os
import main

c = TestClient(main.app)
cat = c.get("/api/catalog").json()
print("catalog:", {k: len(v) if isinstance(v, list) else {p: len(x) for p, x in v.items()} for k, v in cat.items()}["pairs"], "pair modes,", len(cat["series"]), "series modes")

def show(tag, r, n=3):
    j = r.json()
    if r.status_code != 200:
        print(f"{tag:18} {r.status_code} {j.get('detail')}"); return j
    print(f"{tag:18} 200 metrics={len(j['metrics'])} images={len(j['images'])} series={len(j.get('series', []))} :: " + " | ".join(f"{m['label']}: {m['value']}" for m in j['metrics'][:n]))
    return j

d = lambda lvl, t, dr="Ascending": f"demo:{lvl}:{t}:{dr}"
print("--- two files")
pairs = {
 "gcov_change": (d("GCOV",0), d("GCOV",5)), "flood": (d("GCOV",0), d("GCOV",5)), "deforest": (d("GCOV",0), d("GCOV",5)),
 "coherence_change": (d("GUNW",0), d("GUNW",4)), "gslc_ifg": (d("GSLC",0), d("GSLC",3)),
 "gcov_gunw": (d("GCOV",0), d("GUNW",0)), "gcov_sme2": (d("GCOV",0), d("SME2",0)), "goff_gunw": (d("GOFF",2), d("GUNW",2)),
 "vertical_ew": (d("GUNW",3), d("GUNW",3,"Descending")), "gcov_ascdesc": (d("GCOV",0), d("GCOV",0,"Descending")),
}
res = {}
for mode, (a, b) in pairs.items():
    res[mode] = show(mode, c.get("/api/compare", params={"url_a": a, "url_b": b, "mode": mode}), 2)
print("--- series")
ids = [d("GCOV", k) for k in range(7)]; times = [f"2026-07-{1+k*12:02d}T18:00:00Z" if k < 2 else f"2026-0{8+(k-2)//2}-{(k%2)*12+3:02d}T18:00:00Z" for k in range(7)]
ts = [f"2026-06-17T18:00:00Z", "2026-06-29T18:00:00Z", "2026-07-11T18:00:00Z", "2026-07-23T18:00:00Z", "2026-08-04T18:00:00Z", "2026-08-16T18:00:00Z", "2026-08-28T18:00:00Z"]
for mode, lvl in [("gcov_ts","GCOV"),("first_change","GCOV"),("temporal_avg","GCOV"),("coh_series","GUNW"),("velocity","GUNW"),("speed_series","GOFF"),("sme_anomaly","SME2")]:
    r = c.get("/api/series", params={"urls": ",".join(d(lvl, k) for k in range(7)), "times": ",".join(ts), "mode": mode})
    res[mode] = show(mode, r, 2)
print("--- pixel / export")
r = c.get("/api/pixel", params={"url": d("GCOV", 0), "lon": -7.6, "lat": 33.62}); print("pixel", r.status_code, [(x["layer"], round(x["value"], 4) if x["value"] is not None else None) for x in r.json().get("layers", [])][:5] if r.status_code == 200 else r.json())
r = c.get("/api/pixel", params={"url": d("GCOV", 0), "lon": 10, "lat": 10}); print("pixel outside", r.status_code, r.json().get("detail"))
j = c.get("/api/analyse", params={"url": d("GUNW", 0), "want": "all"}).json()
r = c.get("/api/export", params={"rid": j["rid"], "image": "Line-of-sight change (cm)", "fmt": "geotiff"}); print("geotiff", r.status_code, len(r.content))
pth = os.path.join(tempfile.mkdtemp(), "x.tif"); open(pth, "wb").write(r.content)
with rasterio.open(pth) as ds: print("  rasterio:", ds.crs, ds.shape, round(float(np.nanmin(ds.read(1))), 2), round(float(np.nanmax(ds.read(1))), 2))
r = c.get("/api/export", params={"rid": j["rid"], "image": "Line-of-sight change (cm)", "fmt": "csv"}); rows = list(csv.reader(io.StringIO(r.text))); print("csv", r.status_code, len(rows), rows[:2])
print("export unknown", c.get("/api/export", params={"rid": "zzz", "image": "x"}).status_code)
print("bad bbox", c.get("/api/compare", params={"url_a": d("GCOV",0), "url_b": d("GCOV",1), "mode": "flood", "bbox": "-9,30,-8.9,30.1"}).json().get("detail"))
print("mismatch", c.get("/api/compare", params={"url_a": d("GCOV",0), "url_b": d("GUNW",0), "mode": "flood"}).json().get("detail"))
