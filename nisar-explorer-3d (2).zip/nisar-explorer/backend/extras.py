"""Optional extra analyses, run on top of the base analysis of each product (selected by key)."""
import math
import os

import numpy as np
from PIL import Image, ImageDraw
from pyproj import Transformer
from scipy import ndimage as ndi

import analyse as A
import render

LAM = A.LAMBDA
M, IMG, nf, pct = A.M, A.IMG, A.nf, A.pct


# ---------- helpers ----------
def _ll(gm, rows, cols):
    tr = Transformer.from_crs(gm["epsg"], 4326, always_xy=True)
    x = gm["left"] + (np.asarray(cols, float) + 0.5) * gm["dx"]
    y = gm["top"] - (np.asarray(rows, float) + 0.5) * gm["dy"]
    lon, lat = tr.transform(x, y)
    return lon, lat


def _pix(gm, lon, lat):
    x, y = Transformer.from_crs(4326, gm["epsg"], always_xy=True).transform(lon, lat)
    return (gm["top"] - y) / gm["dy"] - 0.5, (x - gm["left"]) / gm["dx"] - 0.5  # row, col


def _area(n, d):
    gm = d.get("gm")
    return f"{n * gm['dx'] * gm['dy'] / 1e6:.2f} km2" if gm else f"{int(n)} pixels"


def _where(d, rr, cc):
    if d.get("gm"):
        lon, lat = _ll(d["gm"], [rr], [cc])
        return f"{float(lat[0]):.4f}, {float(lon[0]):.4f}"
    return f"row {int(rr)}, column {int(cc)}"


def _otsu(v):
    lo, hi = np.percentile(v, [1, 99])
    hist, edges = np.histogram(v, bins=256, range=(lo, hi))
    c = (edges[:-1] + edges[1:]) / 2
    w0 = np.cumsum(hist).astype(float)
    w1 = w0[-1] - w0
    s = np.cumsum(hist * c)
    mu0 = s / np.maximum(w0, 1)
    mu1 = (s[-1] - s) / np.maximum(w1, 1)
    between = w0 * w1 * (mu0 - mu1) ** 2
    k = int(np.argmax(between))
    total_var = np.var(v)
    eta = float(between[k] / (w0[-1] ** 2 * total_var + 1e-12))
    return float(c[k]), eta


# Calm open water is very dark at L-band, and rough or smooth bare ground can be nearly as dark. Two limits are used:
#   core  : a pixel this dark is a water SEED (very likely water)
#   grow  : water spreads from seeds into connected pixels below this (water edges and mixed pixels are brighter)
# A grown region is kept only if it is dark through and through (at least half of its pixels below `core`), and is at
# least `min_px` pixels big. There is NO smoothing or morphological opening, so rivers only a few pixels wide survive.
# Cross-pol is darker everywhere, so it has its own limits. These are rules of thumb, not NASA values: calibrate them
# on a scene you know with validate.py, or change them with the parameters water_core_db and water_grow_db.
WATER_CORE_DB = {"co": -20.0, "cross": -27.0}
WATER_GROW_DB = {"co": -17.0, "cross": -24.0}
WATER_MIN_PX = 4
WATER_DARK_FRAC = 0.5


def water_limits(ctx, pol):
    k = "cross" if str(pol).upper() in ("HV", "VH") else "co"
    core = ctx.p("water_core_db", WATER_CORE_DB[k])
    grow = max(ctx.p("water_grow_db", WATER_GROW_DB[k]), core)
    return float(core), float(grow)


def water_regions(db, core, grow, min_px=WATER_MIN_PX, dark_frac=WATER_DARK_FRAC):
    """boolean water mask from a dB image (see the notes above)"""
    ok = np.isfinite(db)
    cand = ok & (db < grow)
    lab, n = ndi.label(cand, structure=np.ones((3, 3)))
    if n == 0:
        return np.zeros(db.shape, bool)
    idx = np.arange(1, n + 1)
    size = ndi.sum(cand, lab, idx)
    dark = ndi.sum(ok & (db < core), lab, idx)
    keep = (size >= min_px) & (dark / np.maximum(size, 1) >= dark_frac)
    return np.isin(lab, idx[keep])


def region_report(mask, db, d, top=5):
    """the biggest water regions: size, mean dB, how slender (river-like) or compact (lake-like) and position.
    slenderness = area / (2 x widest inscribed radius)^2: about 1 for a lake, 6 or more for a river, even a winding one"""
    lab, n = ndi.label(mask, structure=np.ones((3, 3)))
    if n == 0:
        return []
    idx = np.arange(1, n + 1)
    size = ndi.sum(mask, lab, idx)
    boxes = ndi.find_objects(lab)
    rows = []
    for j in np.argsort(-size)[:top]:
        sl = boxes[j]
        reg = np.pad(lab[sl] == idx[j], 1)
        width = 2.0 * float(ndi.distance_transform_edt(reg).max())
        r, c = np.nonzero(lab == idx[j])
        rows.append(dict(px=int(size[j]), mean_db=float(np.nanmean(db[lab == idx[j]])), slender=float(size[j]) / max(width, 1.0) ** 2,
                         width_px=width, where=_where(d, float(r.mean()), float(c.mean()))))
    return rows


def _smooth_db(lin, k=3):
    """k x k mean of linear power (NaN-aware), then dB: reduces speckle before thresholding"""
    ok = np.isfinite(lin)
    num = ndi.uniform_filter(np.where(ok, lin, 0.0), k)
    den = ndi.uniform_filter(ok.astype(float), k)
    m = np.where(ok & (den > 0.5), num / np.maximum(den, 1e-12), np.nan)
    return 10 * np.log10(np.where(m > 0, m, np.nan))


def _img(out, d, name, png, legend, raw=None):
    IMG(out, name, png, d.get("cr"), d.get("geo"), legend, raw=raw, gm=d.get("gm"))


def _series(out, name, x, y, xl, yl):
    out.setdefault("series", []).append({"name": name, "x": [float(v) for v in x], "y": [float(v) for v in y], "xlabel": xl, "ylabel": yl})


# ---------- GCOV ----------


def dem_slope(path, gm, shape):
    """Terrain slope in degrees on the analysis grid, from a DEM GeoTIFF (any CRS and resolution).
    NISAR GCOV has no slope layer, so this needs your own DEM (for example Copernicus GLO-30)."""
    import rasterio
    from rasterio.transform import Affine
    from rasterio.warp import Resampling, reproject
    tr = Affine(gm["dx"], 0, gm["left"], 0, -gm["dy"], gm["top"])
    z = np.full(shape, np.nan, dtype="float64")
    with rasterio.open(path) as src:
        reproject(rasterio.band(src, 1), z, src_transform=src.transform, src_crs=src.crs, src_nodata=src.nodata,
                  dst_transform=tr, dst_crs=f"EPSG:{gm['epsg']}", dst_nodata=np.nan, resampling=Resampling.bilinear)
    gy, gx = np.gradient(z, gm["dy"], gm["dx"])
    return np.degrees(np.arctan(np.hypot(gx, gy)))


def terrain_steep(ctx, gm, shape):
    """(boolean mask of pixels steeper than max_slope, text for the result) - or (None, None) if no DEM was given.
    Water almost never lies on steep ground, while radar shadow and layover (which look like water) do."""
    path = str(ctx.p("dem", "") or "")
    if not path or not gm:
        return None, None
    # the server opens this path: accept only an existing local GeoTIFF (no URLs, no other file types)
    if "://" in path or not path.lower().endswith((".tif", ".tiff")) or not os.path.isfile(path):
        raise A.Unsupported("The DEM must be the path of an existing local .tif or .tiff file.")
    lim = ctx.p("max_slope", 10.0)
    sl = dem_slope(path, gm, shape)
    steep = np.isfinite(sl) & (sl > lim)
    known = 100.0 * float(np.isfinite(sl).mean())
    return steep, f"slope above {lim:g} degrees (DEM covers {nf(known, 0)} % of the window)"


def _gmm2(v, iters=80):
    """two-component Gaussian mixture of a 1-D sample (EM). Returns (means, stds, weights) sorted by mean."""
    rng = np.random.default_rng(0)
    x = v if v.size <= 60000 else rng.choice(v, 60000, replace=False)
    m = np.percentile(x, [15, 75]).astype(float)
    s = np.full(2, max(float(x.std()) / 2.0, 0.3))
    w = np.array([0.3, 0.7])
    for _ in range(iters):
        p = w * np.exp(-0.5 * ((x[:, None] - m) / s) ** 2) / s
        r = p / np.maximum(p.sum(1, keepdims=True), 1e-300)
        nk = np.maximum(r.sum(0), 1e-9)
        w = nk / len(x)
        m = (r * x[:, None]).sum(0) / nk
        s = np.maximum(np.sqrt((r * (x[:, None] - m) ** 2).sum(0) / nk), 0.3)
    o = np.argsort(m)
    return m[o], s[o], w[o]


def adaptive_water(db, strict):
    """A second, clearly UNCERTAIN layer: water brighter than the fixed limits (wind-roughened lakes; NISAR GCOV is
    gamma-0, which reads about 1-2 dB brighter than sigma-0 over water). It looks for a separate dark class in the
    scene's own histogram with a two-component mixture, and only trusts it if the components are clearly separate
    (Ashman's D above 2: every lake tested scores 2.6 or more, land with a wide spread of backscatter scores 1.4 or less), the dark one is darker than -15 dB and fairly homogeneous
    (std 3 dB at most) and makes up 0.5 % to 60 % of the scene. Regions must be at least 100 pixels and dark through
    and through. Returns (mask without the strict water, split dB, gap dB) or None."""
    v = db[np.isfinite(db)]
    if v.size < 500:
        return None
    (m0, m1), (s0, s1), (w0, w1) = _gmm2(v)
    gap = float(m1 - m0)
    D = math.sqrt(2.0) * gap / math.sqrt(s0 ** 2 + s1 ** 2)
    if not (D >= 2.0 and gap >= 3.0 and m0 <= -15.0 and s0 <= 3.0 and 0.005 <= w0 <= 0.6):
        return None
    grid = np.linspace(m0, m1, 400)
    d0 = w0 * np.exp(-0.5 * ((grid - m0) / s0) ** 2) / s0
    d1 = w1 * np.exp(-0.5 * ((grid - m1) / s1) ** 2) / s1
    T = float(grid[int(np.argmin(np.abs(d0 - d1)))])           # where the two classes are equally likely
    m = water_regions(db, T, T + 1.5, min_px=100, dark_frac=0.7) & ~strict
    return m, T, gap


def gcov_water(out, ctx, d):
    ref = d["ref"]
    db = d["db"][ref]                                   # per-pixel dB: no smoothing, so thin rivers are not blurred away
    v = A.finite(db)
    if v.size < 200:
        out["notes"].append("Water map: too few valid pixels.")
        return
    core, grow = water_limits(ctx, ref)
    keep = water_regions(db, core, grow, int(ctx.p("water_min_px", WATER_MIN_PX)))
    valid = np.isfinite(db)
    steep, steep_txt = terrain_steep(ctx, d.get("gm"), db.shape)
    if steep is not None:
        before = int(keep.sum())
        keep = keep & ~steep
        M(out, "Excluded as steep terrain", f"{nf(100.0 * (before - int(keep.sum())) / max(before, 1), 1)} % of the dark pixels", steep_txt)
    p1, p5, p50 = (float(x) for x in np.nanpercentile(v, [1, 5, 50]))
    M(out, "Automatic water threshold", f"seed below {nf(core, 0)} dB, growth below {nf(grow, 0)} dB ({ref})",
      f"Fixed physical limits (change with water_core_db / water_grow_db). This scene: darkest 1 % {nf(p1, 1)} dB, 5 % {nf(p5, 1)} dB, median {nf(p50, 1)} dB")
    n_bodies = int(ndi.label(keep, structure=np.ones((3, 3)))[1])
    M(out, "Water share", f"{nf(A.share(keep, valid), 1)} %")
    M(out, "Water area", _area(int(keep.sum()), d))
    M(out, "Water bodies", str(n_bodies))
    for i, r in enumerate(region_report(keep, db, d), 1):
        shape = f"long and thin, about {nf(r['width_px'], 0)} px wide (river-like)" if r["slender"] >= 6 else "compact (lake-like)"
        M(out, f"Water region {i}", f"{_area(r['px'], d)}, mean {nf(r['mean_db'], 1)} dB, {shape}", f"at {r['where']}")
    _img(out, d, "Water map", render.class_png(keep.astype(int), {1: (31, 119, 180, 210)}), None, raw=keep.astype(float))
    ad = adaptive_water(db, keep)
    if ad is not None and ad[0].any():
        pm, pT, pgap = ad
        if steep is not None:
            pm = pm & ~steep
        M(out, "Possible water (uncertain)", f"{nf(A.share(pm, valid), 1)} % of the window, {_area(int(pm.sum()), d)}",
          f"Brighter than the usual water limit: the scene itself has a dark class below {nf(pT, 1)} dB, {nf(pgap, 1)} dB darker than the rest. Wind-roughened water looks like this, and so can dry smooth ground: check it")
        _img(out, d, "Possible water (uncertain)", render.class_png(pm.astype(int), {1: (255, 170, 40, 190)}), None, raw=pm.astype(float))
    if n_bodies == 0 and not (ad is not None and ad[0].any()):
        out["notes"].append(f"Water map: no open water found in this window. The darkest 1 % of pixels is {nf(p1, 1)} dB and the median {nf(p50, 1)} dB; water is only mapped below {nf(grow, 0)} dB (seed {nf(core, 0)} dB). If you know there is water here and it is brighter (wind, or a wide lake in a windy area), raise both limits toward the darkest values listed, for example seed {nf(p1 + 2, 0)} and growth {nf(p1 + 4, 0)}, then check the result against an optical image.")
    out["notes"].append(f"Water map: a feature narrower than about 3 pixels (about {nf(3 * d['gm']['dx'] if d.get('gm') else 0, 0)} m here) is mixed with its banks and cannot be mapped reliably. Smooth or bare dry ground can be as dark as water at L-band: check regions against an optical image, give a DEM to exclude steep terrain, or calibrate the limits with validate.py.")


def gcov_landcover(out, ctx, d):
    ref = d["ref"]
    # cluster speckle-smoothed values: raw single pixels differ mostly by speckle, which would create fake dark/bright classes
    db = {k: _smooth_db(v) for k, v in d["lin"].items()}
    feats = [db[ref]]
    cross = "HV" if "HV" in db else "VH" if "VH" in db else None
    if cross:
        feats += [db[cross], db[cross] - db[ref]]
    X = np.stack([f.ravel() for f in feats], 1)
    ok = np.all(np.isfinite(X), 1)
    if ok.sum() < 500:
        out["notes"].append("Land-cover groups: too few valid pixels.")
        return
    k = max(2, min(8, ctx.p("kclusters", 5)))
    Z = (X[ok] - X[ok].mean(0)) / (X[ok].std(0) + 1e-9)
    rng = np.random.default_rng(1)
    S = Z[rng.choice(len(Z), min(40000, len(Z)), replace=False)]
    cen = S[np.argsort(S[:, 0])[np.linspace(0, len(S) - 1, k).astype(int)]].copy()
    for _ in range(20):
        lab = ((S[:, None, :] - cen[None]) ** 2).sum(2).argmin(1)
        for j in range(k):
            if (lab == j).any():
                cen[j] = S[lab == j].mean(0)
    full = np.concatenate([((Z[i:i + 200000, None, :] - cen[None]) ** 2).sum(2).argmin(1) for i in range(0, len(Z), 200000)])
    order = np.argsort(cen[:, 0])  # darkest first
    rank = np.empty(k, int)
    rank[order] = np.arange(1, k + 1)
    codes = np.zeros(X.shape[0], int)
    codes[ok] = rank[full]
    codes = codes.reshape(db[ref].shape)
    pal = [(31, 119, 180), (140, 86, 75), (188, 189, 34), (44, 160, 44), (214, 39, 40), (148, 103, 189), (227, 119, 194), (127, 127, 127)]
    for r in range(1, k + 1):
        m = codes == r
        mean_ref = float(np.nanmean(db[ref][m])) if m.any() else float("nan")
        hint = (" (darkest: water-like or smooth)" if mean_ref <= WATER_GROW_DB["co"] else " (darkest)") if r == 1 else \
               (" (brightest: built-up or steep slopes)" if mean_ref >= -6.0 else " (brightest)") if r == k else ""
        extra = f", {cross} {nf(float(np.nanmean(db[cross][m])), 1)} dB" if cross else ""
        M(out, f"Class {r}{hint}", f"{nf(100 * m.sum() / ok.sum(), 1)} % - {_area(int(m.sum()), d)} - {ref} {nf(float(np.nanmean(db[ref][m])), 1)} dB{extra}")
    _img(out, d, f"Land-cover groups (k={k})", render.class_png(codes, {r: pal[r - 1] for r in range(1, k + 1)}), None)
    out["notes"].append("Land-cover groups are unsupervised radar classes, not verified land cover. Validate with optical data.")






def gcov_decomp(out, ctx, d):
    idx, f, win, lin = d["idx"], d["f"], d["win"], d["lin"]
    hv = A.pick(idx, "HHVV", prefer=("frequencyA",))
    if not hv or not all(k in lin for k in ("HH", "VV", "HV")):
        out["notes"].append("Decomposition needs a quad-pol file (HHHH, VVVV, HVHV and HHVV). This file does not have them.")
        return
    C11, C33, S = lin["HH"], lin["VV"], lin["HV"]
    C13 = A.read(f, hv, win).astype(np.complex128)
    with np.errstate(all="ignore"):
        fv = 3 * S
        c11, c33, c13 = C11 - fv, C33 - fv, C13 - fv / 3
        den1 = c11 + c33 + 2 * c13.real
        fd1 = (c11 * c33 - np.abs(c13) ** 2) / den1
        fs1 = c33 - fd1
        b2 = np.maximum((c11 - fd1) / fs1, 0)
        ps1, pd1 = fs1 * (1 + b2), 2 * fd1
        den2 = c11 + c33 - 2 * c13.real
        fs2 = (c11 * c33 - np.abs(c13) ** 2) / den2
        fd2 = c33 - fs2
        a2 = np.maximum((c11 - fs2) / fd2, 0)
        ps2, pd2 = 2 * fs2, fd2 * (1 + a2)
        surf = c13.real >= 0
        Ps, Pd, Pv = np.where(surf, ps1, ps2), np.where(surf, pd1, pd2), 8 * fv / 3
        bad = (c11 <= 0) | (c33 <= 0) | ~np.isfinite(Ps) | ~np.isfinite(Pd)
        Ps, Pd = np.where(bad, 0, np.maximum(Ps, 0)), np.where(bad, 0, np.maximum(Pd, 0))
        tot = Ps + Pd + Pv
        valid = np.isfinite(tot) & (tot > 0)
        fs_, fd_, fv_ = Ps / tot, Pd / tot, Pv / tot
    dom = np.argmax(np.stack([np.where(valid, fs_, -1), np.where(valid, fd_, -1), np.where(valid, fv_, -1)]), 0)
    M(out, "Surface scattering", f"{nf(100 * float(np.nanmedian(fs_[valid])), 1)} % of the power (median)")
    M(out, "Double-bounce scattering", f"{nf(100 * float(np.nanmedian(fd_[valid])), 1)} % of the power (median)", "Buildings, flooded forest, tree trunks")
    M(out, "Volume scattering", f"{nf(100 * float(np.nanmedian(fv_[valid])), 1)} % of the power (median)", "Canopy")
    M(out, "Dominant mechanism", f"surface {nf(100 * np.mean(dom[valid] == 0), 1)} %, double-bounce {nf(100 * np.mean(dom[valid] == 1), 1)} %, volume {nf(100 * np.mean(dom[valid] == 2), 1)} % of pixels")
    rgb = [np.where(valid, x, np.nan) for x in (fd_, fv_, fs_)]
    png = render.rgb_png(rgb[0], rgb[1], rgb[2], [(0, 1)] * 3)
    _img(out, d, "Decomposition (R=double-bounce, G=volume, B=surface)", png, None)
    out["notes"].append("Freeman-Durden three-component decomposition on the covariance terms. It needs fully polarimetric (quad-pol) data.")


# ---------- GUNW / RUNW ----------
def unw_extremes(out, ctx, d):
    z = d["disp"]
    if d.get("coh") is not None:                       # decorrelated pixels carry garbage phase
        z = np.where(d["coh"] >= ctx.p("coh_min", 0.6), z, np.nan)
    if not np.isfinite(z).any():
        out["notes"].append("Largest change: no pixel has good enough coherence.")
        return
    f = ndi.median_filter(np.where(np.isfinite(z), z, np.nanmedian(z)), size=5)
    f = np.where(np.isfinite(z), f, np.nan)
    for name, fn in (("Largest positive change", np.nanargmax), ("Largest negative change", np.nanargmin)):
        r, c = np.unravel_index(fn(f), f.shape)
        M(out, name, f"{nf(float(f[r, c]), 1)} cm at {_where(d, r, c)}", "5x5 median-filtered; the sign follows the product's phase convention")


def unw_deform_area(out, ctx, d):
    T, cm = ctx.p("deform_cm", 2.0), ctx.p("coh_min", 0.6)
    z, coh = d["disp"], d["coh"]
    ok = np.isfinite(z) & (np.isfinite(coh) & (coh >= cm) if coh is not None else True)
    hit = ok & (np.abs(z) > T)
    M(out, f"Area moving more than {T:g} cm", _area(int(hit.sum()), d), f"Only pixels with coherence of at least {cm:g}" if coh is not None else None)
    M(out, "Share of reliable pixels that move more", f"{nf(100 * float(hit.sum()) / max(1, ok.sum()), 1)} %")
    _img(out, d, f"Moving more than {T:g} cm", render.class_png(hit.astype(int), {1: (214, 39, 40, 220)}), None, raw=hit.astype(float))


def unw_profile(out, ctx, d):
    z = np.where(np.isfinite(d["disp"]), d["disp"], np.nanmedian(d["disp"]))
    h, w = z.shape
    gm = d.get("gm")
    line = str(ctx.p("line", ""))
    if gm and line.count(",") == 3:
        lo1, la1, lo2, la2 = (float(v) for v in line.split(","))
        (r1, c1), (r2, c2) = _pix(gm, lo1, la1), _pix(gm, lo2, la2)
    elif gm:
        r1, c1, r2, c2 = h - 1, 0, 0, w - 1  # south-west to north-east corner
    else:
        r1 = r2 = h // 2
        c1, c2 = 0, w - 1
    n = int(max(20, min(300, math.hypot(r2 - r1, c2 - c1))))
    t = np.linspace(0, 1, n)
    rr, cc = r1 + (r2 - r1) * t, c1 + (c2 - c1) * t
    L = math.hypot(r2 - r1, c2 - c1) + 1e-9
    nr, nc = -(c2 - c1) / L, (r2 - r1) / L  # unit normal
    prof = np.mean([ndi.map_coordinates(z, [rr + o * nr, cc + o * nc], order=1, mode="nearest") for o in range(-2, 3)], 0)
    if gm:
        step_m = np.hypot((r2 - r1) / (n - 1) * gm["dy"], (c2 - c1) / (n - 1) * gm["dx"])
        x, xl = np.arange(n) * step_m / 1000, "distance (km)"
    else:
        x, xl = np.arange(n) * L / (n - 1), "distance (pixels)"
    _series(out, "Line-of-sight change along the line", x, prof, xl, "cm")
    M(out, "Profile", f"{nf(float(prof.min()), 1)} to {nf(float(prof.max()), 1)} cm over {nf(float(x[-1]), 1)} {xl.split('(')[1][:-1]}", "Line: drawn-box diagonal (south-west to north-east) unless a line is given")


def unw_strain(out, ctx, d):
    z = np.where(np.isfinite(d["disp"]), d["disp"], np.nanmedian(d["disp"])) / 100.0  # metres
    gm = d.get("gm")
    px = (gm["dx"] + gm["dy"]) / 2 if gm else 1.0
    g = ndi.gaussian_gradient_magnitude(z, sigma=2) / px * 1e6  # microstrain
    g = np.where(np.isfinite(d["disp"]), g, np.nan)
    lo, med, hi = pct(g, 5, 50, 95)
    unit = "microstrain" if gm else "microstrain per pixel"
    M(out, "Line-of-sight strain", f"median {nf(med, 2)}, 95th percentile {nf(hi, 2)} {unit}", "Gradient of the smoothed displacement; line-of-sight component only")
    a, b = pct(g, 2, 98)
    _img(out, d, "Strain (microstrain)", render.colormap_png(g, a, b, "viridis"), {"min": a, "max": b, "unit": "microstrain"}, raw=g)


def unw_corrections(out, ctx, d):
    names = [p for p in d["idx"] if any(k in p.rsplit("/", 1)[-1].lower() for k in ("tropo", "tide")) and "iono" not in p.lower()]
    same = [p for p in names if d["f"][p].shape == d["f"][d["path"]].shape]
    if not same:
        out["notes"].append("Corrections: the troposphere and tide layers are stored as coarse lookup tables, which this version does not interpolate." if names else "Corrections: no troposphere or tide layers in this file.")
        return

    def units(p):
        u = d["f"][p].attrs.get("units", b"")
        return (u.decode() if isinstance(u, bytes) else str(u)).strip().lower()
    use = [p for p in same if "radian" in units(p)]
    skip = [p for p in same if p not in use]
    if skip:   # the scaling and sign of a layer in other units cannot be checked here, so it is not subtracted
        out["notes"].append("Corrections: left out because their units are not radians: " + ", ".join(f"{p.rsplit('/', 1)[-1]} ({units(p) or 'no units'})" for p in skip))
    if not use:
        return
    ph = d["ph"].copy()
    for p in use:
        ph = ph - A.read(d["f"], p, d["win"]).astype(float)
    corr = (ph - np.nanmedian(ph)) * LAM / (4 * math.pi) * 100
    M(out, "Spread after troposphere and tide correction", f"{nf(float(np.nanstd(corr)), 2)} cm (before: {nf(float(np.nanstd(d['disp'])), 2)} cm)", ", ".join(p.rsplit("/", 1)[-1] for p in use))


def unw_reliable(out, ctx, d):
    cm = ctx.p("coh_min", 0.6)
    if d["coh"] is None:
        out["notes"].append("Reliable-pixel mask: no coherence layer found.")
        return
    z = np.where(d["coh"] >= cm, d["disp"], np.nan)
    M(out, f"Pixels kept (coherence of at least {cm:g})", f"{nf(100 * np.isfinite(z).sum() / max(1, np.isfinite(d['disp']).sum()), 1)} %")
    lim = max(abs(x) for x in pct(z, 2, 98)) or 1e-6
    _img(out, d, f"Change, coherence >= {cm:g} (cm)", render.colormap_png(z, -lim, lim, "diverging"), {"min": -lim, "max": lim, "unit": "cm"}, raw=z)


def unw_uncertainty(out, ctx, d):
    if d["coh"] is None:
        out["notes"].append("Uncertainty: no coherence layer found.")
        return
    L = ctx.p("looks", 20.0)
    g = np.clip(d["coh"], 0.05, 0.999)
    sd = np.sqrt((1 - g ** 2) / (2 * L * g ** 2)) * LAM / (4 * math.pi) * 100
    sd = np.where(np.isfinite(d["coh"]), sd, np.nan)
    lo, med, hi = pct(sd, 5, 50, 95)
    M(out, "Displacement uncertainty", f"median {nf(med, 2)} cm (5-95%: {nf(lo, 2)} to {nf(hi, 2)})", f"Estimated from coherence with {L:g} looks (set the number of looks if different)")
    _img(out, d, "Uncertainty (cm)", render.colormap_png(sd, 0, max(hi, 1e-6), "viridis"), {"min": 0, "max": hi, "unit": "cm"}, raw=sd)


# ---------- GOFF / ROFF ----------
def off_direction(out, ctx, d):
    a0, r0, mag = d["a0"], d["r0"], d["mag"]
    h, w = mag.shape
    B = max(8, min(h, w) // 20)
    hi = pct(mag, 98)[0] or 1.0
    img = Image.fromarray(render.colormap_rgba(mag, 0, hi, "viridis"), "RGBA")
    dr = ImageDraw.Draw(img)
    noise = float(1.4826 * np.nanmedian(np.abs(mag - np.nanmedian(mag))))
    for y in range(B // 2, h - B // 2, B):
        for x in range(B // 2, w - B // 2, B):
            sa, sr = a0[y - B // 2:y + B // 2, x - B // 2:x + B // 2], r0[y - B // 2:y + B // 2, x - B // 2:x + B // 2]
            if not np.isfinite(sa).any():
                continue
            va, vr = float(np.nanmedian(sa)), float(np.nanmedian(sr))
            m = math.hypot(va, vr)
            if m < max(noise, 1e-9):
                continue
            k = min(1.0, m / hi) * B * 0.9
            ex, ey = x + vr / m * k, y - va / m * k  # x = range, y = along-track (image frame)
            dr.line([(x, y), (ex, ey)], fill=(255, 255, 255, 255), width=1)
            dr.ellipse([ex - 1.5, ey - 1.5, ex + 1.5, ey + 1.5], fill=(255, 255, 255, 255))
    _img(out, d, "Flow arrows (x = range, y = along-track)", render.encode_rgba(np.array(img)), {"min": 0, "max": hi, "unit": "m"})
    va, vr = float(np.nanmean(a0)), float(np.nanmean(r0))
    R = math.hypot(va, vr) / (float(np.nanmean(mag)) + 1e-12)
    M(out, "Mean direction (image frame)", f"{nf(math.degrees(math.atan2(va, vr)), 0)} degrees from the range axis towards along-track", "Not rotated to north: needs the track heading")
    M(out, "Direction consistency", nf(R, 2), "1 = everything moves the same way, 0 = random")


def off_quality(out, ctx, d):
    cm = ctx.p("corr_min", 0.1)
    mag = d["mag"].copy()
    cp = A.sibling(d["path"], "correlationSurfacePeak", d["idx"])
    if cp:
        c = A.read(d["f"], cp, d["win"]).astype(float)
        if c.shape == mag.shape:
            mag = np.where(c >= cm, mag, np.nan)
    sn = next((p for p in d["idx"] if p.rsplit("/", 1)[-1].lower() in ("snr", "signaltonoiseratio") and p.rsplit("/", 1)[0] == d["path"].rsplit("/", 1)[0]), None)
    if sn:
        s = A.read(d["f"], sn, d["win"]).astype(float)
        if s.shape == mag.shape:
            mag = np.where(s >= np.nanpercentile(s, 10), mag, np.nan)
    med = ndi.median_filter(np.where(np.isfinite(mag), mag, np.nanmedian(mag)), size=5)
    sig = max(1.4826 * float(np.nanmedian(np.abs(mag - med))), 1e-9)   # a flat field must not be wiped out by a zero spread
    mag = np.where(np.abs(mag - med) > 5 * sig, np.nan, mag)
    M(out, "Pixels kept", f"{nf(100 * np.isfinite(mag).sum() / max(1, np.isfinite(d['mag']).sum()), 1)} %", f"Correlation peak of at least {cm:g}" + (", lowest 10% SNR removed" if sn else "") + ", and outliers beyond 5 sigma of the local median removed")
    hi = pct(mag, 98)[0] or 1e-6
    _img(out, d, "Relative motion, quality-masked (m)", render.colormap_png(mag, 0, hi, "viridis"), {"min": 0, "max": hi, "unit": "m"}, raw=mag)


def off_speed(out, ctx, d):
    v = d["mag"] / ctx.baseline_days * 365.25
    lo, med, hi = pct(v, 5, 50, 95)
    rs = A.noise_hf
    floor = math.sqrt(2 * math.log(20)) * math.sqrt((rs(d["a0"]) ** 2 + rs(d["r0"]) ** 2) / 2) / ctx.baseline_days * 365.25
    M(out, f"Speed over {ctx.baseline_days:g} days", f"median {nf(med, 0)} m/yr, 95th percentile {nf(hi, 0)} m/yr", f"Noise floor about {nf(floor, 0)} m/yr: speeds near or below it are noise")
    _img(out, d, "Speed (m/yr)", render.colormap_png(v, 0, max(hi, 1e-6), "viridis"), {"min": 0, "max": hi, "unit": "m/yr"}, raw=v)


# ---------- GSLC / RSLC ----------


def slc_cfar(out, ctx, d):
    I = np.nan_to_num(d["ml"])
    k = ctx.p("cfar_k", 6.0)
    big, small = 41, 11
    n_out = big * big - small * small
    sb = lambda a: ndi.uniform_filter(a, big) * big * big - ndi.uniform_filter(a, small) * small * small
    mu = sb(I) / n_out
    var = np.maximum(sb(I * I) / n_out - mu * mu, 0)
    hit = (I > mu + k * np.sqrt(var)) & (I > 3 * mu) & np.isfinite(d["ml"])
    lab, n = ndi.label(hit)
    M(out, "Bright targets detected", f"{n} (CFAR, k = {k:g})", "Two-parameter CFAR on the 3x3 averaged intensity; ships, buildings, corner reflectors")
    if n:
        idxs = np.arange(1, n + 1)
        peaks = ndi.maximum(I, lab, idxs)
        pos = ndi.maximum_position(I, lab, idxs)
        for rank, j in enumerate(np.argsort(-np.asarray(peaks))[:5], 1):  # strongest first, numbered by rank
            M(out, f"Target {rank}", f"{nf(10 * math.log10(max(float(peaks[j]), 1e-12)), 1)} dB at {_where(d, *pos[j])}")
    lo, hi = pct(d["db"], 2, 98)
    base = render.colormap_rgba(d["db"], lo, hi, "gray")
    base[ndi.binary_dilation(hit, iterations=2)] = (255, 40, 40, 255)
    _img(out, d, "Bright-target detections (red)", render.encode_rgba(base), None)




# ---------- SME2 ----------
def sme_drywet(out, ctx, d):
    a = d["arrs"][d["names"][0]]
    scale = 100.0 if np.nanmax(a) > 1.5 else 1.0
    dry, wet = ctx.p("dry", 0.15) * scale, ctx.p("wet", 0.35) * scale
    v = np.isfinite(a)
    M(out, f"Dry (below {dry:g})", f"{nf(A.share(a < dry, v), 1)} %")
    M(out, f"Wet (above {wet:g})", f"{nf(A.share(a > wet, v), 1)} %")
    codes = np.where(v & (a < dry), 1, np.where(v & (a > wet), 2, 0))
    _img(out, d, "Dry (brown) and wet (blue)", render.class_png(codes, {1: (166, 97, 26, 220), 2: (31, 119, 180, 220)}), None)


def sme_uncertainty(out, ctx, d):
    names = [p for p in d["idx"] if "uncert" in p.rsplit("/", 1)[-1].lower()]
    if not names:
        out["notes"].append("Uncertainty: no uncertainty layer found.")
        return
    a = A.read(d["f"], names[0], d["win"]).astype(float)
    a = np.where(a >= 0, a, np.nan)
    lo, med, hi = pct(a, 5, 50, 95)
    M(out, "Soil-moisture uncertainty", f"median {nf(med, 3)} (5-95%: {nf(lo, 3)} to {nf(hi, 3)})", names[0].rsplit("/", 1)[-1])
    _img(out, d, "Uncertainty", render.colormap_png(a, 0, max(hi, 1e-9), "viridis"), {"min": 0, "max": hi, "unit": ""}, raw=a)


def sme_vegcrop(out, ctx, d):
    names = [p for p in d["idx"] if any(k in p.rsplit("/", 1)[-1].lower() for k in ("vegetationwater", "croptype", "crop"))]
    if not names:
        out["notes"].append("Vegetation water content / crop type: no such layers in this file.")
        return
    for p in names[:3]:
        a = A.read(d["f"], p, d["win"])
        nm = p.rsplit("/", 1)[-1]
        v = a[np.isfinite(a.astype(float))]
        fv = A.fill_of(d["f"][p])
        if fv is not None:                       # integer layers keep their fill value (for example 255): it is not a class
            v = v[v != fv]
        u = np.unique(v)
        if a.dtype.kind in "iu" or len(u) <= 20:
            vals, cnt = np.unique(v, return_counts=True)
            for val, c in sorted(zip(vals, cnt), key=lambda t: -t[1])[:6]:
                M(out, f"{nm}: class {int(val)}", f"{nf(100 * c / v.size, 1)} % - {_area(int(c), d)}")
        else:
            lo, med, hi = pct(a.astype(float), 10, 50, 90)
            M(out, nm, f"median {nf(med, 3)} (10-90%: {nf(lo, 3)} to {nf(hi, 3)})")


# ---------- RIFG ----------
def rifg_fringe(out, ctx, d):
    z = d["z"]
    if not np.iscomplexobj(z):
        out["notes"].append("Fringe density needs the complex wrapped interferogram.")
        return
    dx = np.angle(z[:, 1:] * np.conj(z[:, :-1]))
    dy = np.angle(z[1:, :] * np.conj(z[:-1, :]))
    fr = np.hypot(np.pad(dx, ((0, 0), (0, 1)), mode="edge"), np.pad(dy, ((0, 1), (0, 0)), mode="edge")) / (2 * math.pi)
    fr = np.where(np.abs(z) > 0, fr, np.nan)
    lo, med, hi = pct(fr, 5, 50, 95)
    M(out, "Fringe density", f"median {nf(med * 100, 1)}, 95th percentile {nf(hi * 100, 1)} fringes per 100 pixels", "No unwrapping needed. Many fringes close together = steep ground-change gradient (or noise)")
    _img(out, d, "Fringe density (fringes per pixel)", render.colormap_png(fr, 0, max(hi, 1e-6), "viridis"), {"min": 0, "max": hi, "unit": "fringes/pixel"}, raw=fr)


# ---------- registry ----------
def gcov_bright(out, ctx, d):
    ref = d["ref"]
    v = A.finite(d["db"][ref])
    lim = ctx.p("bright_db", -5.0)
    M(out, f"Very bright share (above {lim:g} dB)", f"{nf(100.0 * float((v > lim).sum()) / max(v.size, 1), 2)} %", f"{ref}; built-up areas, rock and steep slopes facing the radar")


def _layer(d, name):
    p = A.pick(d["idx"], name, prefer=("frequencyA",))
    if not p:
        raise A.Unsupported(f"No {name} layer in this file.")
    return A.read(d["f"], p, d["win"]).astype(np.float64)


def gcov_sigma0(out, ctx, d):
    fac = _layer(d, "rtcGammaToSigmaFactor")
    ref = d["ref"]
    fac = np.where(np.isfinite(fac) & (fac > 0), fac, np.nan)
    s0 = d["lin"][ref] * fac
    s0db = 10 * np.log10(np.where(s0 > 0, s0, np.nan))
    M(out, "Gamma-0 to sigma-0 factor", f"median {nf(float(np.nanmedian(fac)), 2)} ({nf(10 * math.log10(float(np.nanmedian(fac))), 1)} dB)", "sigma-0 = gamma-0 x factor; sigma-0 is the darker of the two")
    M(out, f"{ref} sigma-0", f"median {nf(float(np.nanmedian(s0db)), 1)} dB", f"gamma-0 median {nf(float(np.nanmedian(d['db'][ref])), 1)} dB")
    lo, hi = A.pct(s0db, 2, 98)
    _img(out, d, f"{ref} sigma-0 (dB)", render.colormap_png(s0db, lo, hi, "gray"), {"min": lo, "max": hi, "unit": "dB"}, raw=s0db)


def gcov_texture(out, ctx, d):
    ref, k = d["ref"], 5
    x = d["lin"][ref]
    ok = np.isfinite(x)
    n = ndi.uniform_filter(ok.astype(float), k)
    m1 = ndi.uniform_filter(np.where(ok, x, 0.0), k) / np.maximum(n, 1e-9)
    m2 = ndi.uniform_filter(np.where(ok, x * x, 0.0), k) / np.maximum(n, 1e-9)
    cv = np.where(ok & (n > 0.5), np.sqrt(np.maximum(m2 - m1 * m1, 0)) / np.maximum(m1, 1e-12), np.nan)
    lo, med, hi = A.pct(cv, 5, 50, 95)
    M(out, f"{ref} texture (coefficient of variation, 5x5)", f"median {nf(med, 2)} (5-95%: {nf(lo, 2)} to {nf(hi, 2)})", "Low = smooth or homogeneous; high = mixed targets such as towns, trees and rocks")
    _img(out, d, f"{ref} texture (CV)", render.colormap_png(cv, lo, hi, "gray"), {"min": lo, "max": hi, "unit": ""}, raw=cv)
    out["notes"].append("Texture: part of the variation is speckle, which is about 1 / sqrt(looks) even on a perfectly uniform surface.")


def gcov_quality(out, ctx, d):
    shown = False
    try:
        mk = _layer(d, "mask")
        v = mk[np.isfinite(mk)].astype(int)
        n = max(v.size, 1)
        bad = int(((v == 0)).sum())
        fill = int((v == 255).sum())
        M(out, "Mask: valid", f"{nf(100.0 * float(((v >= 1) & (v <= 5)).sum()) / n, 1)} %", "Values 1 to 5 = fully focused samples (the number is the sub-swath)")
        M(out, "Mask: invalid or partly focused (0)", f"{nf(100.0 * bad / n, 1)} %")
        M(out, "Mask: outside the image (255)", f"{nf(100.0 * fill / n, 1)} %")
        sw = {int(k): int(c) for k, c in zip(*np.unique(v[(v >= 1) & (v <= 5)], return_counts=True))}
        if len(sw) > 1:
            M(out, "Sub-swaths present", ", ".join(f"{k}: {nf(100.0 * c / n, 1)} %" for k, c in sorted(sw.items())), "Radiometric steps can appear at sub-swath borders")
        shown = True
    except A.Unsupported:
        pass
    try:
        nl = _layer(d, "numberOfLooks")
        M(out, "Number of looks", f"mean {nf(float(np.nanmean(nl)), 1)}, minimum {nf(float(np.nanmin(nl)), 1)}", "Adaptive multilooking: fewer looks on steep or foreshortened terrain, so noisier pixels there")
        shown = True
    except A.Unsupported:
        pass
    if not shown:
        raise A.Unsupported("No mask or numberOfLooks layer in this file.")
    out["notes"].append("The mask (0 / 1-5 / 255) is applied to every GCOV analysis. It describes data validity, not layover or shadow: the GCOV product has no layover/shadow layer. NASA notes that the mask of the BETA products can be misaligned near image edges.")


def slc_enl(out, ctx, d):
    I = np.where(np.isfinite(d["inten"]), d["inten"], np.nan)
    b, sb = 32, 8
    best = None
    for r in range(0, I.shape[0] - b + 1, b):
        for c in range(0, I.shape[1] - b + 1, b):
            blk = I[r:r + b, c:c + b]
            if np.isfinite(blk).mean() < 0.95:
                continue
            sub = blk.reshape(b // sb, sb, b // sb, sb)
            means = np.nanmean(sub, axis=(1, 3))
            h = float(np.std(means) / max(np.mean(means), 1e-30))   # variation of the LOCAL MEAN: no texture or edges
            if best is None or h < best[0]:
                best = (h, r, c)
    if best is None:
        raise A.Unsupported("No homogeneous 32 x 32 block found.")
    _, r, c = best
    blk = I[r:r + b, c:c + b]
    enl = float(np.nanmean(blk) ** 2 / np.nanvar(blk))
    M(out, "Equivalent number of looks (most homogeneous 32 x 32 block)", nf(enl, 2), f"Block at row {r + d['win'][0]}, column {c + d['win'][2]}")
    out["notes"].append("A single-look complex image should give an ENL near 1. A clearly higher value means the block is smoother than speckle, or the image was multilooked.")


def slc_phase(out, ctx, d):
    z = d["z"].astype(np.complex128)
    ok = np.abs(z) > 0
    ph = np.where(ok, np.angle(z), np.nan)
    R = float(np.abs(np.mean(np.exp(1j * ph[ok]))))
    M(out, "Phase concentration (0 = random, 1 = identical)", nf(R, 3), "Phase of one date is random for distributed surfaces")
    _img(out, d, "Phase of one date (colour wheel)", render.phase_png(ph), {"min": -math.pi, "max": math.pi, "unit": "rad"}, raw=None)
    out["notes"].append("The phase of a single date carries no usable information by itself. It only becomes useful as the difference between two dates (interferogram).")


EXTRAS = {
    "GCOV": {"water": ("Automatic water map and area", gcov_water), "landcover": ("Land-cover groups", gcov_landcover),
             "decomp": ("Scattering decomposition (quad-pol)", gcov_decomp), "bright": ("Very bright share", gcov_bright),
             "sigma0": ("Sigma-0 conversion", gcov_sigma0), "texture": ("Texture", gcov_texture), "quality": ("Mask and number of looks", gcov_quality)},
    "UNW": {"extremes": ("Largest positive and negative change", unw_extremes), "deform_area": ("Area moving more than a limit", unw_deform_area), "profile": ("Profile along a line", unw_profile),
            "strain": ("Strain", unw_strain), "corrections": ("Troposphere and tide corrections", unw_corrections), "reliable": ("Reliable-pixel mask", unw_reliable), "uncertainty": ("Displacement uncertainty", unw_uncertainty)},
    "OFF": {"direction": ("Flow direction and arrows", off_direction), "quality": ("Offset quality mask", off_quality), "speed": ("Speed map (m/yr)", off_speed)},
    "SLC": {"cfar": ("Bright-target detection (CFAR)", slc_cfar), "enl": ("Speckle statistics (ENL)", slc_enl), "phase": ("Phase of one date", slc_phase)},
    "SME2": {"drywet": ("Dry and wet shares", sme_drywet), "uncertainty": ("Uncertainty map", sme_uncertainty), "vegcrop": ("Vegetation water content and crop type", sme_vegcrop)},
    "RIFG": {"fringe": ("Fringe density", rifg_fringe)},
}
FAMILY = {"GCOV": "GCOV", "GUNW": "UNW", "RUNW": "UNW", "GOFF": "OFF", "ROFF": "OFF", "GSLC": "SLC", "RSLC": "SLC", "SME2": "SME2", "RIFG": "RIFG"}
CATALOG = {p: [{"key": k, "title": t} for k, (t, _) in EXTRAS[fam].items()] for p, fam in FAMILY.items()}


def run(out, ctx, prod, d):
    reg = EXTRAS.get(FAMILY.get(prod, ""), {})
    want = set(ctx.want or ())
    if "all" in want:
        want = set(reg)
    for key in reg:
        if key in want:
            try:
                reg[key][1](out, ctx, d)
            except Exception as exc:  # one failing extra must not hide the others
                msg = "no valid data in this window" if any(s in str(exc) for s in ("All-NaN", "zero-size", "empty")) else str(exc)
                out["notes"].append(f"{reg[key][0]}: could not run ({msg})")
