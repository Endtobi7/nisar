const fs = require("fs");
const EN = require("./content.js").SECTIONS, FR = require("./content_fr.js");
const R = "ready", P = "partial", G = "guide";
// [status, where, noteEN, noteFR] per item, in the order of content.js
const AV = [
 [[R,"search"],[R,"results"],[R,"layers"],[R,"layers"],[R,"insights"],[R,"insights"],[R,"insights"]],
 [[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"extra"],[R,"extra"],[R,"extra"],[R,"extra"],[R,"extra"],[R,"extra"]],
 [[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"extra"],[R,"extra"],[R,"extra"],[R,"extra"],
  [P,"extra","Used only when the troposphere and tide layers are on the full pixel grid; coarse lookup tables are not interpolated yet.","Utilisée seulement si les couches de troposphère et de marée sont sur la grille complète ; les tables grossières ne sont pas encore interpolées."],[R,"extra"],[R,"extra"]],
 [[R,"analyse"],[R,"analyse"],[R,"analyse"],[R,"extra"],[R,"extra"],[R,"extra"]],
 [[R,"analyse"],[R,"extra"],[R,"extra"],[R,"extra"]],
 [[R,"analyse"],[R,"extra"],[R,"extra"],[R,"extra"]],
 [[R,"analyse"],[R,"analyse"],[R,"extra"]],
 [[R,"tools"],
  [P,"tools","The analysis window is your drawn box (a rectangle). Free-form polygons are not drawn yet.","La fenêtre d'analyse est votre rectangle dessiné. Les polygones libres ne sont pas encore dessinés."],
  [R,"tools"],[R,"tools"],
  [P,"layers","A crossfade slider between two projected images (Layers panel), not a swipe.","Un curseur de fondu enchaîné entre deux images projetées (panneau Couches), pas un balayage."],
  [R,"tools"]],
 [[R,"pair"],[R,"pair"],[R,"pair"],[R,"pair"],
  [P,"pair","Wrapped phase and coherence only: no topographic-phase removal and no unwrapping. Use GUNW for quantitative motion.","Phase enroulée et cohérence seulement : pas de retrait de la phase topographique ni de déroulement. Utilisez GUNW pour un mouvement quantitatif."],
  [R,"pair"],[R,"pair"],[R,"pair"],[R,"pair"]],
 [[R,"series"],[R,"series"],[R,"series"],
  [P,"series","Pairs are chained as consecutive steps, not a full SBAS inversion.","Les paires sont enchaînées comme des pas consécutifs, pas une inversion SBAS complète."],
  [R,"series"],[R,"series"],[R,"series"],[G,"guide","Needs many frames on a common grid; not built.","Demande plusieurs frames sur une grille commune ; non réalisé."]],
 [[P,"pair","Uses nominal incidence angle and heading, and ignores the north component.","Utilise l'angle d'incidence et le cap nominaux, et ignore la composante nord."],[R,"pair"]],
 [[P,"layers","Visual only: NASA true-colour layers to compare by eye. A numerical comparison needs optical data you download yourself.","Visuel seulement : couches vraies couleurs de la NASA à comparer à l'œil. Une comparaison chiffrée demande des données optiques à télécharger vous-même."],
  [G,"guide","Needs Sentinel-1 data from another service.","Demande des données Sentinel-1 d'un autre service."],
  [P,"layers","Only the IMERG rainfall layer is shown for visual context; elevation and GRACE need external data.","Seule la couche de pluie IMERG est affichée pour le contexte visuel ; l'altitude et GRACE demandent des données externes."],
  [G,"guide","Needs a reference map you supply.","Demande une carte de référence que vous fournissez."]],
];
// analyses removed from the system (not useful for surface change, or redundant)
const REMOVED = ["Coverage heat map", "Layer inventory"];
const drop = EN.map((s) => s.items.map((it, i) => REMOVED.includes(it.n)));
if (drop.flat().filter(Boolean).length !== REMOVED.length) throw new Error("a removed analysis was not found");
EN.forEach((s, si) => { const keep = (_, i) => !drop[si][i]; FR[si].items = FR[si].items.filter(keep); AV[si] = AV[si].filter(keep); s.items = s.items.filter(keep); });
const out = { sections: [], items: [] };
EN.forEach((s, si) => {
  out.sections.push({ title: { en: s.title, fr: FR[si].title }, intro: { en: s.intro, fr: FR[si].intro } });
  s.items.forEach((it, ii) => {
    const f = FR[si].items[ii], [st, where, nEn, nFr] = AV[si][ii];
    out.items.push({
      id: `${si + 3}.${ii + 1}`, sec: si, product: it.p, difficulty: it.d, status: st, where,
      note: nEn ? { en: nEn, fr: nFr } : null,
      name: { en: it.n, fr: f.n }, needs: { en: it.needs, fr: f.needs }, tells: { en: it.tells, fr: f.tells },
      steps: { en: it.steps, fr: f.steps }, formulas: it.f || [],
      out: it.out ? { en: it.out, fr: f.out } : null, caution: it.caution ? { en: it.caution, fr: f.caution } : null,
    });
  });
});
const c = (k) => out.items.filter((i) => i.status === k).length;
console.log(out.items.length, "items:", c(R), "ready,", c(P), "partial,", c(G), "guide only");
fs.writeFileSync(require("path").join(__dirname, "../../frontend/src/guideData.js"), "// generated from the analysis guide: do not edit by hand\nexport const GUIDE = " + JSON.stringify(out) + ";\n");
