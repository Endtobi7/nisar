# NISAR Explorer

A web application to **find, view and analyse data from the NASA-ISRO NISAR radar satellite** without downloading whole files.
It searches the ASF archive, draws the granule footprints on a map, shows NISAR imagery from NASA, tracks the satellite in real time, and runs
more than 60 analyses (change maps, floods, deforestation, ground motion, glacier speed, soil moisture, time series, ...) on small windows
streamed from the files. A built-in guide (French and English) explains every analysis and how it is calculated.

It was built for the NASA Space Apps challenge about tracking and visualising Earth surface change with NISAR radar data.

---

## Contents

1. [Status: what is tested and what is not](#1-status-what-is-tested-and-what-is-not)
2. [Quick start](#2-quick-start)
3. [How the system works](#3-how-the-system-works)
4. [Project structure](#4-project-structure)
5. [Using the application](#5-using-the-application)
6. [NISAR products](#6-nisar-products)
7. [The analyses](#7-the-analyses)
8. [How the main calculations work](#8-how-the-main-calculations-work)
9. [Backend API reference](#9-backend-api-reference)
10. [Backend internals](#10-backend-internals)
11. [Frontend internals](#11-frontend-internals)
12. [Demo mode and synthetic data](#12-demo-mode-and-synthetic-data)
13. [Testing](#13-testing)
14. [Configuration and tuning](#14-configuration-and-tuning)
15. [Limitations and assumptions](#15-limitations-and-assumptions)
16. [Troubleshooting](#16-troubleshooting)
17. [Glossary](#17-glossary)
18. [Data sources, credits and privacy](#18-data-sources-credits-and-privacy)
19. [Possible next steps](#19-possible-next-steps)

---

## 1. Status: what is tested and what is not

Read this first. It tells you how far you can trust each part.

| Part | Status |
|---|---|
| Backend code, all analyses, the HDF5 streaming, exports | Tested on **synthetic files that follow the NISAR file layout** (`backend/test_analyse.py`, `backend/test_api.py`). |
| GeoTIFF export | Validated by reading it back with rasterio (CRS, transform, no-data). |
| User interface | An automatic test drives the whole flow in demo mode against the real backend (`frontend/src/ui.test.jsx`). The map itself is replaced by a stub in that test, so map drawing was **not** checked automatically. |
| Search against the real ASF archive | **Not tested here.** The build environment could not reach ASF, NASA GIBS, CelesTrak or Earthdata. |
| Analyses on real NISAR files | **Not tested.** Layers are found by name, so small layout differences are tolerated, but a real file may still reveal differences. |
| NASA GIBS imagery layers | Layer names and the WMS request were taken from NASA documentation and Worldview, not verified live. |

Whenever a result comes from synthetic data the interface says so ("Demo analysis on synthetic data. Not a real NISAR measurement").

Thresholds such as -18 dB, coherence 0.6 or 0.3 are **rules of thumb**, not NASA values. Validate every classification with another source.

---

## 2. Quick start

### Requirements

- **Python 3.10 or newer**
- **Node.js 18 or newer**
- A free **NASA Earthdata account** (https://urs.earthdata.nasa.gov) to read or download real files. Searching and demo mode need no account.
- Internet access to ASF, NASA GIBS and CelesTrak for real data.

### Windows (PowerShell)

PowerShell 5 does not accept `&&`. Type one command per line.

```powershell
cd nisar-explorer\backend
pip install -r requirements.txt
python -m uvicorn main:app --reload
```

Leave that window open, then open a **second** PowerShell window:

```powershell
cd nisar-explorer\frontend
copy .env.example .env
npm install
npm run dev
```

Open http://localhost:5173.

### macOS / Linux

```bash
cd nisar-explorer/backend && pip install -r requirements.txt && python -m uvicorn main:app --reload
# second terminal
cd nisar-explorer/frontend && cp .env.example .env && npm install && npm run dev
```

### First five minutes

1. Tick **Demo data** in the sidebar and press **Search NISAR**: footprints appear without any account.
2. Click a footprint or a row in the list. The granule panel opens.
3. In the panel press **Run analysis** (tick some **Extra analyses** first if you like).
4. Open **Guide** at the top of the sidebar to read about every analysis.
5. Untick **Demo data**, draw a box with **Draw box**, and search the real archive. Sign in with **Sign in** to analyse real files.

### After you extract a new version

1. Stop the backend (Ctrl+C) and the frontend.
2. In `backend`: `pip install -r requirements.txt` (new packages appear from time to time).
3. In `frontend`: `npm install`.
4. Start both again. If you extracted into a new folder, start them **from the new folder**: an old backend running from an old folder is the most common cause of "Not Found" errors.

---

## 3. How the system works

```
Browser (React + MapLibre)  <----->  FastAPI backend  <----->  ASF Search API (find granules)
        |                                   |             <->  Earthdata Login + Earthdata Cloud (files, HTTP range reads)
        |                                   |             <->  CelesTrak (orbit elements)
        +--> NASA GIBS WMS (backscatter, optical, rain tiles) directly from the browser
```

- **Search** is public. The backend wraps the `asf_search` package (dataset NISAR) and returns GeoJSON footprints.
- **Files** are HDF5. The backend never downloads a whole file to analyse it: it opens it through **HTTP range requests** (`rangefile.py`), so `h5py` reads only the blocks that hold the requested window.
- **Why a backend?** The browser cannot call Earthdata with your login (cross-origin limits), cannot read HDF5 efficiently, and cannot run the scientific code (numpy, scipy, pyproj).
- **NASA GIBS tiles** (the Worldview imagery) are requested by the browser directly. They need no login.
- **Orbit tracking** runs in the browser (SGP4 model in `satellite.js`) from orbital elements that the backend fetches from CelesTrak and caches.
- **State** (filters, map view, selected granule, layer settings) lives in the URL hash, so a link restores a view.

Data flow of one analysis:

1. The browser asks `/api/analyse` with the granule's file URL and a lon/lat window.
2. The backend opens the file with range reads, converts the window to pixel indices, reads only those pixels, computes metrics and renders PNG images.
3. The reply carries metrics, images (as data URLs), the image corners in longitude/latitude, histograms and notes.
4. The browser shows them and can place the images on the map from their corners.

---

## 4. Project structure

```
nisar-explorer/
├── README.md                     this file
├── backend/                      Python (FastAPI)
│   ├── main.py                   all HTTP endpoints, sessions, caches, security checks
│   ├── analyse.py                single-file analysis for each product, window and geo helpers
│   ├── extras.py                 optional extra analyses (ticked in the interface)
│   ├── pairs.py                  two-file analyses
│   ├── series.py                 many-file (time series) analyses
│   ├── rangefile.py              file-like object that reads a remote file with HTTP range requests
│   ├── render.py                 arrays to PNG (colour maps, class maps, phase colour wheel)
│   ├── geotiff.py                writes a georeferenced GeoTIFF
│   ├── demo_data.py              synthetic NISAR-style HDF5 files (demo mode and tests)
│   ├── test_analyse.py           offline test of every analyser and of the range reader
│   ├── test_api.py               end-to-end test of every endpoint with demo granules
│   └── requirements.txt
├── frontend/                     React + Vite
│   ├── index.html, vite.config.js, vitest.config.js, package.json, .env.example
│   └── src/
│       ├── main.jsx              entry point
│       ├── App.jsx               state and layout: ties everything together
│       ├── MapView.jsx           MapLibre map: footprints, layers, overlays, drawing, orbit
│       ├── Filters.jsx           search filters (area, dates and hours, products, orbit)
│       ├── Results.jsx           results list and acquisitions-per-day chart
│       ├── Insights.jsx          coverage table: revisit gaps and predicted next passes
│       ├── Detail.jsx            granule panel (information, actions)
│       ├── AnalysisPanel.jsx     "Analyse this file" (extras, parameters, results)
│       ├── Workbench.jsx         two-file and time-series analyses
│       ├── ResultView.jsx        displays any analysis result (metrics, charts, images)
│       ├── Chart.jsx             line/scatter charts and histograms (plain SVG)
│       ├── LayerPanel.jsx        map layers panel (backscatter, context, projected images, orbit)
│       ├── PixelPanel.jsx        pixel inspector results
│       ├── GuideDialog.jsx       the guide (analyses and products, French/English)
│       ├── LoginDialog.jsx       Earthdata sign-in
│       ├── api.js                every call to the backend
│       ├── catalogStore.js       loads the list of analyses the backend offers
│       ├── hash.js               reads and writes the shareable URL state
│       ├── products.js           descriptions of the 10 NISAR products
│       ├── guideData.js          GENERATED guide content (see tools/guide)
│       ├── gibs.js               NASA GIBS imagery requests
│       ├── orbit.js              orbit tracker (orbital elements + SGP4)
│       ├── fit.js, kml.js        placement of browse images (exact KML corners, fit modes)
│       ├── mock.js               demo granules for demo mode
│       ├── report.js             printable report
│       ├── styles.css
│       └── ui.test.jsx           automatic interface test
└── tools/guide/                  source of the guide
    ├── content.js                English text of every analysis (steps, formulas, cautions)
    ├── content_fr.js             French text, same order
    └── build_guide.js            merges both, applies the list of removed analyses, writes src/guideData.js
```

To change the guide text, edit `tools/guide/content.js` and `content_fr.js`, then run `node build_guide.js` inside `tools/guide`.

---

## 5. Using the application

### 5.1 The sidebar

**Title area**
- **Guide**: opens the guide (see 5.9).
- **Workbench (n)**: opens the multi-file analyses (see 5.7). The number counts the granules you collected.
- **Sign in / Sign out**: Earthdata login (see 5.6).

**Search filters**
- **Area**: press **Draw box** and drag a rectangle on the map. **Clear** removes it. With no box the whole world is searched.
- **From / To (UTC)**: date and hour. Times are UTC; the app shows your computer's offset. If From is after To the app shows a message and disables the search button.
- **Quick ranges**: Last 12 days, Last 30 days, Since 17 June 2026 (the first calibrated observations).
- **Match granules**: *that start inside the window* (default, recommended) or *whose time span touches the window*. The ASF time filter returns anything overlapping your interval. Pair products (interferograms, offsets) combine two acquisitions 12 or more days apart, so one can touch your interval while starting days earlier. The default keeps only granules that start inside your window and tells you how many were hidden.
- **Product type**: choose any of the 10 types (grouped as map-ready Level 2/3 and radar-specialist Level 0/1). Hover a chip for its full name. Default: GCOV.
- **Orbit**: any, ascending or descending.
- **Demo data**: uses synthetic granules and files instead of the real archive.
- **Search NISAR**: runs the search (maximum 250 results; the list says when the limit is reached).

**Results**
- **Acquisitions per day** chart: click a bar to show only that date.
- The list shows product, date and time (UTC), orbit, track and frame. Pair products also show their span ("pair 2026-10-08 → 2026-10-20"). Hover a row to highlight its footprint on the map; click to select it and zoom.
- **Coverage and next passes**: for each track and orbit direction: number of acquisitions, median and longest gap, and the predicted next pass (latest acquisition plus 12-day steps). It is a prediction; the observation plan can change.

### 5.2 The map

- **Footprints** are teal outlines. Hover = amber outline, selected = orange fill.
- The dashed grey box is your drawn area.
- Zoom and pan as usual. The base map is OpenStreetMap.
- **Layers panel** (bottom right, collapsible) holds everything else (see 5.3).
- **Granule panel** (top left) appears when a granule is selected (see 5.4).
- **Pixel panel** (bottom left) shows the result of the pixel inspector.

### 5.3 Layers panel

**NISAR radar backscatter (false colour, provisional)**
- A NASA mosaic of NISAR brightness: one image per UTC day (layer `NISAR_L2_Geocoded_Polarimetric_Covariance`), requested through the GIBS WMS service.
- **View**: *Daily mosaics* uses the slider; *NASA rolling 12-day composite* uses NASA's ready-made layer.
- **Latest day of the window**: the end date. Default is 3 days ago because GIBS publishes with a delay.
- **Days shown (1 to 12)**: stacks that many daily mosaics ending on the chosen date, newest on top. NISAR repeats every 12 days, so 12 days shows one full cycle of land and ice coverage.
- **Find latest data**: checks NASA day by day and jumps to the newest day with imagery.
- **Check which days have data**: lists the empty days in your window.
- **Opacity** slider.
- Tiles are reliable up to zoom 10 (about 150 m) and are enlarged beyond that.
- It is a picture for viewing, not measurements. NISAR maps mostly land and ice, so open ocean stays empty.

**Optical and rainfall context (NASA GIBS, visual only)**
- MODIS Terra true colour, VIIRS true colour, or IMERG rainfall rate, for a chosen date. Use it to check a water, burn or flood result by eye. Clouds hide the ground in optical images.

**Projected images**
- Browse images and analysis images that you placed on the map stay there until you remove them (the **×** per image or **Remove all**). They are lost when the page is reloaded.
- **Image opacity** slider.
- **Fit** dropdown (browse images only): *Exact* (from the granule's KML file), *auto*, *bounds*, *corners* (see 5.5).
- **Compare two images (crossfade)**: with two or more images, pick A and B and slide between them.

**NISAR orbit tracker (live)**
- The satellite position now (latitude, longitude, altitude, speed), the track of the last 50 minutes (dashed) and the next 110 minutes (solid). **Follow satellite** keeps the map centred on it.

### 5.4 The granule panel

For the selected granule:

- **Information**: product, start and stop (UTC), orbit, track and frame, polarization, data maturity, pipeline, size, and what the product contains and what you can extract.
- **Analyse this file**: see 5.8.
- **Project image on map** / **Remove image from map**: places the granule's browse image on the map (see 5.5).
- **Backscatter for this date**: turns on the backscatter layer for this acquisition day with 1 day shown, and zooms to the granule.
- **Download file** (after sign-in) or **Sign in to download**: streams the HDF5 file through your backend. Files are often several GB.
- **Copy share link**: copies the URL that restores this exact view.
- **Add to workbench**: collects the granule for multi-file analyses.
- **Inspect a point**: see 5.10.

### 5.5 Browse images and exact placement

- Every NISAR browse PNG is accompanied by a **KML file** that states exactly where the image sits. When it is found (from the granule's extra file links, or by replacing `.png` with `.kml`), the image is placed from its exact corners and the Fit dropdown offers **Exact**.
- When no KML is found, the image is fitted to the footprint. Geocoded products use the footprint bounding box with transparent edges cropped (**auto**); radar-geometry products pin their corners to the slanted footprint (**corners**). Use the Fit dropdown to adjust by eye. This placement is approximate.
- ASF sometimes serves PNGs labelled `binary/octet-stream`; the app recognises images by their first bytes.
- Browse images are public. The browser downloads them directly, and falls back to the backend if the server blocks cross-site requests.

### 5.6 Earthdata login

- Searching is public. **Reading or downloading real files needs an Earthdata login.**
- **Sign in** accepts a username and password, or a **token** (safer; generate one in your Earthdata profile).
- Credentials go **only to your own backend**, which keeps the session in memory (8 hours, lost when the backend restarts). Nothing is written to disk.
- If a download or analysis is refused, log in once at urs.earthdata.nasa.gov and **accept the ASF DAAC terms (EULA)**.
- Do not expose the backend on a public network: it holds your session and its CORS setting is open for local use.

### 5.7 The Workbench (two files and time series)

Open it from the sidebar. It is where you analyse several granules together, because **Analyse this file** works on one granule at a time.

1. Select a granule and press **Add to workbench** in its panel. Repeat for each granule.
2. Open **Workbench**.
3. **Two files** tab: choose file A and file B and an analysis. The hint under the analysis says what A and B mean (for example A = before, B = after). Only analyses that fit your two products are listed.
4. **Time series** tab: uses every granule in the workbench; they must all be one product type. It needs at least 3 files (5 for *Date of first change*).
5. Set the parameters shown, press **Run analysis**.

Rules: files must share track, frame, orbit direction and grid (otherwise the app reports that they do not cover the same area). The window is your drawn box if there is one (it must lie inside all granules), otherwise the centre of the first granule. Reading several files can take a minute or more.

### 5.8 Analyse this file (single granule)

- Press **Run analysis** to run the **base analysis** of the product, then optionally tick **Extra analyses** (and edit their thresholds).
- **Window**: *Drawn area* (the part of your box inside the granule) or *Centre of the granule*. Radar-geometry products (Level 0/1) always use a crop from the middle of the frame.
- Only a small window is read (never more than 1200 pixels per side; larger windows are read every k-th pixel).
- **Result view**: metrics (with notes), charts, images with a histogram, and buttons:
  - **Show on map** (georeferenced images): places the image on the map from its exact corners.
  - **GeoTIFF**: downloads the values with map coordinates (open in QGIS, ArcGIS, rasterio).
  - **CSV**: longitude, latitude, value (at most about 200,000 rows).
  - **PNG**: the picture.
  - **Open printable report**: a page you can print or save as PDF.
- The backend keeps the last 12 results for export. If an export says the result is no longer available, run the analysis again.

### 5.9 The guide

- Tabs: **Analyses** and **Products**; buttons **FR** and **EN**.
- Each analysis has: where to run it in the app, what it needs, what it tells you, the calculation steps, formulas, result and cautions.
- Status badge: **Ready in the app**, **Partly** (with the limit explained) or **Guide only**.
- Search box, section filter and status filter. The **Products** tab has a **Search <product>** button that sets the product filter.

### 5.10 Pixel inspector

In the granule panel press **Inspect a point**, then click the map. The pixel panel lists the value of every layer of the product at that point (complex layers as amplitude and phase; power layers also in dB). Turn off by clicking the button again. It reads a 1 x 1 window, so it is quick.

### 5.11 Shareable URL

State is stored in the URL after `#`:

| Parameter | Meaning |
|---|---|
| `bbox` | drawn area `west,south,east,north` |
| `start`, `end` | time window (UTC, `YYYY-MM-DDTHH:MM`) |
| `lvl` | product types, comma separated |
| `dir` | `ASCENDING` or `DESCENDING` |
| `tm` | `overlap` when matching granules whose span touches the window |
| `mock` | `1` for demo data |
| `v` | map view `lng,lat,zoom` |
| `sel` | selected granule name |
| `bs`, `bd`, `bn`, `bm` | backscatter layer on, end date, days shown, composite mode |
| `orbit` | `1` when the orbit tracker is on |

A link that contains a `bbox` or `sel` runs the search when it is opened.

---

## 6. NISAR products

All files are HDF5 (`.h5`), with layers under `/science/LSAR/<PRODUCT>/`. Geocoded (Level 2 and 3) products store the x and y coordinates of the pixel centres and a `projection` layer with the EPSG code.

| Product | Level | Grid | Main layers | Pair of dates |
|---|---|---|---|---|
| **GCOV** | L2 | UTM, 10 or 20 m | HHHH, HVHV, VVVV, VHVH (power, gamma-0, terrain corrected); HHVV in quad-pol; mask, numberOfLooks, rtcGammaToSigmaFactor | no |
| **GUNW** | L2 | UTM or polar stereographic, 80 m | unwrappedPhase, coherenceMagnitude, connectedComponents, ionospherePhaseScreen, wrapped interferogram, offsets, correction tables | yes |
| **GOFF** | L2 | 80 m | alongTrackOffset, slantRangeOffset, variances, correlation peak, SNR | yes |
| **GSLC** | L2 | 5 to 40 m | complex HH, HV, VH or VV; lookup tables; mask | no |
| **SME2** | L3 | 200 m | three soil-moisture estimates, uncertainty, vegetation water content, crop type | no |
| **RSLC** | L1 | radar geometry | complex HH, HV, VH or VV; calibration data | no |
| **RIFG** | L1 | 30 m, radar geometry | wrappedInterferogram, coherenceMagnitude | yes |
| **RUNW** | L1 | 80 m, radar geometry | unwrappedPhase, coherenceMagnitude, connectedComponents, ionospherePhaseScreen | yes |
| **ROFF** | L1 | 90 m, radar geometry | along-track and range offsets with quality layers | yes |
| **RRSD (L0B)** | L0 | raw | unfocused radar pulses | no |

- Map-ready products (GCOV, GUNW, GOFF, GSLC, SME2) can be placed on the map and combined. Radar-geometry products (RSLC, RIFG, RUNW, ROFF) give previews only.
- **Data maturity**: calibrated (provisional) products start on 2026-06-17. Beta products from early 2026 are less calibrated: do not mix them with provisional ones in one time series.
- NISAR repeats its orbit every 12 days. It maps mostly land and ice; open ocean is largely not covered.

---

## 7. The analyses

The guide inside the app has the full text for each. This is the map of what exists. **Ready** means available in the app; **partial** means available with a stated limit; **guide only** means described but not built.

### 7.1 Search and coverage
Search by area, date and hour, product and orbit; acquisitions per day; backscatter layer with the 1-12 day slider; live orbit tracker; next-pass prediction; revisit and gap statistics.

### 7.2 Single file (Analyse this file)

| Product | Base analysis (always) | Extra analyses (tick) |
|---|---|---|
| **GCOV** | backscatter statistics per polarization (dB); HV minus HH; radar vegetation index; grey and false-colour images | automatic water map and area; land-cover groups; scattering decomposition (quad-pol only) |
| **GUNW / RUNW** | line-of-sight change (cm); ionosphere check; coherence statistics; change and coherence images | largest positive and negative change; area moving more than a limit; profile along a line; strain; troposphere and tide corrections (partial); reliable-pixel mask; displacement uncertainty |
| **GOFF / ROFF** | relative motion and noise level; implied speed; motion and range-offset images | flow direction and arrows; offset quality mask; speed map (m/yr) |
| **GSLC / RSLC** | amplitude statistics and image | bright-target detection (CFAR) |
| **SME2** | soil-moisture statistics and image | dry and wet shares; uncertainty map; vegetation water content and crop type |
| **RIFG** | wrapped phase and coherence preview | fringe density |
| **RRSD** | none: raw pulses must be focused with SAR software (ISCE3), so the app says there is nothing to analyse | none |

### 7.3 Two files (Workbench)

| Analysis | A | B | Output |
|---|---|---|---|
| GCOV before and after change map | before | after | log-ratio change map, significant darker/brighter pixels and area |
| Flood extent and flooded area | before | after | permanent water, new open water, possible flooded vegetation, areas |
| Deforestation and burn-scar area | before | after | HV drop map and vegetation-loss area (needs HV) |
| Coherence change (damage mapping) | reference pair | pair spanning the event | coherence difference, strong coherence loss and area |
| Own interferogram from two GSLC (partial) | first date | second date | wrapped phase and coherence (no topographic-phase removal, no unwrapping) |
| GCOV plus GUNW: reliable motion | GCOV | GUNW | displacement kept only on non-water, coherent pixels |
| GCOV plus SME2: radar vs soil moisture | GCOV | SME2 | correlation, straight-line fit, scatter plot |
| GOFF plus GUNW: fast and slow motion | GOFF | GUNW | merged line-of-sight change, agreement statistics |
| Vertical and east-west motion (partial) | ascending GUNW | descending GUNW | vertical and east-west maps (nominal geometry) |
| Ascending plus descending GCOV | ascending | descending | difference map and gap-filled combined image |

### 7.4 Many files (Workbench, time series)

| Analysis | Product | Minimum files | Output |
|---|---|---|---|
| Backscatter time series for a place | GCOV | 3 | curves per polarization, trend, largest drop and rise, variability map |
| Date of first change | GCOV | 5 | map of the first change date, share changed |
| Temporal average and variability | GCOV | 3 | clean average image, coefficient of variation |
| Coherence over time | GUNW | 3 | coherence curves, largest drop, mean coherence map |
| Ground-motion velocity (mm/yr) (partial) | GUNW | 3 | velocity map and cumulative curve (pairs chained, not full SBAS) |
| Glacier or ground speed series | GOFF | 3 | speed curves |
| Soil-moisture anomaly | SME2 | 3 | z-score map of the latest date |

### 7.5 Tools
Histogram under each image; GeoTIFF, CSV and PNG export; printable report; pixel inspector; crossfade between two projected images; optical and rainfall context layers; statistics inside a drawn area (partial: the area is a rectangle).

### 7.6 Not built (guide only)
Mosaic of several frames; Sentinel-1 radar combination; reference-map accuracy assessment. Also partial: swipe comparison (crossfade only), optical comparison (visual only), rainfall/elevation/water-storage (rainfall layer only).

### 7.7 Analyses removed
Layer inventory (RRSD), single-date phase, speckle statistics (ENL), sigma-0 conversion, mask and number-of-looks quality, coverage heat map, water-like share, very bright share, texture and GSLC amplitude change were removed as not useful for surface-change work or redundant.

### 7.8 Analyses that can mislead
Land-cover groups (unlabelled clusters), flow arrows (image frame, not north), displacement uncertainty (assumed number of looks), troposphere and tide corrections (rarely applicable), own interferogram, vertical and east-west motion (nominal geometry), the GOFF plus GUNW merge (sign conventions), velocity and soil-moisture anomaly (records of only a few months), dry and wet shares (arbitrary limits). Read the cautions in the guide before using them.

---

## 8. How the main calculations work

**Decibels.** Power spans orders of magnitude, so it is shown in dB: `dB = 10 x log10(power)` (amplitude: `20 x log10`). Always average in linear units, then convert.

**Gamma-0.** GCOV values are terrain-normalised power (gamma-0). Sigma-0 is `gamma-0 x rtcGammaToSigmaFactor`.

**Speckle and multilooking.** Radar images are grainy. Averaging L independent pixels reduces the relative noise to `1/sqrt(L)`. Change maps average 5 x 5 windows and use the noise of a log-ratio: `sigma_dB = 4.34 x sqrt(2 / L)`; the change limit is `k x sigma_dB` (k = 3 by default, L = 25).

**Robust statistics.** Median and percentiles ignore outliers. Noise is estimated as `1.4826 x median(|x - median(x)|)` (MAD).

**Window selection.**
1. The lon/lat box corners are converted to the file's coordinate system (EPSG from the `projection` layer, using pyproj).
2. The pixels whose centres lie inside the x and y range are selected (coordinate arrays are small and read first).
3. If the window exceeds the limit (1200 px per side), every k-th pixel is read: `k = ceil(max(width, height) / 1200)`.
4. With no area, a 600-pixel square at the centre is used.
5. Image corners are the pixel edges (centre plus or minus half the spacing) converted back to lon/lat, so images land exactly on the map.

**Phase to displacement.** `d = phase x lambda / (4 pi)` with `lambda = 0.2384 m` (L-band). One full phase cycle is `lambda / 2 = 11.9 cm`. Results are relative to the window median; the sign convention must be checked in the product specification.

**Coherence.** `gamma = |E[s1 x conj(s2)]| / sqrt(E[|s1|^2] x E[|s2|^2])`, between 0 (changed) and 1 (stable). Phase noise: `sigma_phi = sqrt((1 - gamma^2) / (2 L gamma^2))`; `sigma_d = sigma_phi x lambda / (4 pi)`.

**Offsets to speed.** Offsets (metres) have the window's median removed (bulk shift); magnitude `= sqrt(along^2 + range^2)`; speed `= magnitude / days x 365.25` (m/yr). The days between the two acquisitions default to 12 and can be changed.

**Areas and shares.** `area_km2 = N_pixels x dx x dy / 1,000,000`; `share = 100 x N_class / N_valid` (valid pixels only).

**Automatic water map (seeded growth, no smoothing).** Water is found on single pixels of the HH (or VV) dB image: *seeds* are pixels below -20 dB (-27 dB for HV/VH), water *grows* into connected pixels below -17 dB (-24 dB), and a grown region is kept only if it has at least 4 pixels and at least half of them are below the seed limit (a water body is dark through and through; merely dark ground is not). There is no smoothing and no opening, so rivers only a few pixels wide survive; a feature narrower than about 3 pixels is mixed with its banks and cannot be mapped reliably. The result lists the largest regions with their mean dB and whether they are long and thin (river-like) or compact (lake-like). Change the limits with `water_core_db` / `water_grow_db`. A second, **uncertain** layer, *Possible water* (orange), shows water brighter than those limits, for example wind-roughened lakes (GCOV is gamma-0, 1 to 2 dB brighter than sigma-0 over water): a two-component mixture is fitted to the scene histogram and the layer appears only if the classes are clearly separate (Ashman's D above 2) and the dark class is darker than -15 dB. When nothing is found, the note gives the darkest 1 % and median dB of the scene so you can choose the limits. Smooth or bare dry ground can be as dark as water at L-band: use a DEM (below), an optical check, or `validate.py` to calibrate on a river you know. Pixels the mask layer marks invalid (0) or outside the image (255) are left out.

**Land-cover groups.** k-means (k = 5 by default) on standardised features HH dB, HV dB and HV minus HH, using up to 40,000 sampled pixels; groups are ranked darkest to brightest.

**Scattering decomposition.** Freeman-Durden three components from the covariance terms (volume `Pv = 8 x HVHV`, then surface and double-bounce from the remainder, depending on the sign of Re(HHVV)). Needs quad-pol data.

**Flood.** Water found with the same seeded-growth rule as the automatic water map, on each date separately; new open water = water after, not before, at least 3 dB darker; possible flooded vegetation = at least 3 dB brighter and not water before.

**Deforestation.** HV drop of more than 2 dB with the HV minus co-pol ratio also falling; small patches removed (about half a hectare).

**Time series velocity.** Reference point = the most coherent pixel on average; pairs are chained as consecutive steps (12 days by default); a straight line is fitted per pixel; mm/yr `= slope (cm/day) x 10 x 365.25`; pixels with low mean coherence are masked.

**Vertical and east-west.** Unit line-of-sight vectors from a nominal incidence of 39 degrees and the satellite heading (from inclination 98.4 degrees and latitude), look direction from the file (right if missing); the 2 x 2 system for ascending and descending is solved per pixel, ignoring the north component.

**Orbit tracker.** Orbital elements (TLE, NORAD 65053) propagated with SGP4, converted with the Greenwich sidereal time; the track is sampled every 30 seconds and split where the longitude jumps by more than 180 degrees.

---

## 9. Backend API reference

Base URL `http://localhost:8000`. All data endpoints are GET except login and logout.

| Endpoint | Parameters | Returns |
|---|---|---|
| `GET /api/health` | none | `ok`, the product types, the list of routes (useful to check the backend is the newest) |
| `GET /api/search` | `bbox` (w,s,e,n), `start`, `end` (ISO), `level` (comma list), `direction`, `pol`, `maturity`, `limit` (default 250, max 2000) | GeoJSON FeatureCollection of granules |
| `POST /api/login` | JSON `{username, password}` or `{token}` | `{sid, user}`; 401 if refused |
| `GET /api/me` | `sid` | `{user}`; 401 if the session expired |
| `POST /api/logout` | `sid` | `{ok}` |
| `GET /api/download` | `sid`, `url` | streams the file; only ASF and Earthdata hosts |
| `GET /api/tle` | none | NISAR orbital elements (text), cached 2 hours |
| `GET /api/browse` | `url`, optional `sid` | the browse image (public https only) |
| `GET /api/text` | `url` | a small `.kml` or `.xml` file (at most 1 MB) |
| `GET /api/catalog` | none | the extras, two-file and series analyses the backend offers |
| `GET /api/analyse` | `url`, `sid`, `bbox`, `level`, `baseline_days`, `max_px`, `want`, `params`, `demo` | one-file result |
| `GET /api/compare` | `url_a`, `url_b`, `mode`, `sid`, `bbox`, `baseline_days`, `max_px`, `params` | two-file result |
| `GET /api/series` | `urls`, `times` (comma lists), `mode`, `sid`, `bbox`, `baseline_days`, `max_px`, `params` | series result (at most 24 files) |
| `GET /api/pixel` | `url`, `lon`, `lat`, `sid`, `level` | values of the layers at one point |
| `GET /api/export` | `rid`, `image`, `fmt` (`geotiff` or `csv`) | a file download |

**File URLs** are the https URL of a NISAR `.h5` file, or a demo address `demo:LEVEL:T:DIRECTION` (for example `demo:GCOV:3:Ascending`).

**`want`**: comma list of extra analysis keys, or `all`. **`params`**: JSON with the thresholds below.

| Parameter | Default | Used by |
|---|---|---|
| `kclusters` | 5 | land-cover groups |
| `deform_cm` | 2 | area moving more than a limit |
| `coh_min` | 0.6 | area moving, reliable-pixel mask, velocity |
| `looks` | 20 (uncertainty), 25 (change maps) | displacement uncertainty, change maps |
| `line` | window diagonal | profile along a line (`lon1,lat1,lon2,lat2`) |
| `corr_min` | 0.1 | offset quality mask |
| `cfar_k` | 6 | bright-target detection |
| `dry`, `wet` | 0.15, 0.35 | dry and wet shares (percent data are scaled automatically) |
| `k_sigma` | 3 | change maps, first change |
| `hv_drop` | 2 | deforestation |
| `drop` | 0.3 | coherence change |
| `incidence` | 39 | vertical and east-west |
| `baseline_days` (own parameter) | 12 | offsets and velocity |

**A result** contains: `product`, `identification` (track, frame, pass direction, ...), `metrics` (label, value, note), `images` (name, `png` data URL, `corners`, `georeferenced`, `legend`, `hist`), `series` (charts), `notes`, `window` (rows, columns, pixel size), `demo`, and `rid` (used for export).

**Errors** are JSON `{detail}`: 400 bad input, 401 not signed in or refused, 404 export no longer available (or an old backend: `Not Found`), 422 the data does not allow the analysis (for example "outside this granule"), 502 the file or a remote service could not be read.

---

## 10. Backend internals

- **`main.py`**: endpoints; the session store (memory only, 8 hour life); results cache (last 12) and raw-array store for exports (last 12); search cache (256).
- **`analyse.py`**: opens a product group, finds layers by name (`pick`), computes the window (`Geo`, `geo_window`, `radar_window`), reads it (`read`, which also handles the real/imaginary compound storage of complex data and fill values), and runs the analyser of the product. `identification` reads track, frame and pass direction when present.
- **`extras.py`**: each optional analysis is a function registered by product family; `CATALOG` is built from the registry. One failing extra never hides the others (it adds a note).
- **`pairs.py`**: `Src` wraps a file; the window of file A defines a lon/lat box that is used to read file B; B is resampled to A's grid (`fit_to`, NaN-aware); `check_cover` refuses files that do not cover the same area.
- **`series.py`**: the first file defines the window; the other files are read in parallel (4 workers) with that box; all arrays are resampled to the first file's shape.
- **`rangefile.py`**: `RangeFile` is a file-like object. It follows the Earthdata redirects once (to a pre-signed URL), then reads 2 MB blocks with `Range` requests, keeps up to 96 blocks (about 190 MB) and re-resolves the URL if it expires. `h5py` can open it directly.
- **`render.py`**: colour maps (gray, viridis, diverging, earth), class maps, RGB composites, the phase colour wheel; PNG data URLs, at most 1100 pixels on the long side.
- **`geotiff.py`**: float32 GeoTIFF with the pixel scale, tie point, projected CRS (EPSG) and a NaN no-data value.
- **Security**: the download proxy accepts only ASF and Earthdata hosts; the browse and text proxies accept only **public https** addresses (private, loopback and link-local addresses are refused, also after redirects); file analysis accepts only allowed hosts or demo addresses; credentials are never logged or stored on disk.
- **Memory and size limits**: windows are limited to 1200 pixels per side (800 for two files, 400 for series, 300 default window); responses with several images can reach a few MB.

---

## 11. Frontend internals

- **`App.jsx`** holds the state: filters, results, selection, hover, layers, projected images (`overlays`), the workbench basket, pixel inspector, login session (kept in `sessionStorage`), guide and dialogs. Search results are filtered by granule start time (unless "touches the window" is chosen).
- **`MapView.jsx`** (MapLibre GL) creates sources and layers once and updates them from props: your area, footprints, hover and selected highlights, orbit lines and satellite, pixel pin, up to 12 backscatter layers (`bs-0` to `bs-11`), the context layer (`ctx`), and projected images (`ov-<id>`) inserted below the footprints.
- **`gibs.js`**: builds the NASA GIBS WMS requests (backscatter daily or 12-day composite, context layers) and helpers to find the latest day with data.
- **`orbit.js`**: a small store (subscribe pattern) that loads the orbital elements, propagates once per second and keeps the track; the map and the readout subscribe to it.
- **`kml.js`, `fit.js`**: read the exact corners of a browse image from its KML (`LatLonQuad` or rotated `LatLonBox`); otherwise fit the image to the footprint.
- **`ResultView.jsx`, `Chart.jsx`, `report.js`**: render any result, draw charts and histograms as plain SVG, and open a printable report.
- **`products.js`** describes the 10 products; **`guideData.js`** (generated) feeds the guide.
- **Language**: the interface is in English; the guide has a French/English switch (default follows the browser language).

---

## 12. Demo mode and synthetic data

Tick **Demo data** to work without the archive and without a login.

- `mock.js` produces fake granules: two tracks (ascending track 82, descending track 119), ten dates 12 days apart from 2026-06-17, three frames per date. Each granule's file address is `demo:LEVEL:T:DIRECTION` (T = date index 0 to 9).
- The backend turns that address into a **synthetic HDF5 file in memory** (`demo_data.py`) with the same group names as real products: a 500 x 500 pixel grid of 20 m in UTM zone 29N (200 m and 50 x 50 for SME2).
- The synthetic scene contains a water body and an urban patch. From date index 4 a vegetation-loss patch appears (HV drops) and part of the coherence is lost; from index 5 a patch floods. Each interferogram shows a subsidence bowl (1 cm per pair), the GSLC phase carries a bowl that grows with the date, and the offsets mimic a flowing glacier whose speed grows with the date. This lets every analysis show something.
- Everything demo shows is labelled as synthetic.

---

## 12b. Accuracy tools and parameters

- **Mask layer (GCOV).** Product specification, section 4.3.3: `0` = invalid or partly focused, `1` to `5` = valid (the sub-swath number), `255` = outside the image. It is applied while reading every covariance layer, so all GCOV analyses (single, two-file, series) use valid pixels only. It is **not** a layover or shadow mask, and NASA notes that the mask of the BETA products can be misaligned near image edges.
- **Steep terrain (optional).** GCOV has no slope layer. Give your own DEM as the parameters `dem` (path to a GeoTIFF, any CRS or resolution) and `max_slope` (degrees, default 10): the water map and the flood map then ignore steeper pixels, where radar shadow and layover look like water.
- **Change maps.** The noise uses the file's own `numberOfLooks`. Set `false_alarm` (for example 0.0027) to choose the false-alarm rate instead of `k_sigma`.
- **Velocity from many pairs.** If each GUNW file gives its reference and secondary dates (file metadata, or four time stamps in the file name) the pairs are inverted together by weighted least squares (SBAS) with their real dates, and the result includes a formal uncertainty map and a network-misfit map. Otherwise the old chain is used and the result says so. Set `network=0` to force the chain.
- **`validate.py`.** Compares any binary result with an independent reference and calibrates thresholds on a real scene: `python validate.py compare --pred water.tif --ref reference.tif`, `python validate.py water-threshold --db HH_dB.tif --ref reference.tif` (best dB threshold, ROC area), `python validate.py coherence --coh coh.tif --disp los_cm.tif --stable stable.tif`.

## 13. Testing

From `backend`:

```bash
python test_analyse.py    # every analyser on synthetic files, windows, decimation, range reading over HTTP
python test_accuracy.py   # 106 checks of the NUMBERS against known synthetic truth (water, flood, deformation, time series, ...)
python test_api.py        # every endpoint: search-free analyses, two-file, series, pixel, exports (GeoTIFF read back with rasterio)
```

`test_api.py` imports `rasterio` for the GeoTIFF check: `pip install rasterio` (only needed for testing).

From `frontend` (needs the backend running on port 8000, started with `python -m uvicorn main:app --port 8000`):

```bash
npm install
npm test
```

The interface test uses jsdom (no real browser) with a stub map and drives: the guide (counts and French), a demo search, the coverage table, a single-file analysis with an extra, adding six granules to the workbench, a two-file change map, a flood analysis, a backscatter time series and the date of first change.

---

## 14. Configuration and tuning

- **Backend address**: `frontend/.env` (`VITE_API_URL`, default `http://localhost:8000`).
- **Change limits** (all in the interface): the numbers in the extras and in the workbench forms (see the parameter table in section 9).
- **Hard limits** you may want to change in code: result limit in `main.py` (`limit`), `max_px` defaults in `main.py` and `analyse.Ctx`, block size and cache in `rangefile.py`, cache sizes in `main.py`, session life (`SESSION_TTL`).
- **Backscatter default date** (3 days ago): `DEFAULT_LAYERS` in `hash.js`.
- **GIBS layer names**: top of `gibs.js`. If a layer stays blank, check the name and the time range in NASA Worldview.
- **Allowed download hosts**: `ALLOWED_HOSTS` in `main.py`.
- **Guide text**: `tools/guide` (then run `node build_guide.js`).
- **Adding an analysis**: write the function in `extras.py` (single file), `pairs.py` or `series.py`, register it in the registry/`MODES`, and add its text in `tools/guide/content.js` and `content_fr.js` (and its availability in `build_guide.js`).

---

## 15. Limitations and assumptions

- **No real data was available during the build.** Layer names, the time semantics of ASF, the format of GIBS tiles and the presence of browse images and KML files for NISAR granules are assumptions based on documentation. The first runs on real data may reveal differences; send the error text and the product type.
- **Time filter**: ASF matches granules whose time span overlaps the window; the app then keeps granules by start time by default.
- **Phase sign** (towards or away from the satellite) and the **look direction** (assumed right if missing) are not confirmed; vertical and east-west results depend on them.
- **Incidence angle and heading** are nominal in the vertical/east-west analysis; per-pixel values are not read.
- **Troposphere and tide corrections** are applied only when those layers are on the full pixel grid; coarse lookup tables are not interpolated.
- **Own interferogram** has no topographic-phase removal and no unwrapping.
- **Velocity** chains consecutive pairs (no full SBAS inversion); with only a few months of data slopes are uncertain.
- **Resampling** between files of different resolution is approximate (ignores small rotations and different map projections).
- **Windows are small by design.** Statistics describe the window, not the whole granule.
- **Radar-geometry products** (RSLC, RIFG, RUNW, ROFF) give central-crop previews that cannot be placed on the map.
- **The backscatter layer** is a picture; do not read numbers from it.
- **Browser support**: a recent Chrome, Edge or Firefox (date-time inputs and WebGL are required).
- **Security**: designed for local use. Do not publish the backend without restricting CORS and adding your own protection.

---

## 16. Troubleshooting

| Symptom | Likely cause | What to do |
|---|---|---|
| PowerShell says `&&` is not a valid separator | Windows PowerShell 5 | Type one command per line. |
| `Cannot find path ...\backend` | You are one folder too high or too low (the zip contains a `nisar-explorer` folder) | Run `dir`, go into the folder that contains `backend` and `frontend`. |
| `uvicorn` is not recognised | pip installed it in your user folder | Use `python -m uvicorn main:app --reload`. |
| "Not Found" when analysing, projecting an image or listing analyses | The backend running is an older version | Stop it and start it again from the newest folder. Open http://localhost:8000/api/health and check the `routes` list. |
| Extra analyses list is empty | Old backend, or the backend is not running | Restart the backend; the interface says so. |
| Search shows nothing | Dates outside the record (calibrated data starts 2026-06-17), no data in the box, or the time window excludes granules | Widen the dates, clear the area, choose **touches the window**, add more product types. |
| Files appear outside my dates | Pair products span two dates; the ASF filter matches overlap | Keep **start inside the window** (default), or read the pair span shown in the list. |
| Backscatter layer is blank | GIBS publishes with a delay, or the date has no imagery | Press **Find latest data** or pick an earlier date; check the layer name in `gibs.js`. |
| Browse image does not show on the map | No browse image for the granule, an old backend, or the server refused the image | Read the message under the button; use **Backscatter for this date** instead. |
| Image is misplaced | No KML found, so the placement is approximate | Try the Fit dropdown (auto, bounds, corners). |
| "Earthdata rejected the request" | Wrong credentials or the ASF DAAC terms are not accepted | Sign in again; accept the EULA at urs.earthdata.nasa.gov. |
| Analysis says "outside this granule" | The drawn box does not intersect the granule | Redraw the box, or choose "Centre of the granule". |
| "The two files do not cover the same area" | Different track or frame | Choose files of the same track, frame and orbit direction, or draw a smaller box inside both. |
| Analysis is slow | Remote reading depends on your connection | Draw a smaller box; run from a computer close to the data (AWS us-west-2) if possible. |
| "Could not read the file" (502) | A network or file problem | Try again; check the Earthdata login; check the backend window for the detail. |
| Time series: "needs at least N files" | Too few granules in the workbench | Add more granules of the same product and track. |
| Orbit tracker says elements could not be loaded | CelesTrak is not reachable | Check the connection; the backend caches the last elements for 2 hours. |
| Interface test fails on connection | Backend is not running | Start `python -m uvicorn main:app --port 8000` first. |

---

## 17. Glossary

- **SAR**: synthetic aperture radar, an imaging radar that works day and night through clouds.
- **L-band**: the radar wavelength of NISAR's main instrument (about 24 cm); it sees through much vegetation. NISAR also has an S-band instrument.
- **Granule**: one data file (one acquisition frame of one product).
- **Track / frame**: the repeating satellite path and the piece of it that one file covers. Files can be compared only if track and frame match.
- **Ascending / descending**: the satellite moving towards the north or the south. They look at the ground from opposite sides.
- **Backscatter**: how strongly the ground reflects the radar signal back (shown in dB).
- **Polarization (HH, HV, VV, VH)**: transmitted and received direction of the radar wave; HV and VH are cross-polarized and respond to vegetation.
- **Gamma-0 / sigma-0**: two ways to normalise backscatter.
- **Speckle**: grainy noise typical of radar images, reduced by averaging (multilooking).
- **Coherence**: similarity of the surface between two dates (1 stable, 0 changed).
- **Interferogram**: the phase difference between two dates; wrapped (modulo one cycle) or unwrapped.
- **Line of sight (LOS)**: the direction from the ground to the satellite; radar measures motion along it.
- **Offset tracking**: measuring displacement by matching image patterns, useful for fast motion.
- **HDF5**: the file format of NISAR products.
- **Range request**: asking a server for only part of a file.
- **GIBS / Worldview**: NASA's imagery service and its viewer.
- **TLE**: two-line element set, the orbit description used to compute a satellite's position.
- **EPSG code**: the number identifying a map projection (for example 32629 for UTM zone 29N).
- **GeoTIFF**: an image file that carries map coordinates.
- **Otsu threshold**: a method that finds the value best separating two classes in a histogram.
- **CFAR**: constant false alarm rate, a detector of bright targets against their local background.

---

## 18. Data sources, credits and privacy

- **NISAR** is a joint mission of NASA and ISRO. Data are distributed by the **ASF DAAC** (Alaska Satellite Facility) through NASA Earthdata. Calibrated products are provisional.
- **Imagery layers** (backscatter, true colour, rainfall) come from **NASA GIBS**.
- **Orbital elements** come from **CelesTrak**.
- **Base map**: © OpenStreetMap contributors.
- **Software**: FastAPI, asf_search, h5py, numpy, scipy, pyproj, Pillow, tifffile, React, Vite, MapLibre GL, satellite.js.
- **Privacy**: your Earthdata credentials or token are sent only to your own backend, kept in its memory and never written to disk. The backend contacts ASF, Earthdata, CelesTrak and the file hosts on your behalf. The browser contacts NASA GIBS and OpenStreetMap directly.
- Cite NISAR, ASF DAAC and NASA Earthdata in anything you publish.

---

## 19. Possible next steps

- Run the analyses on real NISAR files and adjust layer names or behaviour where needed.
- Finish the partial analyses: free-form polygon statistics, swipe comparison, full SBAS velocity with the real pair dates, interpolation of the correction tables, topographic-phase removal and unwrapping.
- Upload a reference map and compute an accuracy assessment.
- Optical validation with Sentinel-2 data.
- Mosaics of neighbouring frames.
- An **Advanced** switch with warning labels for the analyses that can mislead.


## Nisa, the AI assistant

Nisa (the character in the bottom-left corner of the map) answers questions about the app, radar terms and your
current analysis result. She always works offline from a built-in list. With an Anthropic API key she answers with
Claude, using the app state and the latest result as context.

```bash
export ANTHROPIC_API_KEY=sk-ant-...      # required for AI answers; never put it in the frontend
export NISA_MODEL=claude-haiku-5-5       # optional, this is the default
export NISA_RATE_PER_MINUTE=20           # optional, questions per minute per client
# NISA_API_URL=...                       # optional, e.g. a proxy or a test double
cd backend && uvicorn main:app --port 8000
```

The key stays on the server (`backend/nisa.py`). Without a key, or if the AI call fails, Nisa falls back to the
offline answer and says so. Tests (the Anthropic call is faked): `pip install pytest httpx2` then
`pytest backend/test_nisa.py`.

## Disaster events (earthquakes and floods)

The **Events** tab lists earthquakes and floods from public, keyless sources:

- Earthquakes: USGS.
- Floods: GDACS + NASA EONET (relays FloodList, ReliefWeb, GLIDE, ...) + Copernicus EMS Rapid Mapping. The same flood reported by several sources is merged into one event that keeps every source and report link.

Click an event: the map flies to the affected area, the analysis box and dates are set, and the backend (`/api/events/plan`) searches NISAR granules there and pairs one scene BEFORE with one scene AFTER (same product level, direction, track and frame, footprint covering the event point; one processing maturity when possible, otherwise flagged). **Open in Workbench** loads the pair as A = before, B = after with the suggested analysis (flood map for floods; own interferogram / coherence change for earthquakes).

**What the ASF archive holds.** NISAR collects nearly all land every 12 days, but the archive is released in windows (NISAR Data User Guide, Nov 2026), coded in `ARCHIVE` in `events.py`:

| Date of event | Status |
|---|---|
| before 1 Aug 2025 | before NISAR |
| 1 Aug to 16 Oct 2025, 21 Jan to 16 Jun 2026 | collected, not in the archive yet (2027 reprocessing) |
| 17 Oct 2025 to 20 Jan 2026 | BETA subset only (up to 8 acquisitions per track) |
| 17 Jun 2026 onwards | global (PROVISIONAL, then VALIDATED from 21 Oct 2026) |
| 27 Jul to 10 Aug 2026 | permanent instrument gap, no data |

Every event shows this label; the planner does not query ASF when no data can exist, and otherwise says why no pair was found (no scene before, none after, or different tracks).

**On the map.** The loaded events are drawn as dots: earthquakes sized and coloured by magnitude (yellow below 6, orange 6 to 7, red 7 and above), floods in blue. Hover for a tooltip, click a dot to select the event (it opens its NISAR plan). A weekly activity chart and a legend sit above the list; "Show on the map" switches the dots off.

**Copernicus flood outline.** When an event has a Copernicus EMS activation (EMSR code), **Show on map** draws the flood polygons that analysts delineated from satellite images (cyan; the white dashed line is the area they actually looked at: outside it nobody observed, so the absence of a polygon there means nothing). The panel lists each product with the date the water was SEEN, the sensor, the flooded area in km2 (geodesic) and the number of days between that date and your NISAR "after" scene. To compare, run the flood analysis in the Workbench and project the flood map on the globe: it appears under the cyan outline. Copernicus data: "Contains modified Copernicus Emergency Management Service information, © European Union." Only activations from 2023 are public through the API, and only hosts of the service are fetched.

- `GET /api/events?kind=all|earthquake|flood&start=&end=&min_mag=&bbox=&with_data=`
- `GET /api/events/cems/{EMSR code}/flood` (outline, observation mask, per-product date and area)
- `GET /api/events/plan?kind=&lon=&lat=&start=&end=&bbox=&magnitude=&look_back_days=&wait_after_days=`
- Tests: `python -m pytest test_events.py` (network faked).
- Limits: flood catalogues are not complete (small local floods are often missing). A flood scene weeks after the event may show no water. Downloading the files needs an Earthdata login.
