import { useEffect, useMemo, useRef, useState } from "react";
import { answer, SUGGESTIONS } from "./nisaKnowledge.js";
import { nisaStatus, askNisa } from "./api.js";

// Nisa, the guide character. She follows what you do, reacts to results, answers questions,
// runs one-click actions and can read a result aloud. Everything works offline.

const TOUR = [
  { tab: "search", sel: ".filters .aoi", title: "1. Choose a place", text: "Press Draw box and drag a rectangle on the map. The map zooms to your area." },
  { tab: "search", sel: ".filters .search", title: "2. Search", text: "Press Search NISAR to list the radar acquisitions that cover your area and dates. No account is needed to search." },
  { tab: "granules", sel: ".dock .results", title: "3. Pick a granule", text: "Each line is one acquisition. Click it (or its footprint on the map) to zoom in and see its details." },
  { sel: ".maptools", title: "4. Look in 3D", text: "Switch basemaps, turn the Earth into a globe, tilt the ground into 3D terrain and exaggerate the relief." },
  { tab: "layers", sel: ".dock .layers", title: "5. Add layers", text: "Overlay NISAR backscatter, rainfall or optical images, track the satellite live and compare dates." },
  { sel: ".topbar .actions", title: "6. Analyse and learn", text: "The Workbench compares several dates. The Guide explains every analysis. Each result comes with a plain-language reading and a printable report." },
];

const tipFor = (s) => {
  if (s.drawing) return { id: "drawing", text: "Drag a rectangle on the map, then let go. I will zoom to it." };
  if (s.searching) return { id: "searching", text: "Searching the archive…" };
  if (!s.searched && !s.hasArea) return { id: "start", text: "Hi, I'm Nisa. Let's find radar data. Outline the place you care about, or skip the area to search the whole world.", acts: ["draw"] };
  if (!s.searched) return { id: "area", text: "Good area. Now search for the acquisitions over it.", acts: ["search"] };
  if (s.count === 0) return { id: "none", text: "No granules here. Widen the dates, clear the area, or tick Demo data to try the app with synthetic files." };
  if (!s.selected) return { id: "found", text: `${s.count} granule${s.count === 1 ? "" : "s"} found. Click a footprint on the map or a line in the list and I will zoom to it.` };
  if (!s.analysed) return { id: "analyse", text: "Open Analyse this file, tick an extra analysis and press Run analysis. I will explain the results in plain words." };
  if (!s.terrain) return { id: "flat", text: "Switch on 3D terrain to see your results draped over the relief.", acts: ["terrain"] };
  if (s.basket >= 2 && !s.wbOpen) return { id: "basket", text: `${s.basket} granules are in your workbench. Compare dates: change, floods, damage, motion.`, acts: ["workbench"] };
  return { id: "read", text: "Start with What this means, then Every number, explained. Open the printable report when you are ready." };
};

const ACTS = { draw: "Draw a box", search: "Search now", terrain: "Turn on 3D", workbench: "Open the workbench", layers: "Open Layers", guide: "Open the guide", tour: "Take the tour" };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function Face({ mood, look, talking }) {
  const teal = "#35ecdc";
  const mouth = talking ? "M55 68q5 8 10 0z" : mood === "happy" ? "M53 67q7 8 14 0" : mood === "worried" ? "M55 71q5 -3.5 10 0" : mood === "think" ? "M57 69h7" : "M55 68.5q5 3.5 10 0";
  const ox = mood === "think" ? 1.6 : 0, oy = mood === "think" ? -2.2 : 0;
  const lx = look.x * 0.9 + ox, ly = look.y * 0.8 + oy;
  const eye = (cx) => (mood === "happy"
    ? <path key={cx} d={`M${cx - 4.5} 60.5q4.5 -6.5 9 0`} stroke={teal} strokeWidth="2.8" fill="none" strokeLinecap="round" />
    : (
      <g key={cx} transform={`translate(${lx} ${ly})`}>
        <ellipse cx={cx} cy="59" rx="5.6" ry="6.8" fill={teal} opacity=".22" />
        <ellipse cx={cx} cy="59" rx="4" ry={mood === "worried" ? 4.6 : 5.2} fill={teal} />
        <circle cx={cx - 1.3} cy="56.8" r="1.4" fill="#fff" />
      </g>
    ));
  const rim = mood === "worried" ? "#ff8a4c" : "#7fd6cf";
  return (
    <svg viewBox="0 0 120 120" width="86" height="86" aria-hidden="true" className={`nisa-svg mood-${mood}${talking ? " talking" : ""}`}>
      <defs>
        <radialGradient id="nbody" cx="38%" cy="28%" r="80%"><stop offset="0" stopColor="#ffffff" /><stop offset=".55" stopColor="#e1f4f2" /><stop offset="1" stopColor="#a6d6d3" /></radialGradient>
        <linearGradient id="nvisor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#173e55" /><stop offset="1" stopColor="#06182a" /></linearGradient>
        <linearGradient id="nwing" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#6db3ff" /><stop offset="1" stopColor="#2a58a8" /></linearGradient>
        <radialGradient id="nglow" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#ffc83d" stopOpacity=".9" /><stop offset="1" stopColor="#ffc83d" stopOpacity="0" /></radialGradient>
      </defs>
      <g transform="rotate(-16 60 66)"><ellipse className="nisa-ring" cx="60" cy="66" rx="55" ry="15" fill="none" stroke="#2fd1c5" strokeOpacity=".4" strokeWidth="1.4" strokeDasharray="2 6" strokeLinecap="round" /><circle cx="113" cy="62" r="2.6" fill="#ffc83d" /></g>
      <ellipse className="nisa-shadow" cx="60" cy="114" rx="22" ry="3.6" fill="#000" opacity=".35" />
      <g className="nisa-bob">
        <path className="nisa-flame" d="M52 98q8 22 16 0q-8 5 -16 0z" fill="#ffc83d" opacity=".9" /><path className="nisa-flame" d="M56 98q4 11 8 0q-4 3 -8 0z" fill="#35ecdc" />
        <g transform="rotate(-9 30 62)"><rect x="3" y="45" width="26" height="32" rx="4.5" fill="url(#nwing)" stroke="#cfeeff" strokeWidth=".9" /><path d="M11.7 45v32M20.3 45v32M3 55.7h26M3 66.3h26" stroke="#fff" strokeOpacity=".45" strokeWidth=".8" /><rect x="27" y="59" width="12" height="5" rx="2" fill="#bfe9e5" /></g>
        <g transform="rotate(9 90 62)"><rect x="91" y="45" width="26" height="32" rx="4.5" fill="url(#nwing)" stroke="#cfeeff" strokeWidth=".9" /><path d="M99.7 45v32M108.3 45v32M91 55.7h26M91 66.3h26" stroke="#fff" strokeOpacity=".45" strokeWidth=".8" /><rect x="81" y="59" width="12" height="5" rx="2" fill="#bfe9e5" /></g>
        <line x1="60" y1="27" x2="60" y2="13" stroke="#bfe9e5" strokeWidth="3" strokeLinecap="round" />
        <circle cx="60" cy="11" r="9" fill="url(#nglow)" className="nisa-ping" />
        <circle cx="60" cy="11" r="4.2" fill={mood === "worried" ? "#ff8a4c" : "#ffc83d"} stroke="#fff" strokeWidth="1" />
        <path className="nisa-wave" d="M51 6q-5 4 -3 10M69 6q5 4 3 10" fill="none" stroke="#ffc83d" strokeWidth="1.6" strokeLinecap="round" />
        <ellipse cx="60" cy="66" rx="33" ry="39" fill="url(#nbody)" stroke={rim} strokeWidth="2.6" />
        <path d="M36 50q4 -17 24 -21" fill="none" stroke="#fff" strokeOpacity=".85" strokeWidth="3" strokeLinecap="round" />
        <rect x="49" y="90" width="22" height="8" rx="4" fill="#cfe9e6" stroke="#9fd0cc" strokeWidth="1" />
        <circle cx="54.5" cy="94" r="1.6" fill="#35ecdc" /><circle cx="60" cy="94" r="1.6" fill="#ffc83d" /><circle cx="65.5" cy="94" r="1.6" fill="#ff8aa1" />
        <rect x="39" y="44" width="42" height="33" rx="16.5" fill="url(#nvisor)" stroke="#2b6f86" strokeWidth="1.6" />
        <path d="M45 51q8 -5 19 -4" stroke="#fff" strokeOpacity=".32" strokeWidth="2.2" fill="none" strokeLinecap="round" />
        <g className={mood === "think" ? "nisa-eyes think" : "nisa-eyes"}>{eye(52)}{eye(68)}</g>
        {mood === "worried" && <path d="M46.5 49.5l10 3M73.5 49.5l-10 3" stroke={teal} strokeWidth="2" strokeLinecap="round" />}
        <circle cx="44.5" cy="69" r="3" fill="#ff8aa1" opacity=".5" /><circle cx="75.5" cy="69" r="3" fill="#ff8aa1" opacity=".5" />
        <path className="nisa-mouth" d={mouth} fill={talking ? teal : "none"} stroke={teal} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        {mood === "happy" && <path className="nisa-spark" d="M93 26l2.4 6 6 2.4 -6 2.4 -2.4 6 -2.4 -6 -6 -2.4 6 -2.4z" fill="#ffc83d" />}
        {mood === "think" && <g fill="#9fd8d3" className="nisa-dots"><circle cx="88" cy="30" r="2.2" /><circle cx="95" cy="22" r="2.8" /><circle cx="103" cy="13" r="3.4" /></g>}
      </g>
    </svg>
  );
}

export default function Mascot({ stage, tourReq = 0, onTab, actions = {}, result = null, getContext }) {
  const [hidden, setHidden] = useState(() => { try { return localStorage.getItem("nisa-hidden") === "1"; } catch { return false; } });
  const [open, setOpen] = useState(true);
  const [step, setStep] = useState(-1);
  const [asking, setAsking] = useState(false);
  const [q, setQ] = useState("");
  const [reply, setReply] = useState(null);
  const [speaking, setSpeaking] = useState(false);
  const [aiOn, setAiOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [thread, setThread] = useState([]);
  const [lastQ, setLastQ] = useState("");
  const [look, setLook] = useState({ x: 0, y: 0 });
  const charRef = useRef(null);
  const tip = useMemo(() => tipFor(stage), [stage.drawing, stage.searching, stage.searched, stage.hasArea, stage.count, stage.selected, stage.analysed, stage.terrain, stage.basket, stage.wbOpen]); // eslint-disable-line react-hooks/exhaustive-deps
  const canSpeak = typeof window !== "undefined" && "speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined";
  const showResult = stage.analysed && !!result;

  // mood follows the situation
  const mood = speaking ? "happy" : busy || stage.searching ? "think" : showResult && result.tone === "alert" ? "worried" : showResult && result.tone !== "watch" ? "happy" : "idle";

  // the eyes follow the cursor
  useEffect(() => {
    if (hidden || !open) return undefined;
    let raf = 0;
    const move = (e) => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const r = charRef.current?.getBoundingClientRect();
        if (!r) return;
        const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
        setLook({ x: clamp(dx / 160, -1, 1) * 2.6, y: clamp(dy / 160, -1, 1) * 2 });
      });
    };
    window.addEventListener("mousemove", move);
    return () => { window.removeEventListener("mousemove", move); if (raf) cancelAnimationFrame(raf); };
  }, [hidden, open]);

  useEffect(() => { if (step < 0 && !asking) setOpen(true); }, [tip.id, step]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { nisaStatus().then((st) => setAiOn(!!st.enabled)); }, []);
  useEffect(() => { if (result) { setOpen(true); setAsking(false); setReply(null); setThread([]); } }, [result]);
  useEffect(() => { if (tourReq) { setHidden(false); setOpen(true); setAsking(false); setStep(0); } }, [tourReq]);
  useEffect(() => () => { if (canSpeak) window.speechSynthesis.cancel(); }, [canSpeak]);

  // spotlight for the tour
  useEffect(() => {
    document.querySelectorAll(".tour-hl").forEach((el) => el.classList.remove("tour-hl"));
    if (step < 0) return undefined;
    if (TOUR[step].tab) onTab?.(TOUR[step].tab);
    let el = null;
    const t = setTimeout(() => {
      el = document.querySelector(TOUR[step].sel);
      el?.classList.add("tour-hl");
      el?.scrollIntoView?.({ block: "nearest", behavior: "smooth" });
    }, 80);
    return () => { clearTimeout(t); el?.classList.remove("tour-hl"); };
  }, [step]); // eslint-disable-line react-hooks/exhaustive-deps

  function stopSpeech() { if (canSpeak) window.speechSynthesis.cancel(); setSpeaking(false); }
  const hide = () => { stopSpeech(); setHidden(true); setStep(-1); try { localStorage.setItem("nisa-hidden", "1"); } catch { /* ignore */ } };
  const show = () => { setHidden(false); setOpen(true); try { localStorage.removeItem("nisa-hidden"); } catch { /* ignore */ } };
  const speak = () => {
    if (!canSpeak || !result) return;
    if (speaking) { stopSpeech(); return; }
    const u = new SpeechSynthesisUtterance([result.headline, ...result.points.slice(0, 3)].join(". "));
    u.lang = "en-US";
    u.onend = () => setSpeaking(false);
    u.onerror = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };
  const run = (id) => {
    if (id === "tour") { setAsking(false); setStep(0); return; }
    actions[id]?.();
  };
  const ask = async (text) => {
    const t = (text ?? q).trim();
    if (!t || busy) return;
    setQ("");
    setLastQ(t);
    const local = answer(t);
    if (!aiOn) { setReply({ ...local, offline: true }); return; }
    let next = [...thread, { role: "user", content: t }].slice(-10);
    if (next[0].role !== "user") next = next.slice(1);
    setBusy(true);
    setReply(null);
    try {
      const hint = local?.text ? `\n\nApp knowledge that may help: ${local.text}` : "";
      const text2 = await askNisa({ messages: next, context: `${getContext?.() || ""}${hint}` });
      setThread([...next, { role: "assistant", content: text2 }]);
      setReply({ text: text2, act: local?.act && local.act !== "guide" ? local.act : undefined, label: local?.label });
    } catch (e) {
      setThread(next);
      setReply({ ...local, offline: true, error: e.message });
    } finally {
      setBusy(false);
    }
  };

  if (hidden) return <button className="nisa-call" onClick={show} aria-label="Bring back Nisa, the guide">?</button>;

  const touring = step >= 0;
  const cur = touring ? TOUR[step] : null;
  return (
    <aside className="nisa" aria-label="Nisa, your guide">
      {open && (
        <div className="nisa-bubble" role="status" aria-live="polite">
          <button className="x" onClick={() => { setOpen(false); setStep(-1); setAsking(false); stopSpeech(); }} aria-label="Close tip">×</button>
          {touring ? (
            <>
              <b>{cur.title}</b>
              <p>{cur.text}</p>
              <div className="nisa-btns">
                <button className="btn ghost" disabled={step === 0} onClick={() => setStep(step - 1)}>Back</button>
                {step < TOUR.length - 1
                  ? <button className="btn solid" onClick={() => setStep(step + 1)}>Next</button>
                  : <button className="btn solid" onClick={() => setStep(-1)}>Done</button>}
                <span className="nisa-count">{step + 1} / {TOUR.length}</span>
              </div>
            </>
          ) : asking ? (
            <>
              <b>Ask me <span className={`nisa-tag${aiOn ? " ai" : ""}`}>{aiOn ? "AI" : "offline"}</span></b>
              <form className="nisa-ask" onSubmit={(e) => { e.preventDefault(); ask(); }}>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={aiOn ? "Ask about your result, radar, the app…" : "e.g. what is coherence?"} aria-label="Ask Nisa" autoFocus disabled={busy} />
                <button className="btn solid" type="submit" disabled={busy}>Ask</button>
              </form>
              {busy && <p className="nisa-wait">Thinking…</p>}
              {reply ? (
                <div className="nisa-reply">
                  {lastQ && <small className="nisa-q">{lastQ}</small>}
                  {reply.error && <small className="nisa-warn">The AI could not answer ({reply.error}). Here is an offline answer.</small>}
                  <p>{reply.text}</p>
                  {reply.act && <button className="btn solid" onClick={() => run(reply.act)}>{reply.label || ACTS[reply.act]}</button>}
                  {reply.related?.length > 0 && (
                    <div className="nisa-rel"><small>Related analyses</small>{reply.related.map((r) => <button key={r} className="chip" onClick={() => ask(r)}>{r}</button>)}</div>
                  )}
                </div>
              ) : !busy && (
                <div className="nisa-sugg">{[...(showResult && aiOn ? ["Explain this result simply", "What should I check next?"] : []), ...SUGGESTIONS].map((x) => <button key={x} className="chip" onClick={() => ask(x)}>{x}</button>)}</div>
              )}
              <div className="nisa-btns small"><button className="link" onClick={() => { setAsking(false); setReply(null); setLastQ(""); }}>Back to tips</button></div>
            </>
          ) : (
            <>
              {showResult ? (
                <>
                  <b className={`nisa-res tone-${result.tone}`}>{result.headline}</b>
                  {result.points[0] && <p>{result.points[0]}</p>}
                </>
              ) : (
                <p>{tip.text}</p>
              )}
              <div className="nisa-btns">
                {!showResult && (tip.acts || []).map((a) => <button key={a} className="btn solid" onClick={() => run(a)}>{ACTS[a]}</button>)}
                {showResult && aiOn && <button className="btn solid" onClick={() => { setAsking(true); setReply(null); ask("Explain this result in simple terms and tell me what to check next."); }}>Explain it to me</button>}
                {showResult && canSpeak && <button className="btn ghost" onClick={speak}>{speaking ? "Stop" : "Read aloud"}</button>}
                <button className="btn ghost" onClick={() => { setAsking(true); setReply(null); }}>Ask me</button>
              </div>
              <div className="nisa-btns small">
                <button className="link" onClick={() => setStep(0)}>Take the tour</button>
                <button className="link" onClick={hide}>Hide tips</button>
              </div>
            </>
          )}
        </div>
      )}
      <button ref={charRef} className="nisa-char" onClick={() => setOpen(!open)} aria-label={open ? "Hide Nisa's tip" : "Show Nisa's tip"} aria-expanded={open}>
        <Face mood={mood} look={look} talking={speaking} />
      </button>
    </aside>
  );
}
