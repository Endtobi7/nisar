import { useEffect, useRef } from "react";
import maplibregl from "maplibre-gl";
import { tracker } from "./orbit.js";
import { bsTileUrl, contextTileUrl } from "./gibs.js";

const STYLE = {
  version: 8,
  sources: {
    "base-osm": { type: "raster", tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"], tileSize: 256, maxzoom: 19, attribution: "© OpenStreetMap contributors" },
    "base-sat": { type: "raster", tiles: ["https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"], tileSize: 256, maxzoom: 18, attribution: "Imagery © Esri, Maxar, Earthstar Geographics" },
    // elevation for the 3D terrain (one source for the relief, another for the shading)
    dem: { type: "raster-dem", tiles: ["https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"], tileSize: 256, maxzoom: 14, encoding: "terrarium", attribution: "Terrain: Mapzen / AWS Terrain Tiles" },
    "dem-shade": { type: "raster-dem", tiles: ["https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"], tileSize: 256, maxzoom: 14, encoding: "terrarium" },
  },
  layers: [
    { id: "bg", type: "background", paint: { "background-color": "#071018" } },
    { id: "base-dark", type: "raster", source: "base-osm", layout: { visibility: "none" }, paint: { "raster-brightness-min": 0.93, "raster-brightness-max": 0.05, "raster-hue-rotate": 190, "raster-saturation": -0.35, "raster-contrast": 0.15 } },
    { id: "base-osm", type: "raster", source: "base-osm", layout: { visibility: "none" } },
    { id: "base-sat", type: "raster", source: "base-sat" },
    { id: "relief", type: "hillshade", source: "dem-shade", paint: { "hillshade-exaggeration": 0.35, "hillshade-shadow-color": "#05121c", "hillshade-highlight-color": "#ffffff", "hillshade-accent-color": "#2b4a5c" } },
  ],
  sky: { "sky-color": "#0a2236", "horizon-color": "#5aa9c9", "fog-color": "#0d2a3d", "sky-horizon-blend": 0.6, "horizon-fog-blend": 0.7, "fog-ground-blend": 0.4 },
};
const BASEMAPS = ["dark", "osm", "sat"];

const EMPTY = { type: "FeatureCollection", features: [] };

const dayMinus = (iso, i) => new Date(Date.parse(iso + "T00:00:00Z") - i * 864e5).toISOString().slice(0, 10);
const point = (pos) => ({ type: "FeatureCollection", features: pos ? [{ type: "Feature", properties: {}, geometry: { type: "Point", coordinates: [pos.lon, pos.lat] } }] : [] });
const bboxPoly = ([w, s, e, n]) => ({
  type: "FeatureCollection",
  features: [{ type: "Feature", properties: {}, geometry: { type: "Polygon", coordinates: [[[w, s], [e, s], [e, n], [w, n], [w, s]]] } }],
});
const normBox = (a, b) => [Math.min(a.lng, b.lng), Math.min(a.lat, b.lat), Math.max(a.lng, b.lng), Math.max(a.lat, b.lat)];

function boundsOf(features) {
  const b = new maplibregl.LngLatBounds();
  const walk = (c) => (typeof c[0] === "number" ? b.extend(c) : c.forEach(walk));
  features.forEach((f) => walk(f.geometry.coordinates));
  return b.isEmpty() ? null : b;
}

export default function MapView({ fly, view3d, areaKey, ovFocus, mapCmd, features, selectedId, hoveredId, bbox, drawing, view, fitKey, focus, layers, follow, overlays, overlayOpacity, opacities, context, inspect, pin, events, selectedEventId, eventsOn, ems, onEventPick, onMapClick, onIssue, onDraw, onSelect, onHover, onMove }) {
  const box = useRef(null);
  const mapRef = useRef(null);
  const ready = useRef(false);
  const latest = useRef({});
  latest.current = { events, selectedEventId, eventsOn, ems, onEventPick, view3d, features, selectedId, hoveredId, bbox, layers, follow, overlays, overlayOpacity, opacities, context, inspect, pin, onMapClick, onIssue, onDraw, onSelect, onHover, onMove };
  const bsKey = useRef("");
  const lastOrbit = useRef({});

  const sync = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const { features, selectedId, hoveredId, bbox } = latest.current;
    map.getSource("fp").setData({ type: "FeatureCollection", features });
    map.getSource("aoi").setData(bbox ? bboxPoly(bbox) : EMPTY);
    const pn = latest.current.pin;
    map.getSource("pin").setData(pn ? { type: "FeatureCollection", features: [{ type: "Feature", properties: {}, geometry: { type: "Point", coordinates: [pn.lon, pn.lat] } }] } : EMPTY);
    map.setFilter("fp-sel-fill", ["==", ["get", "_id"], selectedId || ""]);
    map.setFilter("fp-sel-line", ["==", ["get", "_id"], selectedId || ""]);
    map.setFilter("fp-hov-line", ["==", ["get", "_id"], hoveredId || ""]);
  };

  const syncBs = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const { bs, date, days, opacity, mode } = latest.current.layers;
    const composite = mode === "composite";
    const key = bs ? `${date}|${mode}` : "";
    if (key !== bsKey.current) {
      for (let i = 0; i < 12; i++) {
        if (map.getLayer(`bs-${i}`)) map.removeLayer(`bs-${i}`);
        if (map.getSource(`bs-${i}`)) map.removeSource(`bs-${i}`);
      }
      bsKey.current = key;
      if (bs) {
        for (let i = (composite ? 0 : 11); i >= 0; i--) { // oldest first, newest on top
          map.addSource(`bs-${i}`, { type: "raster", tiles: [bsTileUrl(dayMinus(date, i), composite)], tileSize: 256, minzoom: 0, maxzoom: 10, attribution: "NASA GIBS · NISAR (provisional)" });
          map.addLayer({ id: `bs-${i}`, type: "raster", source: `bs-${i}`, layout: { visibility: "none" }, paint: { "raster-fade-duration": 0 } }, "aoi-fill");
        }
      }
    }
    if (bs) {
      for (let i = 0; i < 12; i++) {
        if (!map.getLayer(`bs-${i}`)) continue;
        map.setLayoutProperty(`bs-${i}`, "visibility", (composite ? i === 0 : i < days) ? "visible" : "none");
        map.setPaintProperty(`bs-${i}`, "raster-opacity", opacity);
      }
    }
  };

  // projected browse images stay on the map until the user removes them
  const shown = useRef(new Set());
  const syncOverlays = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const { overlays, overlayOpacity, opacities } = latest.current;
    const want = new Set(overlays.map((o) => `ov-${o.id}`));
    shown.current.forEach((id) => {
      if (!want.has(id)) {
        if (map.getLayer(id)) map.removeLayer(id);
        if (map.getSource(id)) map.removeSource(id);
        shown.current.delete(id);
      }
    });
    overlays.forEach((o) => {
      const id = `ov-${o.id}`;
      if (!shown.current.has(id)) {
        map.addSource(id, { type: "image", url: o.url, coordinates: o.coords });
        map.addLayer({ id, type: "raster", source: id, paint: { "raster-fade-duration": 0 } }, "fp-fill");
        shown.current.add(id);
      }
      map.getSource(id).setCoordinates(o.coords);
      map.setPaintProperty(id, "raster-opacity", opacities?.[o.id] ?? overlayOpacity);
    });
  };

  // optical / rainfall context layer from NASA GIBS (visual comparison)
  const ctxKey = useRef("");
  const syncContext = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const { layer, date, opacity } = latest.current.context;
    const key = layer ? `${layer}|${date}` : "";
    if (key !== ctxKey.current) {
      if (map.getLayer("ctx")) map.removeLayer("ctx");
      if (map.getSource("ctx")) map.removeSource("ctx");
      ctxKey.current = key;
      if (layer) {
        map.addSource("ctx", { type: "raster", tiles: [contextTileUrl(layer, date)], tileSize: 256, minzoom: 0, maxzoom: 9, attribution: "NASA GIBS" });
        map.addLayer({ id: "ctx", type: "raster", source: "ctx", paint: { "raster-fade-duration": 0 } }, map.getLayer("bs-11") ? "bs-11" : map.getLayer("bs-0") ? "bs-0" : "aoi-fill");
      }
    }
    if (layer) map.setPaintProperty("ctx", "raster-opacity", opacity);
  };

  // 3D terrain, basemap and relief shading
  const prev3d = useRef(null);
  const prevGlobe = useRef(null);
  const syncEvents = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const { events: evs, selectedEventId: sid, eventsOn: on, ems: em } = latest.current;
    map.getSource("ev").setData({ type: "FeatureCollection", features: (evs || []).map((e) => ({
      type: "Feature", properties: { id: e.id, kind: e.kind, mag: e.magnitude ?? 0, label: e.kind === "earthquake" ? `M ${e.magnitude?.toFixed(1)} · ${e.place || ""}` : `Flood · ${e.place || e.title || ""}`, day: (e.start || "").slice(0, 10) },
      geometry: { type: "Point", coordinates: [e.lon, e.lat] } })) });
    for (const id of ["ev-eq", "ev-fl", "ev-sel"]) map.setLayoutProperty(id, "visibility", on ? "visible" : "none");
    map.setFilter("ev-sel", ["==", ["get", "id"], sid || ""]);
    map.getSource("ems").setData(em?.outline || EMPTY);
    map.getSource("ems-mask").setData(em?.observed_mask || EMPTY);
  };

  const sync3d = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const { terrain, exaggeration, basemap, globe } = latest.current.view3d;
    if (prevGlobe.current !== globe) { map.setProjection({ type: globe ? "globe" : "mercator" }); prevGlobe.current = globe; }
    BASEMAPS.forEach((k) => map.getLayer(`base-${k}`) && map.setLayoutProperty(`base-${k}`, "visibility", k === basemap ? "visible" : "none"));
    map.setPaintProperty("relief", "hillshade-exaggeration", terrain ? 0.2 : 0.4);
    if (terrain) map.setTerrain({ source: "dem", exaggeration });
    else map.setTerrain(null);
    if (prev3d.current !== null && prev3d.current !== terrain) {
      map.easeTo(terrain ? { pitch: 62, bearing: map.getBearing() || -18, duration: 1100 } : { pitch: 0, bearing: 0, duration: 800 });
    }
    prev3d.current = terrain;
  };

  const drawOrbit = () => {
    const map = mapRef.current;
    if (!map || !ready.current) return;
    const s = tracker.getSnapshot();
    if (lastOrbit.current.past !== s.past) { map.getSource("orbit-past").setData(s.past); lastOrbit.current.past = s.past; }
    if (lastOrbit.current.future !== s.future) { map.getSource("orbit-future").setData(s.future); lastOrbit.current.future = s.future; }
    map.getSource("sat").setData(point(s.pos));
    if (s.pos && latest.current.follow) map.easeTo({ center: [s.pos.lon, s.pos.lat], duration: 900, essential: true });
  };

  // init once
  useEffect(() => {
    const map = new maplibregl.Map({ container: box.current, style: STYLE, center: [view[0], view[1]], zoom: view[2], maxPitch: 80, attributionControl: { compact: true } });
    mapRef.current = map;
    if (typeof window !== "undefined" && window.__NISAR_DEBUG__) window.__nisarMap = map; // test hook
    map.addControl(new maplibregl.NavigationControl({ showCompass: true, visualizePitch: true }), "top-right");
    map.on("error", (e) => {
      const id = e.sourceId || "";
      if (id.startsWith("bs-")) latest.current.onIssue?.("bs");
      if (id.startsWith("ov-")) latest.current.onIssue?.("browse");
      if (id === "dem") latest.current.onIssue?.("dem");
    });
    map.on("load", () => {
      map.addSource("fp", { type: "geojson", data: EMPTY });
      map.addSource("aoi", { type: "geojson", data: EMPTY });
      map.addSource("pin", { type: "geojson", data: EMPTY });
      map.addLayer({ id: "aoi-fill", type: "fill", source: "aoi", paint: { "fill-color": "#ffffff", "fill-opacity": 0.07 } });
      map.addLayer({ id: "aoi-line", type: "line", source: "aoi", paint: { "line-color": "#ffc83d", "line-width": 2.5, "line-dasharray": [2, 2] } });
      map.addLayer({ id: "fp-fill", type: "fill", source: "fp", paint: { "fill-color": "#2fd1c5", "fill-opacity": 0.16 } });
      map.addLayer({ id: "fp-line", type: "line", source: "fp", paint: { "line-color": "#2fd1c5", "line-width": 1.6 } });
      map.addLayer({ id: "fp-hov-line", type: "line", source: "fp", filter: ["==", ["get", "_id"], ""], paint: { "line-color": "#ffc83d", "line-width": 3.5 } });
      map.addLayer({ id: "fp-sel-fill", type: "fill", source: "fp", filter: ["==", ["get", "_id"], ""], paint: { "fill-color": "#ff8a4c", "fill-opacity": 0.28 } });
      map.addLayer({ id: "fp-sel-line", type: "line", source: "fp", filter: ["==", ["get", "_id"], ""], paint: { "line-color": "#ff8a4c", "line-width": 3.5 } });

      map.addSource("orbit-past", { type: "geojson", data: EMPTY });
      map.addSource("orbit-future", { type: "geojson", data: EMPTY });
      map.addSource("sat", { type: "geojson", data: EMPTY });
      map.addLayer({ id: "orbit-past", type: "line", source: "orbit-past", paint: { "line-color": "#b9adff", "line-width": 2, "line-dasharray": [2, 2], "line-opacity": 0.9 } });
      map.addLayer({ id: "orbit-future", type: "line", source: "orbit-future", paint: { "line-color": "#b9adff", "line-width": 2.5 } });
      map.addLayer({ id: "sat-halo", type: "circle", source: "sat", paint: { "circle-radius": 16, "circle-color": "#b9adff", "circle-opacity": 0.22 } });
      map.addLayer({ id: "sat-dot", type: "circle", source: "sat", paint: { "circle-radius": 6, "circle-color": "#8d7cff", "circle-stroke-color": "#fff", "circle-stroke-width": 2 } });

      map.addSource("ev", { type: "geojson", data: EMPTY });
      map.addSource("ems", { type: "geojson", data: EMPTY });
      map.addSource("ems-mask", { type: "geojson", data: EMPTY });
      // Copernicus EMS observed flood outline (compare it with the NISAR flood map) and the area they actually looked at
      map.addLayer({ id: "ems-mask", type: "line", source: "ems-mask", paint: { "line-color": "#ffffff", "line-width": 1.2, "line-dasharray": [3, 3], "line-opacity": 0.7 } });
      map.addLayer({ id: "ems-fill", type: "fill", source: "ems", paint: { "fill-color": "#00e5ff", "fill-opacity": 0.12 } });
      map.addLayer({ id: "ems-line", type: "line", source: "ems", paint: { "line-color": "#00e5ff", "line-width": 1.8 } });
      // events: floods as blue dots, earthquakes sized and coloured by magnitude
      map.addLayer({ id: "ev-fl", type: "circle", source: "ev", filter: ["==", ["get", "kind"], "flood"], paint: { "circle-radius": 7, "circle-color": "#3aa0ff", "circle-opacity": 0.85, "circle-stroke-color": "#ffffff", "circle-stroke-width": 1.5 } });
      map.addLayer({ id: "ev-eq", type: "circle", source: "ev", filter: ["==", ["get", "kind"], "earthquake"], paint: {
        "circle-radius": ["interpolate", ["linear"], ["get", "mag"], 4, 4, 6, 8, 8, 22],
        "circle-color": ["step", ["get", "mag"], "#ffd166", 6, "#ff8a4c", 7, "#e5383b"], "circle-opacity": 0.75, "circle-stroke-color": "#ffffff", "circle-stroke-width": 1 } });
      map.addLayer({ id: "ev-sel", type: "circle", source: "ev", filter: ["==", ["get", "id"], ""], paint: { "circle-radius": 26, "circle-color": "rgba(0,0,0,0)", "circle-stroke-color": "#ffffff", "circle-stroke-width": 3 } });
      const tip = new maplibregl.Popup({ closeButton: false, closeOnClick: false, offset: 12 });
      for (const id of ["ev-eq", "ev-fl"]) {
        map.on("mousemove", id, (e) => {
          if (mapRef.current.__drawing) return;
          map.getCanvas().style.cursor = "pointer";
          const p = e.features[0].properties;
          tip.setLngLat(e.features[0].geometry.coordinates).setText(`${p.label} · ${p.day}`).addTo(map);
        });
        map.on("mouseleave", id, () => { map.getCanvas().style.cursor = ""; tip.remove(); });
        map.on("click", id, (e) => { if (!mapRef.current.__drawing && !latest.current.inspect) latest.current.onEventPick(e.features[0].properties.id); });
      }
      map.addLayer({ id: "pin", type: "circle", source: "pin", paint: { "circle-radius": 7, "circle-color": "#ff8a4c", "circle-stroke-color": "#fff", "circle-stroke-width": 2 } });
      map.on("click", (e) => { if (latest.current.inspect) latest.current.onMapClick(e.lngLat); });
      map.on("click", "fp-fill", (e) => {
        if (mapRef.current.__drawing || latest.current.inspect) return;
        if (map.queryRenderedFeatures(e.point, { layers: ["ev-eq", "ev-fl"] }).length) return;
        latest.current.onSelect(e.features[0].properties._id);
      });
      map.on("mousemove", "fp-fill", (e) => {
        if (mapRef.current.__drawing) return;
        map.getCanvas().style.cursor = "pointer";
        latest.current.onHover(e.features[0].properties._id);
      });
      map.on("mouseleave", "fp-fill", () => {
        if (mapRef.current.__drawing) return;
        map.getCanvas().style.cursor = "";
        latest.current.onHover(null);
      });
      map.on("moveend", () => {
        const c = map.getCenter();
        latest.current.onMove([c.lng, c.lat, map.getZoom()]);
      });
      ready.current = true;
      sync3d();
      sync();
      syncBs();
      syncOverlays();
      syncContext();
      syncEvents();
      drawOrbit();
    });
    const unsub = tracker.subscribe(drawOrbit);
    return () => { unsub(); map.remove(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(sync3d, [view3d.terrain, view3d.exaggeration, view3d.basemap, view3d.globe]);
  useEffect(syncBs, [layers.bs, layers.date, layers.mode, layers.days, layers.opacity]);
  useEffect(syncOverlays, [overlays, overlayOpacity, opacities]);
  useEffect(syncContext, [context.layer, context.date, context.opacity]);

  useEffect(sync, [features, selectedId, hoveredId, bbox, pin]);
  useEffect(syncEvents, [events, selectedEventId, eventsOn, ems]);
  useEffect(() => { const map = mapRef.current; if (map && ready.current) map.getCanvas().style.cursor = inspect ? "crosshair" : ""; }, [inspect]);

  // fit to all results after a search
  useEffect(() => {
    const map = mapRef.current;
    if (!fitKey || !map) return;
    const go = () => {
      const b = boundsOf(latest.current.features);
      if (b) map.fitBounds(b, { padding: 60, maxZoom: 8, duration: 600 });
    };
    ready.current ? go() : map.once("load", go);
  }, [fitKey]);


  const tilt = () => (latest.current.view3d.terrain ? 58 : 0);

  // a newly drawn (or typed) area: zoom to it
  useEffect(() => {
    const map = mapRef.current;
    if (!areaKey || !map) return;
    const go = () => {
      const b = latest.current.bbox;
      if (b) map.fitBounds([[b[0], b[1]], [b[2], b[3]]], { padding: 70, maxZoom: 13, duration: 900, pitch: tilt() });
    };
    ready.current ? go() : map.once("load", go);
  }, [areaKey]);

  // a result image put on the map: fly to it
  useEffect(() => {
    const map = mapRef.current;
    if (!ovFocus || !map || !ready.current) return;
    const lons = ovFocus.coords.map((c) => c[0]), lats = ovFocus.coords.map((c) => c[1]);
    map.fitBounds([[Math.min(...lons), Math.min(...lats)], [Math.max(...lons), Math.max(...lats)]], { padding: 70, maxZoom: 14, duration: 1100, pitch: tilt() });
  }, [ovFocus]);

  // cinematic fly-to (intro chapters)
  useEffect(() => {
    const map = mapRef.current;
    if (!fly || !map) return;
    map.flyTo({ center: fly.center, zoom: fly.zoom, pitch: 0, bearing: 0, duration: 5000, essential: true });
  }, [fly]);

  // the map follows its container when the side dock opens or closes
  useEffect(() => {
    const el = box.current;
    if (!el || typeof ResizeObserver === "undefined") return undefined;
    const ro = new ResizeObserver(() => mapRef.current?.resize());
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // buttons of the map toolbar
  useEffect(() => {
    const map = mapRef.current;
    if (!mapCmd || !map || !ready.current) return;
    if (mapCmd.type === "north") map.easeTo({ bearing: 0, pitch: tilt(), duration: 600 });
    if (mapCmd.type === "flat") map.easeTo({ pitch: 0, bearing: 0, duration: 600 });
    if (mapCmd.type === "spin") map.easeTo({ bearing: map.getBearing() + 90, duration: 900 });
    if (mapCmd.type === "fit") { const b = boundsOf(latest.current.features); if (b) map.fitBounds(b, { padding: 60, maxZoom: 9, duration: 700, pitch: tilt() }); }
  }, [mapCmd]);

  // zoom to a granule picked from the list or clicked on the map
  useEffect(() => {
    const map = mapRef.current;
    if (!focus || !map || !ready.current) return;
    const f = latest.current.features.find((x) => x.properties._id === focus.id);
    const b = f && boundsOf([f]);
    if (b) map.fitBounds(b, { padding: 80, maxZoom: 10, duration: 700, pitch: latest.current.view3d.terrain ? 55 : map.getPitch() });
  }, [focus]);

  // rectangle drawing
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    map.__drawing = drawing;
    if (!drawing) {
      map.dragPan.enable();
      map.getCanvas().style.cursor = "";
      return;
    }
    map.dragPan.disable();
    map.getCanvas().style.cursor = "crosshair";
    let start = null;
    const down = (e) => { start = e.lngLat; };
    const move = (e) => {
      if (start && ready.current) map.getSource("aoi").setData(bboxPoly(normBox(start, e.lngLat)));
    };
    const up = (e) => {
      if (!start) return;
      const b = normBox(start, e.lngLat);
      start = null;
      if (b[2] - b[0] > 0.01 && b[3] - b[1] > 0.01) latest.current.onDraw(b);
      else sync();
    };
    map.on("mousedown", down); map.on("mousemove", move); map.on("mouseup", up);
    map.on("touchstart", down); map.on("touchmove", move); map.on("touchend", up);
    return () => {
      map.off("mousedown", down); map.off("mousemove", move); map.off("mouseup", up);
      map.off("touchstart", down); map.off("touchmove", move); map.off("touchend", up);
    };
  }, [drawing]);

  return <div ref={box} className="map" role="application" aria-label="Map of NISAR acquisitions" />;
}
