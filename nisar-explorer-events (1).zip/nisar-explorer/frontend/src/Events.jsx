import { useEffect, useMemo, useRef, useState } from "react";
import { listEvents, planEvent, cemsOutline } from "./api.js";

const day = (s) => (s || "").slice(0, 10);
const ALERT = { red: "#d62728", orange: "#ff7f0e", green: "#2ca02c" };
const COV = { full: ["NISAR data", "#2ca02c"], partial: ["Limited BETA data", "#ff7f0e"], not_published: ["Not in archive yet", "#888"], instrument_gap: ["Instrument gap", "#d62728"], pre_mission: ["Before NISAR", "#888"] };
const gapDays = (a, b) => Math.round(Math.abs(Date.parse(a) - Date.parse(b)) / 864e5 * 10) / 10;

// events per week: earthquakes (orange) and floods (blue)
function Activity({ events, range }) {
  const bars = useMemo(() => {
    if (!events.length || !range) return null;
    const t0 = Date.parse(range[0]), t1 = Date.parse(range[1]);
    const n = Math.max(1, Math.min(60, Math.ceil((t1 - t0) / (7 * 864e5))));
    const b = Array.from({ length: n }, () => ({ eq: 0, fl: 0 }));
    for (const e of events) {
      const i = Math.min(n - 1, Math.max(0, Math.floor(((Date.parse(e.start) - t0) / (t1 - t0)) * n)));
      b[i][e.kind === "earthquake" ? "eq" : "fl"]++;
    }
    return b;
  }, [events, range]);
  if (!bars) return null;
  const max = Math.max(1, ...bars.map((x) => x.eq + x.fl)), w = 300 / bars.length;
  return (
    <svg viewBox="0 0 300 40" width="100%" height="40" role="img" aria-label="Events per week">
      {bars.map((x, i) => {
        const he = (x.eq / max) * 36, hf = (x.fl / max) * 36;
        return <g key={i}><rect x={i * w + 0.5} y={38 - he} width={Math.max(1, w - 1)} height={he} fill="#ff8a4c" /><rect x={i * w + 0.5} y={38 - he - hf} width={Math.max(1, w - 1)} height={hf} fill="#3aa0ff" /></g>;
      })}
    </svg>
  );
}

export default function Events({ onOpenPair, onShowEvent, onEvents, onSelect, eventsOn, setEventsOn, ems, setEms, externalPick }) {
  const [kind, setKind] = useState("all");
  const [days, setDays] = useState(90);
  const [minMag, setMinMag] = useState(6);
  const [withData, setWithData] = useState(true);
  const [st, setSt] = useState({ state: "idle" });
  const [events, setEvents] = useState([]);
  const [range, setRange] = useState(null);
  const [sel, setSel] = useState(null);
  const [plan, setPlan] = useState(null);
  const [pst, setPst] = useState({ state: "idle" });
  const [est, setEst] = useState({ state: "idle" });
  const [after, setAfter] = useState(null); // NISAR "after" date of the pair the person looks at
  const latest = useRef({});
  latest.current = { events };

  const load = async () => {
    setSt({ state: "loading" }); setSel(null); setPlan(null); setEms(null); onSelect(null);
    try {
      const end = new Date(), start = new Date(Date.now() - days * 864e5);
      const r = await listEvents({ kind, start: start.toISOString(), end: end.toISOString(), min_mag: minMag, limit: 300, with_data: withData });
      setEvents(r.events); setRange(r.range); onEvents(r.events); setEventsOn(true); setSt({ state: "done", errors: r.errors });
    } catch (e) { setEvents([]); onEvents([]); setSt({ state: "error", message: e.message }); }
  };

  const pick = async (ev) => {
    setSel(ev.id); onSelect(ev.id); setPlan(null); setEms(null); setEst({ state: "idle" }); setAfter(null); setPst({ state: "loading" });
    onShowEvent(ev);
    try {
      const p = await planEvent({ kind: ev.kind, lon: ev.lon, lat: ev.lat, start: ev.start, end: ev.end, bbox: ev.bbox.join(","), magnitude: ev.magnitude });
      setPlan(p); setAfter(p.pairs[0]?.after_time || null); setPst({ state: "done" });
    } catch (e) { setPst({ state: "error", message: e.message }); }
  };

  // a click on a dot of the map picks the same event
  useEffect(() => {
    if (!externalPick) return;
    const ev = latest.current.events.find((e) => e.id === externalPick.id);
    if (ev) pick(ev);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalPick]);

  const showOutline = async (code) => {
    setEst({ state: "loading" });
    try { setEms(await cemsOutline(code)); setEst({ state: "done" }); }
    catch (e) { setEms(null); setEst({ state: "error", message: e.message }); }
  };

  const ev = events.find((e) => e.id === sel);
  const counts = useMemo(() => ({ eq: events.filter((e) => e.kind === "earthquake").length, fl: events.filter((e) => e.kind === "flood").length }), [events]);
  return (
    <section className="filters" aria-label="Disaster events">
      <div className="row">
        <label className="field"><span className="label">Type</span>
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="all">Floods + earthquakes</option><option value="flood">Floods</option><option value="earthquake">Earthquakes</option>
          </select></label>
        <label className="field"><span className="label">Period</span>
          <select value={days} onChange={(e) => setDays(+e.target.value)}>
            <option value={30}>Last 30 days</option><option value={150}>Since 17 Jun 2026 (global archive)</option><option value={90}>Last 90 days</option><option value={365}>Last year</option>
          </select></label>
        <label className="field"><span className="label">Min. magnitude</span>
          <input type="number" min="4" max="9" step="0.1" value={minMag} onChange={(e) => setMinMag(+e.target.value)} /></label>
      </div>
      <label className="field"><span className="label">
        <input type="checkbox" checked={withData} onChange={(e) => setWithData(e.target.checked)} /> Only events whose date has NISAR products in the archive
      </span></label>
      <button className="btn pill" onClick={load} disabled={st.state === "loading"}>{st.state === "loading" ? "Loading…" : "Load events"}</button>
      {st.state === "error" && <p className="empty" role="alert">{st.message}</p>}
      {st.errors?.length > 0 && <p className="empty">Partial result. {st.errors.join(" · ")}</p>}
      {st.state === "done" && !events.length && <p className="empty">No events for these settings.{withData ? " Untick the filter to see events from dates the archive does not cover yet." : ""}</p>}

      {events.length > 0 && (
        <div className="evviz">
          <label className="field"><span className="label"><input type="checkbox" checked={eventsOn} onChange={(e) => setEventsOn(e.target.checked)} /> Show on the map</span></label>
          <Activity events={events} range={range} />
          <div className="evlegend" aria-label="Legend">
            <span><i style={{ background: "#ffd166" }} /> M &lt; 6</span>
            <span><i style={{ background: "#ff8a4c" }} /> M 6–7</span>
            <span><i style={{ background: "#e5383b" }} /> M ≥ 7</span>
            <span><i style={{ background: "#3aa0ff" }} /> Flood</span>
            <small>{counts.eq} earthquakes · {counts.fl} floods · dot size = magnitude</small>
          </div>
        </div>
      )}

      <ul className="evlist">
        {events.map((e) => (
          <li key={e.id}>
            <button className={e.id === sel ? "evitem on" : "evitem"} onClick={() => pick(e)}>
              <b>{e.kind === "earthquake" ? `M ${e.magnitude.toFixed(1)}` : "Flood"}</b>{" "}
              <span>{e.place || e.title}</span>
              <small> · {day(e.start)}{e.kind === "flood" && e.end !== e.start ? ` → ${day(e.end)}` : ""} · {(e.sources || [e.source]).join(", ")}</small>
              {e.nisar && <small className="evcov" style={{ color: COV[e.nisar.status]?.[1] }} title={e.nisar.text}> · {COV[e.nisar.status]?.[0]}</small>}
              {e.alert && <i className="dotalert" style={{ background: ALERT[e.alert] || "#888" }} title={`Alert ${e.alert}`} />}
            </button>
          </li>
        ))}
      </ul>

      {ev && (
        <div className="evplan">
          {ev.links?.length > 0 && <p className="empty">Reports: {ev.links.map((l, i) => <a key={i} href={l.url} target="_blank" rel="noreferrer">{l.source}</a>).reduce((a, b) => [a, " · ", b])}</p>}

          {ev.cems && (
            <div className="evems">
              <h4>Copernicus flood outline</h4>
              {!ems && <button className="btn" onClick={() => showOutline(ev.cems)} disabled={est.state === "loading"}>{est.state === "loading" ? "Loading outline…" : `Show on map (${ev.cems})`}</button>}
              {est.state === "error" && <p className="empty" role="alert">{est.message}</p>}
              {ems && (
                <>
                  <p className="empty"><i className="swatch" style={{ background: "#00e5ff" }} /> Observed flood (cyan) · white dashes = area they looked at. Put your NISAR flood map on top with “Show on map” in the Workbench result.</p>
                  <ul className="emsprod">
                    {ems.products.map((p) => (
                      <li key={p.label}>
                        <b>{p.label}</b> · seen {day(p.observed_time) || "?"}{p.sensors?.length ? ` (${p.sensors.join(", ")})` : ""}
                        {p.error ? <small> · {p.error}</small> : <small> · {p.area_km2} km² flooded · {p.features} polygons</small>}
                        {after && p.observed_time && <small> · {gapDays(p.observed_time, after)} d from your NISAR “after” scene</small>}
                      </li>
                    ))}
                  </ul>
                  {ems.truncated && <p className="empty">Very large outline: only the first polygons are drawn.</p>}
                  <p className="empty"><small>{ems.attribution}</small></p>
                  <button className="btn ghost" onClick={() => { setEms(null); setEst({ state: "idle" }); }}>Hide outline</button>
                </>
              )}
            </div>
          )}

          <h4>NISAR before / after</h4>
          {pst.state === "loading" && <p className="empty">Searching NISAR scenes over the affected area…</p>}
          {pst.state === "error" && <p className="empty" role="alert">{pst.message}</p>}
          {plan && !plan.pairs.length && <p className="empty">No usable before/after pair.{plan.diagnostics ? ` Scenes covering the point: ${plan.diagnostics.covering_granules} (${plan.diagnostics.before_event} before, ${plan.diagnostics.after_event} after).` : ""}</p>}
          {plan?.pairs.map((p, i) => (
            <div key={i} className="evpair" onMouseEnter={() => setAfter(p.after_time)}>
              <b>{p.level}</b> · {p.direction.toLowerCase()} · track {p.track} · frame {p.frame}
              <div>Before: {day(p.before_time)} ({p.days_before_event} d before) · After: {day(p.after_time)} ({p.days_after_event} d after)</div>
              <div><small>Maturity: {p.maturity || "?"}{p.mixed_maturity ? " ⚠ mixed processing versions" : ""} · Suggested: {p.modes.join(", ") || "—"}</small></div>
              <button className="btn" onClick={() => onOpenPair(p, ev, plan)}>Open in Workbench</button>
            </div>
          ))}
          {plan?.notes.map((n, i) => <p key={i} className="empty">{n}</p>)}
        </div>
      )}
    </section>
  );
}
