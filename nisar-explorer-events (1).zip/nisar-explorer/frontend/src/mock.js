// Demo footprints so the UI works without the backend (tick "Demo data").
// Mimics NISAR: 12-day repeat, slanted frames, ascending and descending tracks.
const rng = (seed) => () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);

function frame(lng, lat, dir) {
  const w = 1.9, h = 2.3, slant = dir === "ASCENDING" ? 0.5 : -0.5;
  return [
    [lng, lat],
    [lng + w, lat + slant * 0.4],
    [lng + w + slant * 0.5, lat + h],
    [lng + slant * 0.5, lat + h - slant * 0.4],
    [lng, lat],
  ];
}

export function mockSearch(f) {
  const [w, s, e, n] = f.bbox || [-14, 24, 6, 38];
  const rand = rng(42);
  const levels = f.levels.length ? f.levels : ["GCOV"];
  const feats = [];
  const t0 = new Date("2026-06-17T00:00:00Z").getTime();
  const tracks = [
    { dir: "ASCENDING", path: 82, lng: w + (e - w) * 0.25, lat: s + (n - s) * 0.2, hour: 18 },
    { dir: "DESCENDING", path: 119, lng: w + (e - w) * 0.55, lat: s + (n - s) * 0.1, hour: 6 },
  ];
  for (const t of tracks) {
    for (let k = 0; k < 10; k++) {
      const start = new Date(t0 + k * 12 * 864e5 + t.hour * 36e5 + (t.dir === "ASCENDING" ? 0 : 3 * 864e5));
      const ts = start.toISOString().slice(0, 16);
      const lo = f.start.length === 10 ? `${f.start}T00:00` : f.start;
      const hi = f.end.length === 10 ? `${f.end}T23:59` : f.end;
      if (ts < lo || ts > hi) continue;
      if (f.direction && f.direction !== t.dir) continue;
      for (let j = 0; j < 3; j++) {
        const lat = t.lat + j * 2.1 + rand() * 0.1;
        const level = levels[(k + j) % levels.length];
        const stop = new Date(start.getTime() + 25e3);
        const stamp = start.toISOString().replace(/[-:]/g, "").slice(0, 15);
        const name = `NISAR_L2_PR_${level}_${String(k + 1).padStart(3, "0")}_${t.path}_${t.dir[0]}_${String(j + 1).padStart(3, "0")}_DEMO_${stamp}`;
        feats.push({
          type: "Feature",
          geometry: { type: "Polygon", coordinates: [frame(t.lng, lat, t.dir)] },
          properties: {
            sceneName: name,
            fileName: name + ".h5",
            startTime: start.toISOString(),
            stopTime: stop.toISOString(),
            processingLevel: level,
            flightDirection: t.dir,
            pathNumber: t.path,
            frameNumber: 100 + j,
            mainBandPolarization: ["HH", "HV"],
            productionConfiguration: "PR",
            dataMaturity: "PROVISIONAL",
            bytes: { [name + ".h5"]: { bytes: 2.4e9 + rand() * 1.5e9, format: "HDF5" } },
            browse: [],
            url: `demo:${level}:${k}:${t.dir === "ASCENDING" ? "Ascending" : "Descending"}`,
            _demo: true,
          },
        });
      }
    }
  }
  return new Promise((r) => setTimeout(() => r({ type: "FeatureCollection", features: feats }), 400));
}
