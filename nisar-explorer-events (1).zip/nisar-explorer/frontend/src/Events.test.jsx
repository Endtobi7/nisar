import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor, cleanup } from "@testing-library/react";

afterEach(cleanup);

vi.mock("./api.js", () => ({
  listEvents: vi.fn(async () => ({
    range: ["2026-08-20T00:00:00Z", "2026-11-13T00:00:00Z"], errors: [],
    events: [
      { id: "us1", kind: "earthquake", magnitude: 6.8, place: "Quakeville", lon: 37, lat: 36.5, start: "2026-09-20T01:00:00Z", end: "2026-09-20T01:00:00Z", source: "USGS", sources: ["USGS"], bbox: [36, 36, 38, 37], nisar: { status: "full", text: "ok" }, links: [] },
      { id: "FL-7", kind: "flood", place: "Y", title: "Flood in Y", lon: 10, lat: 5, start: "2026-09-01T00:00:00Z", end: "2026-09-09T00:00:00Z", source: "GDACS", sources: ["GDACS", "Copernicus EMS"], alert: "orange", cems: "EMSR900", bbox: [9, 4, 11, 6], nisar: { status: "full", text: "ok" }, links: [{ source: "GDACS", url: "http://r" }] },
    ],
  })),
  planEvent: vi.fn(async () => ({ bbox: [9, 4, 11, 6], notes: ["Flood water can recede."], diagnostics: { covering_granules: 2, before_event: 1, after_event: 1 },
    pairs: [{ level: "GCOV", direction: "ASCENDING", track: 10, frame: 100, before_time: "2026-08-25T03:00:00Z", after_time: "2026-09-04T03:00:00Z", days_before_event: 6.1, days_after_event: 0, modes: ["flood"], maturity: "PROVISIONAL", mixed_maturity: false, before: {}, after: {} }] })),
  cemsOutline: vi.fn(async () => ({ code: "EMSR900", attribution: "© European Union, Copernicus EMS", truncated: false,
    products: [{ label: "AOI01_DEL", observed_time: "2026-09-03T05:30:00Z", sensors: ["Sentinel-1"], area_km2: 12.5, features: 4 }],
    outline: { type: "FeatureCollection", features: [] }, observed_mask: { type: "FeatureCollection", features: [] } })),
}));

import Events from "./Events.jsx";

describe("Events panel", () => {
  it("lists events, draws them on the map, plans scenes and shows the Copernicus outline with its date gap", async () => {
    const props = { onOpenPair: vi.fn(), onShowEvent: vi.fn(), onEvents: vi.fn(), onSelect: vi.fn(), eventsOn: true, setEventsOn: vi.fn(), ems: null, setEms: vi.fn(), externalPick: null };
    const { rerender } = render(<Events {...props} />);
    fireEvent.click(screen.getByText("Load events"));
    await screen.findByText("Quakeville");
    expect(props.onEvents).toHaveBeenCalledWith(expect.arrayContaining([expect.objectContaining({ id: "us1" })]));   // the map gets the dots
    expect(screen.getByText(/1 earthquakes · 1 floods/)).toBeTruthy();

    fireEvent.click(screen.getByText("Y"));
    expect(props.onSelect).toHaveBeenCalledWith("FL-7");
    await screen.findByText("Open in Workbench");
    fireEvent.click(screen.getByText("Show on map (EMSR900)"));
    await waitFor(() => expect(props.setEms).toHaveBeenCalledWith(expect.objectContaining({ code: "EMSR900" })));

    // parent stores the outline and hands it back: the panel then shows areas and the gap to the NISAR "after" scene
    const ems = (await import("./api.js")).cemsOutline.mock.results[0].value;
    rerender(<Events {...props} ems={await ems} />);
    expect(screen.getByText(/12.5 km² flooded/)).toBeTruthy();
    expect(screen.getByText(/0.9 d from your NISAR/)).toBeTruthy();
    fireEvent.click(screen.getByText("Open in Workbench"));
    expect(props.onOpenPair).toHaveBeenCalled();
  });

  it("a click on a map dot selects the same event", async () => {
    const props = { onOpenPair: vi.fn(), onShowEvent: vi.fn(), onEvents: vi.fn(), onSelect: vi.fn(), eventsOn: true, setEventsOn: vi.fn(), ems: null, setEms: vi.fn() };
    const { rerender } = render(<Events {...props} externalPick={null} />);
    fireEvent.click(screen.getByText("Load events"));
    await screen.findByText("Quakeville");
    rerender(<Events {...props} externalPick={{ id: "us1", t: 1 }} />);
    await waitFor(() => expect(props.onSelect).toHaveBeenCalledWith("us1"));
  });
});
