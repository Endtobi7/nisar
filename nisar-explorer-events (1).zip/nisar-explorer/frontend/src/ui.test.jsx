import { vi, test, expect, beforeAll } from "vitest";
import { render, screen, waitFor, within, fireEvent, cleanup } from "@testing-library/react";

vi.mock("maplibre-gl", () => {
  const src = { setData() {}, setCoordinates() {} };
  class Map {
    constructor() { this.dragPan = { enable() {}, disable() {} }; setTimeout(() => this._load && this._load(), 0); }
    addControl() {} addSource() {} addLayer() {} removeLayer() {} removeSource() {} setFilter() {} setPaintProperty() {} setLayoutProperty() {}
    getSource() { return src; } getLayer() { return null; } fitBounds() {} easeTo() {} remove() {} getCanvas() { return { style: {} }; }
    getCenter() { return { lng: 0, lat: 0 }; } getZoom() { return 2; } once() {}
    setTerrain() {} setProjection() {} getPitch() { return 0; } getBearing() { return 0; } flyTo() {}
    on(ev, a, b) { if (ev === "load") this._load = a; }
  }
  class NavigationControl {}
  class Popup { setLngLat() { return this; } setText() { return this; } addTo() { return this; } remove() {} }
  class LngLatBounds { constructor() { this.e = false; } extend() { this.e = true; } isEmpty() { return !this.e; } }
  return { default: { Map, NavigationControl, LngLatBounds, Popup } };
});

beforeAll(() => {
  window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));
  Element.prototype.scrollIntoView = () => {};
});

import App from "./App.jsx";

test("guide, single-file analysis with extras, workbench pair and series (demo data, real backend)", async () => {
  render(<App />);

  // guide: all analyses listed, French by switching language
  fireEvent.click(screen.getByText("Guide"));
  await screen.findByText(/74 analyses/);
  fireEvent.click(screen.getByRole("button", { name: "FR" }));
  expect(screen.getByText(/Disponibles dans l'application \(63\)/)).toBeTruthy();
  fireEvent.click(screen.getByLabelText("Close guide"));

  // search in demo mode
  fireEvent.click(screen.getByLabelText(/Demo data/));
  fireEvent.click(screen.getByRole("button", { name: "Search NISAR" }));
  await screen.findByText(/\d+ granules/, { selector: ".count" }, { timeout: 10000 });
  const items = [...document.querySelectorAll(".list .item")];
  expect(items.length).toBeGreaterThan(3);
  fireEvent.click(items[0]);

  // analyse with an extra analysis
  const extra = await screen.findByLabelText("Automatic water map and area", {}, { timeout: 10000 });
  fireEvent.click(extra);
  fireEvent.click(screen.getByText("Run analysis"));
  await screen.findByText("Water share", {}, { timeout: 30000 });
  expect(screen.getByText("Automatic water threshold")).toBeTruthy();
  expect(screen.getAllByText("GeoTIFF").length).toBeGreaterThan(0);

  // coverage insights are listed under the results
  fireEvent.click(screen.getByText("Coverage and next passes"));
  expect(screen.getAllByText(/Next \(predicted, UTC\)/).length).toBeGreaterThan(0);

  // add six granules of one track (one per date) to the workbench
  const seen = new Set();
  let added = 0;
  for (const el of [...document.querySelectorAll(".list .item")]) {
    const txt = el.textContent;
    const date = txt.slice(4, 14);
    if (!txt.includes("ascending") || !txt.includes("path 82") || seen.has(date) || added >= 6) continue;
    seen.add(date);
    fireEvent.click(el);
    const btn = await screen.findByText(/^(Add to|Remove from) workbench$/);
    if (btn.textContent.startsWith("Add")) { fireEvent.click(btn); added++; }
  }
  expect(added).toBe(6);
  fireEvent.click(screen.getByText(/Workbench \(6\)/));
  await screen.findByText("Analysis workbench");
  const dlg = screen.getByRole("dialog");
  await waitFor(() => expect(within(dlg).getByText(/GCOV before and after change map/)).toBeTruthy(), { timeout: 10000 });
  fireEvent.click(within(dlg).getByText("Run analysis"));
  await within(dlg).findByText("Change threshold", {}, { timeout: 30000 });

  // flood analysis through the analysis selector
  fireEvent.change(within(dlg).getAllByRole("combobox").find((s) => [...s.options].some((o) => /Flood extent/.test(o.text))), { target: { value: "flood" } });
  fireEvent.click(within(dlg).getByText("Run analysis"));
  await within(dlg).findByText("New open water (flooded)", {}, { timeout: 30000 });

  // time series: backscatter series, then date of first change
  fireEvent.click(within(dlg).getByRole("tab", { name: "Time series" }));
  fireEvent.click(within(dlg).getByText("Run analysis"));
  await within(dlg).findByText("Largest drop between two dates", {}, { timeout: 60000 });
  expect(dlg.querySelectorAll("svg[role=img]").length).toBeGreaterThan(0);
  fireEvent.change(within(dlg).getAllByRole("combobox")[0], { target: { value: "first_change" } });
  fireEvent.click(within(dlg).getByText("Run analysis"));
  await within(dlg).findByText("Pixels that changed", {}, { timeout: 60000 });
});
