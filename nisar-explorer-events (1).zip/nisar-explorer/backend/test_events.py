"""Tests for the event catalog and the before/after planner. Every network call is faked."""
from datetime import datetime, timezone
import pytest
from fastapi.testclient import TestClient

import events
from main import app

client = TestClient(app)
T = lambda s: datetime.fromisoformat(s).replace(tzinfo=timezone.utc)


def scene(name, when, lvl="GCOV", d="ASCENDING", track=10, frame=100, box=(34, 36, 38, 38)):
    w, s, e, n = box
    return {"type": "Feature", "geometry": {"type": "Polygon", "coordinates": [[[w, s], [e, s], [e, n], [w, n], [w, s]]]},
            "properties": {"sceneName": name, "startTime": when, "processingLevel": lvl, "flightDirection": d, "pathNumber": track, "frameNumber": frame}}


def test_quake_radius_grows_with_magnitude_and_is_capped():
    assert events.quake_radius_km(5.0) == 15.0
    assert events.quake_radius_km(7.8) > events.quake_radius_km(6.5)
    assert events.quake_radius_km(9.5) == 150.0


def test_pairing_takes_last_before_and_first_after_on_same_track():
    fs = [scene("b1", "2026-01-01T03:00:00Z"), scene("b2", "2026-01-13T03:00:00Z"),
          scene("a1", "2026-02-10T03:00:00Z"), scene("a2", "2026-02-22T03:00:00Z")]
    pairs, _ = events.pair_scenes(fs, 36.0, 37.0, T("2026-02-06T01:00:00"), T("2026-02-06T01:00:00"), ("GCOV",), 30)
    assert len(pairs) == 1
    p = pairs[0]
    assert p["before"]["properties"]["sceneName"] == "b2" and p["after"]["properties"]["sceneName"] == "a1"
    assert p["days_before_event"] == pytest.approx(23.9, abs=0.1) and p["days_after_event"] == pytest.approx(4.1, abs=0.1)


def test_no_pair_across_different_tracks_or_directions():
    fs = [scene("b", "2026-01-13T03:00:00Z", track=10), scene("a", "2026-02-10T03:00:00Z", track=11),
          scene("c", "2026-02-11T03:00:00Z", d="DESCENDING", track=10)]
    pairs, _ = events.pair_scenes(fs, 36.0, 37.0, T("2026-02-06T00:00:00"), T("2026-02-06T00:00:00"), ("GCOV",), 30)
    assert pairs == []


def test_footprint_must_cover_the_event_point():
    fs = [scene("b", "2026-01-13T03:00:00Z", box=(0, 0, 1, 1)), scene("a", "2026-02-10T03:00:00Z", box=(0, 0, 1, 1))]
    pairs, _ = events.pair_scenes(fs, 36.0, 37.0, T("2026-02-06T00:00:00"), T("2026-02-06T00:00:00"), ("GCOV",), 30)
    assert pairs == []


def test_after_scene_outside_wait_window_is_ignored():
    fs = [scene("b", "2026-01-13T03:00:00Z"), scene("a", "2026-05-01T03:00:00Z")]
    pairs, _ = events.pair_scenes(fs, 36.0, 37.0, T("2026-02-06T00:00:00"), T("2026-02-06T00:00:00"), ("GCOV",), 30)
    assert pairs == []


def test_flood_duration_measures_gap_from_end_of_flood():
    fs = [scene("b", "2026-01-13T03:00:00Z"), scene("a", "2026-02-20T03:00:00Z")]
    pairs, _ = events.pair_scenes(fs, 36.0, 37.0, T("2026-02-01T00:00:00"), T("2026-02-15T00:00:00"), ("GCOV",), 30)
    assert pairs[0]["days_after_event"] == pytest.approx(5.1, abs=0.1)


USGS = {"features": [{"id": "us1", "properties": {"mag": 6.8, "time": 1790000000000, "title": "M 6.8 - X", "place": "X", "url": "u"},
                      "geometry": {"coordinates": [37.0, 36.5, 10]}}]}
GD = {"features": [{"properties": {"eventid": 77, "name": "Flood in Y", "country": "Y", "fromdate": "2026-09-01T00:00:00", "todate": "2026-09-09T00:00:00",
                                   "alertlevel": "Orange", "severitydata": {"severitytext": "Medium"}, "url": {"report": "r"}},
                    "geometry": {"coordinates": [10.0, 5.0]}, "bbox": [9.5, 4.5, 10.5, 5.5]}]}
EO = {"events": [{"id": "EONET_1", "title": "Floods in Y region", "link": "l", "closed": None,
                  "sources": [{"id": "FloodList", "url": "fl"}], "geometry": [{"date": "2026-09-03T00:00:00Z", "type": "Point", "coordinates": [10.2, 5.1]}]},
                 {"id": "EONET_2", "title": "Floods far away", "link": "l2", "closed": None, "sources": [],
                  "geometry": [{"date": "2026-09-03T00:00:00Z", "type": "Polygon", "coordinates": [[[100, 10], [101, 10], [101, 11], [100, 11], [100, 10]]]}]}]}
CE = {"results": [{"code": "EMSR900", "category": "Flood", "name": "Flood in Y", "countries": ["Y"], "eventTime": "2026-09-02T12:00:00",
                   "centroid": "POINT (10.1 5.05)"},
                  {"code": "EMSR901", "category": "Wildfire", "eventTime": "2026-09-02T12:00:00", "centroid": "POINT (1 1)"}], "next": None}


def fake(url, p):
    return {events.USGS_URL: USGS, events.GDACS_URL: GD, events.EONET_URL: EO, events.CEMS_URL: CE}[url]


def test_archive_status_follows_the_asf_release_windows():
    st = lambda s: events.archive_status(T(s))
    assert st("2025-05-01T00:00:00") == "pre_mission" and st("2025-09-01T00:00:00") == "not_published"
    assert st("2025-12-01T00:00:00") == "partial" and st("2026-03-01T00:00:00") == "not_published"
    assert st("2026-06-17T00:00:00") == "full" and st("2026-08-01T00:00:00") == "instrument_gap" and st("2026-08-11T00:00:00") == "full"


def test_same_flood_from_three_sources_becomes_one_event(monkeypatch):
    monkeypatch.setattr(events, "_get_json", fake)
    j = client.get("/api/events", params={"start": "2026-08-20", "end": "2026-10-01"}).json()
    fl = [e for e in j["events"] if e["kind"] == "flood"]
    assert len(fl) == 2                                   # Y (merged: GDACS + EONET + CEMS) and the far-away EONET one
    y = next(e for e in fl if "Y" in (e["place"] or "") or e["source"] == "GDACS")
    assert set(y["sources"]) >= {"GDACS", "EONET", "FloodList", "Copernicus EMS"} and y["alert"] == "orange"
    assert y["bbox"] == [9.5, 4.5, 10.5, 5.5] and len(y["links"]) == 3 and y["title"] == "Flood in Y"
    assert all(e["nisar"]["status"] == "full" for e in j["events"]) and j["errors"] == []


def test_with_data_hides_dates_that_have_no_nisar_products(monkeypatch):
    old = {"features": [{"properties": {"eventid": 5, "name": "Old", "fromdate": "2026-03-01T00:00:00", "todate": "2026-03-02T00:00:00"}, "geometry": {"coordinates": [1, 1]}}]}
    monkeypatch.setattr(events, "_get_json", lambda u, p: old if u == events.GDACS_URL else {"features": [], "events": [], "results": [], "next": None})
    assert len(client.get("/api/events", params={"start": "2026-02-01", "end": "2026-04-01"}).json()["events"]) == 1
    assert client.get("/api/events", params={"start": "2026-02-01", "end": "2026-04-01", "with_data": True}).json()["events"] == []


def test_one_failing_source_is_reported_not_fatal(monkeypatch):
    def flaky(url, p):
        if url in (events.GDACS_URL, events.CEMS_URL):
            raise RuntimeError("down")
        return fake(url, p)
    monkeypatch.setattr(events, "_get_json", flaky)
    j = client.get("/api/events", params={"start": "2026-08-20", "end": "2026-10-01"}).json()
    assert len(j["errors"]) == 2 and any(e["kind"] == "flood" for e in j["events"])
    monkeypatch.setattr(events, "_get_json", lambda u, p: (_ for _ in ()).throw(RuntimeError("down")))
    assert client.get("/api/events", params={"start": "2026-08-20", "end": "2026-10-01"}).status_code == 502


def test_mixed_maturity_is_flagged_and_same_maturity_preferred():
    b1, a1 = scene("b1", "2026-09-01T03:00:00Z"), scene("a1", "2026-09-22T03:00:00Z")
    b1["properties"]["dataMaturity"], a1["properties"]["dataMaturity"] = "BETA", "PROVISIONAL"
    pairs, _ = events.pair_scenes([b1, a1], 36.0, 37.0, T("2026-09-20T00:00:00"), T("2026-09-20T00:00:00"), ("GCOV",), 30)
    assert pairs[0]["mixed_maturity"] and pairs[0]["maturity"] == "BETA+PROVISIONAL"
    b2 = scene("b2", "2026-09-10T03:00:00Z")
    b2["properties"]["dataMaturity"] = "PROVISIONAL"
    pairs, _ = events.pair_scenes([b1, b2, a1], 36.0, 37.0, T("2026-09-20T00:00:00"), T("2026-09-20T00:00:00"), ("GCOV",), 30)
    assert not pairs[0]["mixed_maturity"] and pairs[0]["before"]["properties"]["sceneName"] == "b2"


def test_plan_pairs_and_explains_why_not(monkeypatch):
    q = dict(kind="earthquake", lon=36.0, lat=37.0, start="2026-09-20T01:00:00Z", magnitude=7.8)
    fs = [scene("b", "2026-09-08T03:00:00Z", lvl="GSLC"), scene("a", "2026-09-22T03:00:00Z", lvl="GSLC")]
    monkeypatch.setattr(events, "_asf_search", lambda *a, **k: fs)
    j = client.get("/api/events/plan", params=q).json()
    assert len(j["pairs"]) == 1 and j["pairs"][0]["modes"] == ["gslc_ifg"] and j["diagnostics"]["before_event"] == 1
    monkeypatch.setattr(events, "_asf_search", lambda *a, **k: [fs[1]])
    assert "No scene BEFORE" in " ".join(client.get("/api/events/plan", params=q).json()["notes"])
    monkeypatch.setattr(events, "_asf_search", lambda *a, **k: [fs[0]])
    assert "No scene AFTER" in " ".join(client.get("/api/events/plan", params=q).json()["notes"])
    monkeypatch.setattr(events, "_asf_search", lambda *a, **k: [fs[0], scene("a2", "2026-09-22T03:00:00Z", lvl="GSLC", track=99)])
    assert "same track" in " ".join(client.get("/api/events/plan", params=q).json()["notes"])


def test_plan_skips_asf_when_the_archive_cannot_have_data(monkeypatch):
    def boom(*a, **k):
        raise AssertionError("ASF must not be queried")
    monkeypatch.setattr(events, "_asf_search", boom)
    for when, status in (("2026-03-10T00:00:00Z", "not_published"), ("2026-08-01T00:00:00Z", "instrument_gap"), ("2025-03-01T00:00:00Z", "pre_mission")):
        j = client.get("/api/events/plan", params={"kind": "flood", "lon": 1, "lat": 1, "start": when}).json()
        assert j["archive_status"] == status and j["pairs"] == [] and j["notes"]
    assert client.get("/api/events/plan", params={"kind": "flood", "lon": 1, "lat": 1, "start": "2999-01-01"}).status_code == 400


# ---- Copernicus EMS observed flood outline
HOST = "https://rapidmapping.emergency.copernicus.eu/backend/"
SQ = lambda x0, y0, d=0.1: {"type": "Polygon", "coordinates": [[[x0, y0], [x0 + d, y0], [x0 + d, y0 + d], [x0, y0 + d], [x0, y0]]]}
DETAIL = {"results": [{"code": "EMSR900", "name": "Flood in Y", "eventTime": "2026-09-02T12:00:00", "reportLink": "r", "aois": [{
    "name": "A", "number": 1, "products": [
        {"type": "DEL", "monitoring": False, "feasible": True, "extent": "POLYGON ((0 0, 1 0, 1 1, 0 1, 0 0))",
         "images": [{"new": False, "sensorName": "old", "acquisitionTime": "2026-08-01T10:00:00"},
                    {"new": True, "sensorName": "Sentinel-1", "acquisitionTime": "2026-09-03T05:30:00"}],
         "layers": [{"name": "EMSR900/AOI01/DEL_PRODUCT/EMSR900_AOI01_DEL_PRODUCT_observedEventA_v1_VT", "format": "vt", "json": HOST + "v1.json"},
                    {"name": "EMSR900/AOI01/DEL_PRODUCT/EMSR900_AOI01_DEL_PRODUCT_observedEventA_v2_VT", "format": "vt", "json": HOST + "v2.json"}]},
        {"type": "DEL", "monitoring": True, "monitoringNumber": 1, "feasible": True, "images": [],
         "layers": [{"name": "x_observedEventA_v1_VT", "format": "vt", "json": "https://evil.example.com/x.json"}]},
    ]}]}]}
LAYERS = {HOST + "v2.json": {"type": "FeatureCollection", "features": [
    {"type": "Feature", "properties": {"event_type": "5-Flood", "notation": "Flooded area"}, "geometry": SQ(0.2, 0.2)},
    {"type": "Feature", "properties": {"event_type": "6-Mass Movement"}, "geometry": SQ(0.5, 0.5)}]}}


def test_cems_outline_uses_latest_layer_flood_features_and_observation_time(monkeypatch):
    monkeypatch.setattr(events, "_get_json", lambda u, p: DETAIL)
    seen = []
    monkeypatch.setattr(events, "_fetch_layer", lambda url: (seen.append(url), LAYERS[url])[1])
    j = client.get("/api/events/cems/EMSR900/flood").json()
    assert seen == [HOST + "v2.json"]                                   # latest version only; the foreign host is never fetched
    p = j["products"][0]
    assert p["label"] == "AOI01_DEL" and p["features"] == 1 and p["observed_time"] == "2026-09-03T05:30:00Z" and p["sensors"] == ["Sentinel-1", "old"]
    assert 100 < p["area_km2"] < 130                                    # 0.1 x 0.1 degree near the equator is ~123 km2
    assert j["products"][1]["error"] and len(j["outline"]["features"]) == 1 and len(j["observed_mask"]["features"]) == 1
    assert "Copernicus" in j["attribution"]


def test_cems_outline_rejects_bad_codes_and_unknown_activations(monkeypatch):
    assert client.get("/api/events/cems/not-a-code/flood").status_code == 400
    monkeypatch.setattr(events, "_get_json", lambda u, p: {"results": []})
    assert client.get("/api/events/cems/EMSR1/flood").status_code == 404
