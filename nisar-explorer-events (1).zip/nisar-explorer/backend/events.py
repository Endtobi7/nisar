"""Disaster events -> NISAR before/after scenes.

Two endpoints:
  GET /api/events        list earthquakes (USGS) and floods (GDACS) for a date range / area
  GET /api/events/plan   for ONE event, find the NISAR granules acquired before and after it
                         and pair them (same track, same direction, same product level) so the
                         workbench can run the change analysis straight away.

All sources are public and need no key. Earthquakes: USGS. Floods: GDACS + NASA EONET (which relays FloodList,
ReliefWeb, GLIDE, ...) + Copernicus EMS Rapid Mapping; the same flood reported by several sources is merged into one
event. The events are fetched live in parallel (nothing is stored), with a short in-memory cache.

NISAR acquires nearly all land every 12 days, but the ASF ARCHIVE has release windows (see archive_status), so every
event carries an availability label and the planner says plainly why a before/after pair is missing.
"""
import math
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from typing import Optional

import requests
from fastapi import APIRouter, HTTPException, Query

router = APIRouter()

USGS_URL = "https://earthquake.usgs.gov/fdsnws/event/1/query"
GDACS_URL = "https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH"
EONET_URL = "https://eonet.gsfc.nasa.gov/api/v3/events"
CEMS_URL = "https://rapidmapping.emergency.copernicus.eu/backend/dashboard-api/public-activations-info/"
CACHE_TTL = 600
_cache: dict = {}

# product levels worth pulling per hazard, and the workbench analysis that fits them
HAZARD = {
    "flood": {"levels": ("GCOV",), "modes": [("flood", "GCOV"), ("gcov_change", "GCOV")]},
    "earthquake": {"levels": ("GSLC", "GUNW", "GCOV"), "modes": [("gslc_ifg", "GSLC"), ("coherence_change", "GUNW"), ("gcov_change", "GCOV")]},
}


# --------------------------------------------------------------------------- what is in the ASF archive
# Source: NISAR Data User Guide "Available NISAR Data" (Nov 2026). Edit here when ASF publishes new releases.
UTC = timezone.utc
ARCHIVE = {
    "mission_start": datetime(2025, 8, 1, tzinfo=UTC),         # L-band collection began
    "beta": (datetime(2025, 10, 17, tzinfo=UTC), datetime(2026, 1, 20, 23, 59, tzinfo=UTC)),  # Feb 2026 release: a SUBSET (<= 8 acquisitions per track)
    "provisional_from": datetime(2026, 6, 17, tzinfo=UTC),     # global, all acquisitions
    "instrument_gap": (datetime(2026, 7, 27, 22, 3, 25, tzinfo=UTC), datetime(2026, 8, 10, 0, 55, 27, tzinfo=UTC)),  # permanent, no data exists
}
STATUS_TEXT = {
    "full": "Global NISAR products are in the ASF archive for this date.",
    "partial": "Only a SUBSET of NISAR data (BETA release, up to 8 acquisitions per track, not fully calibrated) is in the archive for this date.",
    "not_published": "NISAR collected here, but products for this date are not in the ASF archive yet (planned for the 2027 reprocessing).",
    "instrument_gap": "NISAR has a permanent instrument data gap (27 Jul to 10 Aug 2026): no data exists for this date.",
    "pre_mission": "This is before NISAR began collecting (Aug 2025).",
}


def archive_status(t: datetime) -> str:
    if t < ARCHIVE["mission_start"]:
        return "pre_mission"
    if ARCHIVE["instrument_gap"][0] <= t <= ARCHIVE["instrument_gap"][1]:
        return "instrument_gap"
    if t >= ARCHIVE["provisional_from"]:
        return "full"
    if ARCHIVE["beta"][0] <= t <= ARCHIVE["beta"][1]:
        return "partial"
    return "not_published"


# --------------------------------------------------------------------------- helpers
def _now():
    return datetime.now(timezone.utc)


def parse_time(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    s = s.strip().replace("Z", "+00:00")
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        try:
            d = datetime.strptime(s[:10], "%Y-%m-%d")
        except ValueError:
            return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def iso(d: datetime) -> str:
    return d.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _get_json(url, params):
    key = (url, tuple(sorted(params.items())))
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < CACHE_TTL:
        return hit[1]
    r = requests.get(url, params=params, timeout=25, headers={"User-Agent": "nisar-explorer/1.0"})
    r.raise_for_status()
    data = r.json()
    _cache[key] = (time.time(), data)
    if len(_cache) > 200:
        _cache.pop(next(iter(_cache)))
    return data


def quake_radius_km(mag: float) -> float:
    """Area worth looking at around an epicentre: twice the typical rupture length (Wells & Coppersmith), 15-150 km."""
    rupture = 10 ** (0.59 * mag - 2.44)
    return max(15.0, min(150.0, 2 * rupture))


def box_around(lon, lat, radius_km):
    dlat = radius_km / 111.0
    dlon = radius_km / (111.0 * max(0.2, math.cos(math.radians(lat))))
    return [round(max(-180, lon - dlon), 4), round(max(-90, lat - dlat), 4), round(min(180, lon + dlon), 4), round(min(90, lat + dlat), 4)]


# --------------------------------------------------------------------------- event sources
def usgs_quakes(start, end, min_mag, bbox, limit):
    p = {"format": "geojson", "starttime": iso(start), "endtime": iso(end), "minmagnitude": min_mag, "orderby": "time", "limit": limit}
    if bbox:
        p.update(minlongitude=bbox[0], minlatitude=bbox[1], maxlongitude=bbox[2], maxlatitude=bbox[3])
    out = []
    for f in _get_json(USGS_URL, p).get("features", []):
        pr, g = f.get("properties", {}), f.get("geometry") or {}
        c = g.get("coordinates") or []
        if len(c) < 2 or pr.get("mag") is None or pr.get("time") is None:
            continue
        t = datetime.fromtimestamp(pr["time"] / 1000, tz=timezone.utc)
        mag = float(pr["mag"])
        out.append({
            "id": f["id"], "kind": "earthquake", "source": "USGS", "sources": ["USGS"], "title": pr.get("title") or f"M {mag}",
            "place": pr.get("place"), "lon": c[0], "lat": c[1], "depth_km": c[2] if len(c) > 2 else None,
            "start": iso(t), "end": iso(t), "magnitude": mag, "alert": pr.get("alert"),
            "url": pr.get("url"), "bbox": box_around(c[0], c[1], quake_radius_km(mag)),
        })
    return out


def _mk_flood(id_, source, title, place, lon, lat, t0, t1, bbox, bbox_q, alert=None, severity=None, url=None):
    return {"id": id_, "kind": "flood", "source": source, "sources": [source], "title": title, "place": place, "lon": lon, "lat": lat,
            "start": iso(t0), "end": iso(t1), "magnitude": None, "alert": alert, "severity": severity, "url": url,
            "links": [{"source": source, "url": url}] if url else [], "cems": None, "bbox": [round(x, 4) for x in bbox], "_bq": bbox_q}


def _clamp_box(bb, lon, lat):
    """GDACS/EONET boxes can span a country; keep the analysis window small enough to process."""
    bb = [float(x) for x in bb]
    return (bb if (bb[2] - bb[0] <= 3 and bb[3] - bb[1] <= 3) else box_around(lon, lat, 80)), 2


def gdacs_floods(start, end, bbox, limit):
    p = {"eventlist": "FL", "fromdate": start.strftime("%Y-%m-%d"), "todate": end.strftime("%Y-%m-%d"),
         "alertlevel": "green;orange;red", "pagesize": min(limit, 100), "pagenumber": 1}  # the API hides Green unless asked
    out = []
    for f in _get_json(GDACS_URL, p).get("features", []):
        pr, g = f.get("properties", {}), f.get("geometry") or {}
        c = g.get("coordinates") or []
        if len(c) < 2:
            continue
        t0 = parse_time(pr.get("fromdate"))
        t1 = parse_time(pr.get("todate")) or t0
        if not t0:
            continue
        bb = f.get("bbox")
        bb, q = _clamp_box(bb, c[0], c[1]) if isinstance(bb, list) and len(bb) == 4 else (box_around(c[0], c[1], 40), 1)
        sev = pr.get("severitydata") or {}
        url = pr.get("url") or {}
        out.append(_mk_flood(f"FL-{pr.get('eventid')}", "GDACS", pr.get("name") or pr.get("description") or "Flood", pr.get("country"),
                             c[0], c[1], t0, t1, bb, q, (pr.get("alertlevel") or "").lower() or None,
                             sev.get("severitytext") or sev.get("severity"), url.get("report") if isinstance(url, dict) else None))
    return out


def _geom_center_box(g):
    """(lon, lat, bbox or None) of an EONET geometry (Point or Polygon)."""
    c = g.get("coordinates")
    if g.get("type") == "Point" and c and len(c) >= 2:
        return c[0], c[1], None
    if g.get("type") == "Polygon" and c and c[0]:
        xs, ys = [p[0] for p in c[0]], [p[1] for p in c[0]]
        return sum(xs) / len(xs), sum(ys) / len(ys), [min(xs), min(ys), max(xs), max(ys)]
    return None


def eonet_floods(start, end, limit):
    p = {"category": "floods", "status": "all", "start": start.strftime("%Y-%m-%d"), "end": end.strftime("%Y-%m-%d"), "limit": min(limit * 2, 500)}
    out = []
    for e in _get_json(EONET_URL, p).get("events", []):
        geoms = [(parse_time(g.get("date")), _geom_center_box(g)) for g in e.get("geometry", [])]
        geoms = [(t, c) for t, c in geoms if t and c]
        if not geoms:
            continue
        geoms.sort(key=lambda x: x[0])
        t0, t1 = geoms[0][0], geoms[-1][0]
        closed = parse_time(e.get("closed"))
        if closed and closed > t1:
            t1 = closed
        lon, lat, box = geoms[0][1]
        bb, q = _clamp_box(box, lon, lat) if box else (box_around(lon, lat, 40), 1)
        srcs = e.get("sources") or []
        url = (srcs[0].get("url") if srcs else None) or e.get("link")
        names = sorted({s.get("id") for s in srcs if s.get("id")})
        ev = _mk_flood(e["id"], "EONET", e.get("title") or "Flood", None, lon, lat, t0, t1, bb, q, url=url)
        ev["sources"] = ["EONET"] + names  # EONET relays the reporters (FloodList, ReliefWeb, GDACS, ...)
        out.append(ev)
    return out


def cems_floods(start, end, limit):
    out, offset = [], 0
    while offset < 600:  # ~250 activations in total; the list has no date filter
        page = _get_json(CEMS_URL, {"limit": 100, "offset": offset})
        for a in page.get("results", []):
            if (a.get("category") or "").lower() != "flood":
                continue
            t0 = parse_time(a.get("eventTime"))
            if not t0 or not (start <= t0 <= end + timedelta(days=1)):
                continue
            cen = (a.get("centroid") or "").replace("POINT", "").strip(" ()").split()
            if len(cen) != 2:
                continue
            lon, lat = float(cen[0]), float(cen[1])
            countries = [c if isinstance(c, str) else c.get("name") for c in a.get("countries") or []]
            url = f"https://mapping.emergency.copernicus.eu/activations/{a['code']}/"
            ev = _mk_flood(a["code"], "Copernicus EMS", a.get("name") or "Flood", ", ".join(x for x in countries if x) or None,
                           lon, lat, t0, t0, box_around(lon, lat, 40), 1, url=url)
            ev["cems"] = a["code"]
            out.append(ev)
        if not page.get("next"):
            break
        offset += 100
    return out


def _km(a, b):
    p1, p2 = math.radians(a["lat"]), math.radians(b["lat"])
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(b["lon"] - a["lon"]) / 2) ** 2
    return 6371 * 2 * math.asin(min(1, math.sqrt(h)))


def merge_floods(items, max_km=150, max_days=14):
    """The same flood is often reported by GDACS, EONET and Copernicus EMS: merge reports that are close in space
    and time. The merged event keeps every source and link; the better analysis box and the GDACS alert win."""
    merged: list = []
    for e in sorted(items, key=lambda x: x["start"]):
        s0, s1 = parse_time(e["start"]), parse_time(e["end"])
        for m in merged:
            m0, m1 = parse_time(m["start"]), parse_time(m["end"])
            near_in_time = s0 <= m1 + timedelta(days=max_days) and m0 <= s1 + timedelta(days=max_days)
            if near_in_time and _km(e, m) <= max_km:
                m["sources"] = sorted(set(m["sources"]) | set(e["sources"]))
                m["links"] += [x for x in e["links"] if x not in m["links"]]
                m["start"], m["end"] = iso(min(m0, s0)), iso(max(m1, s1))
                if e["_bq"] > m["_bq"]:
                    m["bbox"], m["_bq"], m["lon"], m["lat"] = e["bbox"], e["_bq"], e["lon"], e["lat"]
                m["alert"] = m["alert"] or e["alert"]
                m["severity"] = m["severity"] or e["severity"]
                m["place"] = m["place"] or e["place"]
                if e["source"] in ("Copernicus EMS",):  # human-written title
                    m["title"] = e["title"]
                m["url"] = m["url"] or e["url"]
                m["cems"] = m.get("cems") or e.get("cems")
                break
        else:
            merged.append(dict(e))
    return merged


def parse_bbox(s):
    if not s:
        return None
    try:
        w, so, e, n = (float(x) for x in s.split(","))
    except ValueError:
        raise HTTPException(400, "bbox must be west,south,east,north")
    return [w, so, e, n]


def _inside(e, box):
    return not box or (box[0] <= e["lon"] <= box[2] and box[1] <= e["lat"] <= box[3])


@router.get("/api/events")
def list_events(
    kind: str = Query("all", pattern="^(all|earthquake|flood)$"),
    start: Optional[str] = None, end: Optional[str] = None,
    min_mag: float = Query(5.5, ge=0, le=9.5), bbox: Optional[str] = None, limit: int = Query(100, ge=1, le=500),
    with_data: bool = Query(False, description="keep only events whose date has NISAR products in the ASF archive"),
):
    t1 = parse_time(end) or _now()
    t0 = parse_time(start) or (t1 - timedelta(days=90))
    if t0 > t1:
        raise HTTPException(400, "start must be before end")
    box = parse_bbox(bbox)
    jobs = []
    if kind in ("all", "earthquake"):
        jobs.append(("USGS earthquakes", "eq", lambda: usgs_quakes(t0, t1, min_mag, box, limit)))
    if kind in ("all", "flood"):
        jobs += [("GDACS floods", "fl", lambda: gdacs_floods(t0, t1, box, limit)),
                 ("EONET floods", "fl", lambda: eonet_floods(t0, t1, limit)),
                 ("Copernicus EMS floods", "fl", lambda: cems_floods(t0, t1, limit))]

    def run(job):
        try:
            return job, job[2](), None
        except Exception as exc:  # one source down must not hide the others
            return job, [], f"{job[0]}: {exc}"

    with ThreadPoolExecutor(max_workers=4) as ex:
        results = list(ex.map(run, jobs))
    errors = [r[2] for r in results if r[2]]
    quakes = [e for (j, ev, err) in results if j[1] == "eq" for e in ev]
    floods = merge_floods([e for (j, ev, err) in results if j[1] == "fl" for e in ev if _inside(e, box)])
    events = quakes + floods
    if errors and not events and len(errors) == len(jobs):
        raise HTTPException(502, "Event sources unavailable. " + " | ".join(errors))
    for e in events:
        e.pop("_bq", None)
        st = archive_status(parse_time(e["start"]))
        e["nisar"] = {"status": st, "text": STATUS_TEXT[st]}
    if with_data:
        events = [e for e in events if e["nisar"]["status"] in ("full", "partial")]
    events.sort(key=lambda e: e["start"], reverse=True)
    return {"events": events[:limit], "errors": errors, "range": [iso(t0), iso(t1)], "archive": {k: STATUS_TEXT[k] for k in STATUS_TEXT}}


# --------------------------------------------------------------------------- NISAR scene planner
def _ring_contains(ring, x, y):
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi, xj, yj = ring[i][0], ring[i][1], ring[j][0], ring[j][1]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def footprint_covers(geom, lon, lat) -> bool:
    if not geom:
        return False
    polys = geom["coordinates"] if geom.get("type") == "MultiPolygon" else [geom["coordinates"]] if geom.get("type") == "Polygon" else []
    return any(poly and _ring_contains(poly[0], lon, lat) for poly in polys)


def _asf_search(bbox, start, end, levels):
    import asf_search as asf
    w, s, e, n = bbox
    wkt = f"POLYGON(({w} {s},{e} {s},{e} {n},{w} {n},{w} {s}))"
    res = asf.geo_search(dataset=asf.DATASET.NISAR, intersectsWith=wkt, start=iso(start), end=iso(end),
                         processingLevel=list(levels), maxResults=500)
    return res.geojson().get("features", [])


def _days(a: datetime, b: datetime) -> float:
    return (b - a).total_seconds() / 86400


def _maturity(p):
    m = p.get("dataMaturity") or p.get("maturity")
    if m:
        return str(m).upper()
    name = f"{p.get('sceneName', '')} {p.get('fileID', '')} {p.get('url', '')}".upper()
    return next((k for k in ("VALIDATED", "PROVISIONAL", "BETA") if k in name), "")


def pair_scenes(features, lon, lat, ev_start, ev_end, levels, wait_after_days):
    """Group by (level, direction, track, frame); in each group take the LAST scene before the event and the FIRST
    scene from the event onward. Only scenes whose footprint contains the event point count.
    BETA, PROVISIONAL and VALIDATED products come from different processing versions: a pair uses ONE maturity when
    it can; a pair that has to mix two is kept but flagged (mixed_maturity)."""
    covering = []
    for f in features:
        p = f.get("properties", {})
        t = parse_time(p.get("startTime"))
        if t and p.get("processingLevel") in levels and footprint_covers(f.get("geometry"), lon, lat):
            covering.append((t, f, _maturity(p)))
    groups: dict = {}
    for t, f, mat in covering:
        p = f["properties"]
        groups.setdefault((p["processingLevel"], (p.get("flightDirection") or "").upper(), p.get("pathNumber"), p.get("frameNumber")), []).append((t, f, mat))
    after_end = ev_end + timedelta(days=wait_after_days)

    def best(items, mixed):
        before = [x for x in items if x[0] < ev_start]
        after = [x for x in items if ev_start <= x[0] <= after_end]
        if not before or not after:
            return None
        tb, fb, mb = max(before, key=lambda x: x[0])
        ta, fa, ma = min(after, key=lambda x: x[0])
        if mb != ma and not mixed:
            return None
        return tb, fb, mb, ta, fa, ma

    pairs = []
    for (lvl, direction, track, frame), items in groups.items():
        found = None
        for mat in sorted({x[2] for x in items}, reverse=True):          # same maturity first (VALIDATED > PROVISIONAL > BETA)
            found = best([x for x in items if x[2] == mat], False)
            if found:
                break
        found = found or best(items, True)
        if not found:
            continue
        tb, fb, mb, ta, fa, ma = found
        gb, ga = _days(tb, ev_start), max(0.0, _days(ev_end if ta > ev_end else ev_start, ta))
        pairs.append({
            "level": lvl, "direction": direction, "track": track, "frame": frame,
            "before": fb, "after": fa, "before_time": iso(tb), "after_time": iso(ta),
            "maturity": ma if mb == ma else f"{mb}+{ma}", "mixed_maturity": mb != ma,
            "days_before_event": round(gb, 1), "days_after_event": round(ga, 1),
            "score": round(gb + ga + (30 if mb != ma else 0), 1),
        })
    pairs.sort(key=lambda p: (p["score"], p["level"]))
    tracks = sorted({(k[1], k[2]) for k in groups})
    diag = {"covering_granules": len(covering), "before_event": sum(1 for t, _, _ in covering if t < ev_start),
            "after_event": sum(1 for t, _, _ in covering if ev_start <= t <= after_end), "tracks": [f"{d.lower()} {t}" for d, t in tracks]}
    return pairs, diag


@router.get("/api/events/plan")
def plan(
    kind: str = Query(..., pattern="^(earthquake|flood)$"), lon: float = Query(..., ge=-180, le=180), lat: float = Query(..., ge=-90, le=90),
    start: str = Query(..., description="event start, ISO UTC"), end: Optional[str] = None,
    bbox: Optional[str] = None, magnitude: Optional[float] = None,
    look_back_days: int = Query(90, ge=1, le=730), wait_after_days: int = Query(30, ge=1, le=365),
):
    ev0 = parse_time(start)
    if not ev0:
        raise HTTPException(400, "start must be an ISO date")
    if ev0 > _now():
        raise HTTPException(400, "That event is in the future.")
    ev1 = max(parse_time(end) or ev0, ev0)
    box = parse_bbox(bbox) or box_around(lon, lat, quake_radius_km(magnitude) if (kind == "earthquake" and magnitude) else 40)
    spec = HAZARD[kind]
    win0, win1 = ev0 - timedelta(days=look_back_days), min(ev1 + timedelta(days=wait_after_days), _now())
    status = archive_status(ev0)
    notes = [STATUS_TEXT[status]] if status != "full" else []
    if status in ("pre_mission", "not_published", "instrument_gap"):
        return {"event": {"kind": kind, "lon": lon, "lat": lat, "start": iso(ev0), "end": iso(ev1)}, "bbox": box, "searched": [], "granules_found": 0,
                "pairs": [], "diagnostics": None, "archive_status": status, "notes": notes}  # nothing to search: say why, do not query ASF
    try:
        feats = _asf_search(box, win0, win1, spec["levels"])
    except Exception as exc:
        raise HTTPException(502, f"ASF search failed: {exc}")
    pairs, diag = pair_scenes(feats, lon, lat, ev0, ev1, spec["levels"], wait_after_days)
    for p in pairs:
        p["modes"] = [m for m, lvl in spec["modes"] if lvl == p["level"]]
    if not feats:
        notes.append("ASF returned no NISAR granules over this area in the search window.")
    elif not pairs:
        if not diag["covering_granules"]:
            notes.append("Granules exist near here, but none has a footprint covering the event location.")
        elif not diag["before_event"]:
            before_limit = max(win0, ARCHIVE["provisional_from"])
            notes.append(f"No scene BEFORE the event: the global archive starts on {before_limit:%d %b %Y}. Try a later event or a longer look-back.")
        elif not diag["after_event"]:
            notes.append(f"No scene AFTER the event within {wait_after_days} days (it may not be processed yet, or fell in the instrument gap). Try a longer wait.")
        else:
            notes.append("Scenes exist before and after, but never on the same track and direction. A change map needs the same viewing geometry.")
    if any(p["mixed_maturity"] for p in pairs):
        notes.append("A pair mixes products of different maturity (BETA / PROVISIONAL / VALIDATED): small differences can come from the processing version, not the ground.")
    if kind == "earthquake":
        notes.append("Co-seismic interferograms need the SAME track and direction before and after: only such pairs are listed.")
    else:
        notes.append("Flood water can recede within days; a scene weeks after the event may show nothing. Check days_after_event.")
    return {"event": {"kind": kind, "lon": lon, "lat": lat, "start": iso(ev0), "end": iso(ev1)}, "bbox": box,
            "searched": [iso(win0), iso(win1)], "granules_found": len(feats), "pairs": pairs[:12], "diagnostics": diag,
            "archive_status": status, "notes": notes}


# --------------------------------------------------------------------------- Copernicus EMS observed flood outlines
CEMS_DETAIL_URL = "https://rapidmapping.emergency.copernicus.eu/backend/dashboard-api/public-activations/"
CEMS_HOSTS = ("rapidmapping.emergency.copernicus.eu", "rapidmapping-viewer.s3.eu-west-1.amazonaws.com")
MAX_LAYER_BYTES = 40_000_000
MAX_OUTLINE_FEATURES = 20000
ATTRIBUTION = "Contains modified Copernicus Emergency Management Service information, © European Union."
_layer_cache: dict = {}


def wkt_polygon(wkt):
    """'POLYGON ((x y, x y, ...), (hole...))' -> GeoJSON Polygon coordinates, or None."""
    import re
    if not wkt or not wkt.strip().upper().startswith("POLYGON"):
        return None
    rings = []
    for body in re.findall(r"\(([^()]+)\)", wkt):
        pts = [tuple(float(v) for v in p.split()[:2]) for p in body.split(",") if p.strip()]
        if len(pts) >= 4:
            rings.append([list(p) for p in pts])
    return rings or None


def geodesic_km2(geom) -> float:
    """Area of a GeoJSON Polygon / MultiPolygon on the WGS84 ellipsoid, in km2 (holes subtracted)."""
    from pyproj import Geod
    g = Geod(ellps="WGS84")
    polys = geom["coordinates"] if geom.get("type") == "MultiPolygon" else [geom["coordinates"]] if geom.get("type") == "Polygon" else []
    total = 0.0
    for poly in polys:
        for i, ring in enumerate(poly):
            a = abs(g.polygon_area_perimeter([p[0] for p in ring], [p[1] for p in ring])[0])
            total += a if i == 0 else -a
    return total / 1e6


def _layer_url(layer):
    from urllib.parse import urlparse
    u = layer.get("json")
    if not u:
        return None
    p = urlparse(u)
    return u if p.scheme == "https" and p.hostname in CEMS_HOSTS else None


def _layer_kind(name):
    import re
    m = re.search(r"_([A-Za-z]+)_v(\d+)(?:_VT)?$", name or "")
    return (m.group(1), int(m.group(2))) if m else (None, 0)


def _fetch_layer(url):
    hit = _layer_cache.get(url)
    if hit:
        return hit
    r = requests.get(url, timeout=60, stream=True, headers={"User-Agent": "nisar-explorer/1.0"})
    r.raise_for_status()
    body = b""
    for chunk in r.iter_content(1 << 20):
        body += chunk
        if len(body) > MAX_LAYER_BYTES:
            raise ValueError("layer larger than 40 MB")
    data = __import__("json").loads(body)
    if data.get("type") != "FeatureCollection":
        raise ValueError("layer is not a GeoJSON FeatureCollection")
    _layer_cache[url] = data
    while len(_layer_cache) > 6:
        _layer_cache.pop(next(iter(_layer_cache)))
    return data


def product_label(aoi, p):
    return f"AOI{int(aoi.get('number') or 0):02d}_{p.get('type')}" + (f"_MONIT{int(p.get('monitoringNumber') or 0):02d}" if p.get("monitoring") else "")


def observed_time(p):
    """When the water was SEEN: earliest new (post-event) image of the product, else the earliest image."""
    imgs = [i for i in p.get("images") or [] if parse_time(i.get("acquisitionTime"))]
    new = [i for i in imgs if i.get("new")] or imgs
    return min((parse_time(i["acquisitionTime"]) for i in new), default=None)


@router.get("/api/events/cems/{code}/flood")
def cems_flood_outline(code: str):
    import re
    if not re.fullmatch(r"EMSR\d{1,5}", code):
        raise HTTPException(400, "code must look like EMSR123")
    try:
        detail = _get_json(CEMS_DETAIL_URL, {"code": code}).get("results") or []
    except Exception as exc:
        raise HTTPException(502, f"Copernicus EMS unavailable: {exc}")
    if not detail:
        raise HTTPException(404, f"No public activation {code}")
    act = detail[0]
    todo, masks = [], []
    for aoi in act.get("aois") or []:
        for p in aoi.get("products") or []:
            if not p.get("feasible", True):
                continue
            label = product_label(aoi, p)
            best = max(((_layer_kind(l.get("name"))[1], l) for l in p.get("layers") or [] if _layer_kind(l.get("name"))[0] == "observedEventA" and _layer_url(l)),
                       key=lambda x: x[0], default=(0, None))[1]          # latest version of the observed-event layer
            t = observed_time(p)
            meta = {"label": label, "aoi": aoi.get("name"), "type": p.get("type"), "monitoring": bool(p.get("monitoring")),
                    "observed_time": iso(t) if t else None,
                    "sensors": sorted({i.get("sensorName") for i in p.get("images") or [] if i.get("sensorName")}), "features": 0, "area_km2": None}
            poly = wkt_polygon(p.get("extent"))
            if poly:
                masks.append({"type": "Feature", "properties": {"product": label}, "geometry": {"type": "Polygon", "coordinates": poly}})
            todo.append((meta, _layer_url(best) if best else None))
    todo = todo[:12]

    def get(item):
        meta, url = item
        if not url:
            return meta, None, "no observed-event layer published"
        try:
            return meta, _fetch_layer(url), None
        except Exception as exc:
            return meta, None, str(exc)

    with ThreadPoolExecutor(max_workers=4) as ex:
        loaded = list(ex.map(get, todo))
    feats, products, truncated = [], [], False
    for meta, coll, err in loaded:
        if err:
            meta["error"] = err
        else:
            keep = [f for f in coll.get("features", []) if f.get("geometry") and
                    (not (f.get("properties") or {}).get("event_type") or str(f["properties"]["event_type"]).startswith("5-Flood"))]
            meta["features"] = len(keep)
            meta["area_km2"] = round(sum(geodesic_km2(f["geometry"]) for f in keep), 2)
            for f in keep:
                if len(feats) >= MAX_OUTLINE_FEATURES:
                    truncated = True
                    break
                feats.append({"type": "Feature", "geometry": f["geometry"], "properties": {"product": meta["label"], "observed_time": meta["observed_time"]}})
        products.append(meta)
    return {"code": code, "name": act.get("name"), "event_time": act.get("eventTime"), "report": act.get("reportLink"),
            "products": products, "truncated": truncated, "attribution": ATTRIBUTION,
            "outline": {"type": "FeatureCollection", "features": feats}, "observed_mask": {"type": "FeatureCollection", "features": masks}}
